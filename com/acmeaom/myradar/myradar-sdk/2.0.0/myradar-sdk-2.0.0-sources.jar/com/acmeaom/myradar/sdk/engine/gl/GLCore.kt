package com.acmeaom.myradar.sdk.engine.gl

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES30
import android.util.Log
import android.view.Surface
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer
import java.util.concurrent.ConcurrentLinkedQueue

/** How a draw blends into what's already drawn. */
internal enum class BlendMode {
    /** Premultiplied alpha: `src + dst * (1 - src.a)`. */
    PREMULTIPLIED,
    /** `dst * (1 + src)`, leaving alpha alone, for brightening (lightning flashes). */
    BRIGHTEN,
    /** Writes nothing to color (stencil-only draws). */
    NONE,
}

/** How a draw uses the stencil buffer. */
internal enum class StencilMode {
    OFF,
    /** Writes the reference value wherever it draws. */
    WRITE,
    /** Draws only where the stencil equals the reference value. */
    TEST_EQUAL,
    /** Inverts the stencil wherever it draws (counting coverage for even-odd fills). */
    INVERT,
    /** Draws where the stencil isn't zero, and zeroes it there, so each pixel draws once. */
    TEST_NONZERO_AND_CLEAR,
}

/**
 * The shared OpenGL ES 3 state for every map: one EGL context for the process, current on the
 * main thread (on a tiny pbuffer between frames, on a map's window surface while it draws), and
 * the shader programs built from [EngineShaders]. All GL calls happen on the main thread.
 */
internal class GLContext private constructor(
    val display: EGLDisplay,
    val config: EGLConfig,
    val context: EGLContext,
    private val idleSurface: EGLSurface,
    /** Samples per pixel of the window surfaces (4 when multisampling is available). */
    val samples: Int,
) {
    /** Programs by vertex shader, then fragment shader (no key built per draw). */
    private val programs = HashMap<String, HashMap<String, Program?>>()
    private var stream: FloatBuffer = GLContext.floatBuffer(FloatArray(4096))
    private val clearFramebuffer = IntArray(1)
    private val pendingDeletes = ConcurrentLinkedQueue<Pair<Int, Int>>()
    private val streamBuffer = IntArray(1)
    private val streamVao = IntArray(1)
    private val emptyVao = IntArray(1)

    init {
        GLES30.glGenBuffers(1, streamBuffer, 0)
        GLES30.glGenVertexArrays(1, streamVao, 0)
        GLES30.glGenVertexArrays(1, emptyVao, 0)
    }

    fun makeCurrent(surface: EGLSurface?): Boolean =
        EGL14.eglMakeCurrent(display, surface ?: idleSurface, surface ?: idleSurface, context)

    fun createWindowSurface(surface: Surface): EGLSurface? {
        val s = EGL14.eglCreateWindowSurface(display, config, surface, intArrayOf(EGL14.EGL_NONE), 0)
        return if (s == null || s == EGL14.EGL_NO_SURFACE) null else s
    }

    fun destroySurface(surface: EGLSurface) {
        makeCurrent(null)
        EGL14.eglDestroySurface(display, surface)
    }

    /** A program for a vertex and fragment shader in [EngineShaders], built once. */
    fun program(vertex: String, fragment: String): Program? {
        val byFragment = programs.getOrPut(vertex) { HashMap() }
        byFragment[fragment]?.let { return it }
        if (byFragment.containsKey(fragment)) return null
        val program = Program.build(vertex, fragment)
        byFragment[fragment] = program
        return program
    }

    /** Deletes GL objects whose owners were collected. Called at the start of each frame. */
    fun drainDeletes() {
        while (true) {
            val (kind, id) = pendingDeletes.poll() ?: break
            val ids = intArrayOf(id)
            when (kind) {
                KIND_TEXTURE -> GLES30.glDeleteTextures(1, ids, 0)
                KIND_BUFFER -> GLES30.glDeleteBuffers(1, ids, 0)
                KIND_VAO -> GLES30.glDeleteVertexArrays(1, ids, 0)
            }
        }
    }

    fun deleteLater(kind: Int, id: Int) {
        if (id != 0) pendingDeletes.add(kind to id)
    }

    fun applyBlend(blend: BlendMode) {
        when (blend) {
            BlendMode.PREMULTIPLIED -> {
                GLES30.glEnable(GLES30.GL_BLEND)
                GLES30.glColorMask(true, true, true, true)
                GLES30.glBlendFuncSeparate(GLES30.GL_ONE, GLES30.GL_ONE_MINUS_SRC_ALPHA,
                    GLES30.GL_ONE, GLES30.GL_ONE_MINUS_SRC_ALPHA)
            }
            BlendMode.BRIGHTEN -> {
                GLES30.glEnable(GLES30.GL_BLEND)
                GLES30.glColorMask(true, true, true, false)
                GLES30.glBlendFuncSeparate(GLES30.GL_DST_COLOR, GLES30.GL_ONE, GLES30.GL_ZERO, GLES30.GL_ONE)
            }
            BlendMode.NONE -> {
                GLES30.glDisable(GLES30.GL_BLEND)
                GLES30.glColorMask(false, false, false, false)
            }
        }
    }

    fun applyStencil(mode: StencilMode, reference: Int) {
        if (mode == StencilMode.OFF) {
            GLES30.glDisable(GLES30.GL_STENCIL_TEST)
            return
        }
        GLES30.glEnable(GLES30.GL_STENCIL_TEST)
        when (mode) {
            StencilMode.WRITE -> {
                GLES30.glStencilMask(0xFF)
                GLES30.glStencilFunc(GLES30.GL_ALWAYS, reference, 0xFF)
                GLES30.glStencilOp(GLES30.GL_KEEP, GLES30.GL_KEEP, GLES30.GL_REPLACE)
            }
            StencilMode.TEST_EQUAL -> {
                GLES30.glStencilMask(0)
                GLES30.glStencilFunc(GLES30.GL_EQUAL, reference, 0xFF)
                GLES30.glStencilOp(GLES30.GL_KEEP, GLES30.GL_KEEP, GLES30.GL_KEEP)
            }
            StencilMode.INVERT -> {
                GLES30.glStencilMask(0xFF)
                GLES30.glStencilFunc(GLES30.GL_ALWAYS, reference, 0xFF)
                GLES30.glStencilOp(GLES30.GL_KEEP, GLES30.GL_KEEP, GLES30.GL_INVERT)
            }
            StencilMode.TEST_NONZERO_AND_CLEAR -> {
                GLES30.glStencilMask(0xFF)
                GLES30.glStencilFunc(GLES30.GL_NOTEQUAL, 0, 0xFF)
                GLES30.glStencilOp(GLES30.GL_KEEP, GLES30.GL_KEEP, GLES30.GL_ZERO)
            }
            StencilMode.OFF -> Unit
        }
    }

    /** Uploads per-draw vertices to the streaming buffer and binds it with `layout`. */
    fun bindStream(vertices: FloatArray, count: Int, layout: VertexLayout) {
        GLES30.glBindVertexArray(streamVao[0])
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, streamBuffer[0])
        // One direct buffer, grown as needed, so per-frame draws don't allocate.
        if (stream.capacity() < count) stream = floatBuffer(FloatArray(maxOf(count, stream.capacity() * 2)))
        stream.clear()
        stream.put(vertices, 0, count)
        stream.position(0)
        // Orphan the old storage so the driver needn't wait for draws still reading it.
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, count * 4, null, GLES30.GL_STREAM_DRAW)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, count * 4, stream, GLES30.GL_STREAM_DRAW)
        layout.apply()
    }

    /** Fills a texture with zeros on the GPU, then restores the framebuffer and viewport. */
    fun clear(texture: GPUTexture) {
        if (clearFramebuffer[0] == 0) GLES30.glGenFramebuffers(1, clearFramebuffer, 0)
        val previous = IntArray(1)
        GLES30.glGetIntegerv(GLES30.GL_FRAMEBUFFER_BINDING, previous, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, clearFramebuffer[0])
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D,
            texture.id, 0)
        val viewport = IntArray(4)
        GLES30.glGetIntegerv(GLES30.GL_VIEWPORT, viewport, 0)
        GLES30.glViewport(0, 0, texture.width, texture.height)
        GLES30.glColorMask(true, true, true, true)
        GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
        GLES30.glClearColor(0f, 0f, 0f, 0f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, 0, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, previous[0])
        GLES30.glViewport(viewport[0], viewport[1], viewport[2], viewport[3])
    }

    fun bindEmptyVertexArray() {
        GLES30.glBindVertexArray(emptyVao[0])
    }

    companion object {
        const val KIND_TEXTURE = 0
        const val KIND_BUFFER = 1
        const val KIND_VAO = 2
        private const val LOG_TAG = "MyRadarSDK"

        private var instance: GLContext? = null
        private var failed = false

        /** The process's context, created on first use; null when OpenGL ES 3 isn't available. */
        val shared: GLContext?
            get() {
                instance?.let { return it }
                if (failed) return null
                instance = create()
                if (instance == null) failed = true
                return instance
            }

        private fun create(): GLContext? {
            val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val version = IntArray(2)
            if (display == EGL14.EGL_NO_DISPLAY || !EGL14.eglInitialize(display, version, 0, version, 1)) {
                Log.e(LOG_TAG, "EGL is not available")
                return null
            }
            // Prefer 4× multisampling, as the engine draws on iOS; fall back without it.
            for (samples in intArrayOf(4, 0)) {
                val attributes = intArrayOf(
                    EGL14.EGL_RENDERABLE_TYPE, 0x40, // EGL_OPENGL_ES3_BIT_KHR
                    EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT or EGL14.EGL_PBUFFER_BIT,
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_STENCIL_SIZE, 8,
                    EGL14.EGL_SAMPLE_BUFFERS, if (samples > 0) 1 else 0,
                    EGL14.EGL_SAMPLES, samples,
                    EGL14.EGL_NONE,
                )
                val configs = arrayOfNulls<EGLConfig>(1)
                val count = IntArray(1)
                if (!EGL14.eglChooseConfig(display, attributes, 0, configs, 0, 1, count, 0) || count[0] == 0) continue
                val config = configs[0] ?: continue
                val context = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT,
                    intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
                if (context == null || context == EGL14.EGL_NO_CONTEXT) continue
                val idle = EGL14.eglCreatePbufferSurface(display, config,
                    intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
                if (idle == null || idle == EGL14.EGL_NO_SURFACE ||
                    !EGL14.eglMakeCurrent(display, idle, idle, context)) {
                    EGL14.eglDestroyContext(display, context)
                    continue
                }
                return GLContext(display, config, context, idle, samples)
            }
            Log.e(LOG_TAG, "OpenGL ES 3 is not available on this device")
            return null
        }

        fun floatBuffer(values: FloatArray, count: Int = values.size): FloatBuffer =
            ByteBuffer.allocateDirect(count * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(values, 0, count); position(0)
            }

        fun intBuffer(values: IntArray): IntBuffer =
            ByteBuffer.allocateDirect(values.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer().apply {
                put(values); position(0)
            }
    }
}

/**
 * Interleaved float vertex attributes: each entry is an attribute's component count, bound to
 * locations 0, 1, 2… in order, as the shaders declare them.
 */
internal class VertexLayout(vararg val components: Int) {
    val stride: Int = components.sum()

    fun apply() {
        var offset = 0
        for ((location, count) in components.withIndex()) {
            GLES30.glEnableVertexAttribArray(location)
            GLES30.glVertexAttribPointer(location, count, GLES30.GL_FLOAT, false, stride * 4, offset * 4)
            offset += count
        }
        for (location in components.size until MAX_ATTRIBUTES) GLES30.glDisableVertexAttribArray(location)
    }

    private companion object {
        const val MAX_ATTRIBUTES = 8
    }
}

/** A linked program with its uniform locations looked up once. */
internal class Program private constructor(val id: Int) {
    private val locations = HashMap<String, Int>()

    fun location(name: String): Int = locations.getOrPut(name) { GLES30.glGetUniformLocation(id, name) }

    fun setFloat(name: String, v: Float) = GLES30.glUniform1f(location(name), v)
    fun setInt(name: String, v: Int) = GLES30.glUniform1i(location(name), v)
    fun setVec2(name: String, x: Float, y: Float) = GLES30.glUniform2f(location(name), x, y)
    fun setVec3(name: String, x: Float, y: Float, z: Float) = GLES30.glUniform3f(location(name), x, y, z)
    fun setVec4(name: String, x: Float, y: Float, z: Float, w: Float) = GLES30.glUniform4f(location(name), x, y, z, w)
    fun setVec4Array(name: String, values: FloatArray) = GLES30.glUniform4fv(location(name), values.size / 4, values, 0)
    fun setMat4(name: String, m: FloatArray) = GLES30.glUniformMatrix4fv(location(name), 1, false, m, 0)

    companion object {
        private const val LOG_TAG = "MyRadarSDK"

        fun build(vertex: String, fragment: String): Program? {
            val vs = EngineShaders.vertex[vertex] ?: return missing(vertex)
            val fs = EngineShaders.fragment[fragment] ?: return missing(fragment)
            val v = compile(GLES30.GL_VERTEX_SHADER, vs, vertex) ?: return null
            val f = compile(GLES30.GL_FRAGMENT_SHADER, fs, fragment) ?: return null
            val id = GLES30.glCreateProgram()
            GLES30.glAttachShader(id, v)
            GLES30.glAttachShader(id, f)
            GLES30.glLinkProgram(id)
            GLES30.glDeleteShader(v)
            GLES30.glDeleteShader(f)
            val status = IntArray(1)
            GLES30.glGetProgramiv(id, GLES30.GL_LINK_STATUS, status, 0)
            if (status[0] == 0) {
                Log.e(LOG_TAG, "Program $vertex/$fragment failed to link: ${GLES30.glGetProgramInfoLog(id)}")
                GLES30.glDeleteProgram(id)
                return null
            }
            return Program(id)
        }

        private fun missing(name: String): Program? {
            Log.e(LOG_TAG, "Missing shader $name")
            return null
        }

        private fun compile(type: Int, source: String, name: String): Int? {
            val shader = GLES30.glCreateShader(type)
            GLES30.glShaderSource(shader, source)
            GLES30.glCompileShader(shader)
            val status = IntArray(1)
            GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
            if (status[0] == 0) {
                Log.e(LOG_TAG, "Shader $name failed to compile: ${GLES30.glGetShaderInfoLog(shader)}")
                GLES30.glDeleteShader(shader)
                return null
            }
            return shader
        }
    }
}

/** One frame's drawing: the GL state and what layers need to draw. */
internal class RenderContext(
    val gl: GLContext,
    val transform: MapTransform,
    /** Pixels per point (dp). */
    val pixelRatio: Double,
    /** Seconds, on the same clock as `SystemClock.uptimeMillis() / 1000`. */
    val now: Double,
    /** The drawable size in pixels. */
    val pixelWidth: Int,
    val pixelHeight: Int,
) {
    /** Uses a program with a blend and stencil mode; null when the program isn't available. */
    fun use(vertex: String, fragment: String, blend: BlendMode = BlendMode.PREMULTIPLIED,
            stencil: StencilMode = StencilMode.OFF, reference: Int = 0): Program? {
        val program = gl.program(vertex, fragment) ?: return null
        GLES30.glUseProgram(program.id)
        gl.applyBlend(blend)
        gl.applyStencil(stencil, reference)
        return program
    }

    /** Zeroes the stencil buffer over the whole view. */
    fun clearStencil() {
        GLES30.glStencilMask(0xFF)
        GLES30.glClearStencil(0)
        GLES30.glClear(GLES30.GL_STENCIL_BUFFER_BIT)
    }

    /** Draws vertices given for this draw only, as triangles unless `mode` says otherwise. */
    fun drawVertices(vertices: FloatArray, layout: VertexLayout, count: Int = vertices.size,
                     mode: Int = GLES30.GL_TRIANGLES) {
        if (count == 0) return
        gl.bindStream(vertices, count, layout)
        GLES30.glDrawArrays(mode, 0, count / layout.stride)
    }

    /** Draws `count` vertices with no attributes (shaders use `gl_VertexID`). */
    fun drawWithoutVertices(count: Int) {
        gl.bindEmptyVertexArray()
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, count)
    }
}

/** Interleaved float vertices and 32-bit indices, uploaded once. */
internal class GPUMesh private constructor(
    private val gl: GLContext,
    private val vao: Int,
    private val vbo: Int,
    private val ibo: Int,
    val indexCount: Int,
) {
    /** Draws all the indices, or a range of them. */
    fun draw(indices: IntRange = 0 until indexCount) {
        if (indices.isEmpty()) return
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, indices.last - indices.first + 1,
            GLES30.GL_UNSIGNED_INT, indices.first * 4)
    }

    protected fun finalize() {
        gl.deleteLater(GLContext.KIND_VAO, vao)
        gl.deleteLater(GLContext.KIND_BUFFER, vbo)
        gl.deleteLater(GLContext.KIND_BUFFER, ibo)
    }

    companion object {
        fun create(vertices: FloatArray, indices: IntArray, layout: VertexLayout): GPUMesh? {
            val gl = GLContext.shared ?: return null
            if (vertices.isEmpty() || indices.isEmpty()) return null
            val ids = IntArray(2)
            val vao = IntArray(1)
            GLES30.glGenVertexArrays(1, vao, 0)
            GLES30.glGenBuffers(2, ids, 0)
            GLES30.glBindVertexArray(vao[0])
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, ids[0])
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vertices.size * 4, GLContext.floatBuffer(vertices),
                GLES30.GL_STATIC_DRAW)
            layout.apply()
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ids[1])
            GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, indices.size * 4, GLContext.intBuffer(indices),
                GLES30.GL_STATIC_DRAW)
            GLES30.glBindVertexArray(0)
            return GPUMesh(gl, vao[0], ids[0], ids[1], indices.size)
        }
    }
}

/** An 8-bit texture: RGBA (premultiplied unless the caller says otherwise) or single channel. */
internal class GPUTexture private constructor(
    private val gl: GLContext,
    val id: Int,
    val width: Int,
    val height: Int,
    val singleChannel: Boolean,
    val mipmapped: Boolean,
) {
    /** Replaces a region of the top mip level. Rows run top first. */
    fun replace(x: Int, y: Int, width: Int, height: Int, pixels: ByteArray) {
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        val format = if (singleChannel) GLES30.GL_RED else GLES30.GL_RGBA
        GLES30.glTexSubImage2D(GLES30.GL_TEXTURE_2D, 0, x, y, width, height, format, GLES30.GL_UNSIGNED_BYTE,
            ByteBuffer.wrap(pixels))
    }

    /** Fills the texture with zeros on the GPU. */
    fun clear() = gl.clear(this)

    fun generateMipmaps() {
        if (!mipmapped) return
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
    }

    /** Binds to a texture unit and points a sampler uniform at it. */
    fun bind(program: Program, unit: Int, sampler: String) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id)
        program.setInt(sampler, unit)
    }

    protected fun finalize() {
        gl.deleteLater(GLContext.KIND_TEXTURE, id)
    }

    companion object {
        /**
         * An empty texture. `linear` picks bilinear sampling (with trilinear when mipmapped),
         * otherwise nearest. Edges clamp.
         */
        fun create(width: Int, height: Int, singleChannel: Boolean = false, linear: Boolean = true,
                   mipmaps: Boolean = false): GPUTexture? {
            val gl = GLContext.shared ?: return null
            if (width <= 0 || height <= 0) return null
            val ids = IntArray(1)
            GLES30.glGenTextures(1, ids, 0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, ids[0])
            val levels = if (mipmaps) 1 + (31 - Integer.numberOfLeadingZeros(maxOf(width, height))) else 1
            GLES30.glTexStorage2D(GLES30.GL_TEXTURE_2D, levels, if (singleChannel) GLES30.GL_R8 else GLES30.GL_RGBA8,
                width, height)
            val mag = if (linear) GLES30.GL_LINEAR else GLES30.GL_NEAREST
            val min = when {
                mipmaps -> GLES30.GL_LINEAR_MIPMAP_LINEAR
                else -> mag
            }
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, min)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, mag)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
            return GPUTexture(gl, ids[0], width, height, singleChannel, mipmaps)
        }

        /** An RGBA texture holding `pixels` (rows top first). */
        fun rgba(pixels: ByteArray, width: Int, height: Int, linear: Boolean = true, mipmaps: Boolean = false): GPUTexture? {
            val texture = create(width, height, linear = linear, mipmaps = mipmaps) ?: return null
            texture.replace(0, 0, width, height, pixels)
            texture.generateMipmaps()
            return texture
        }
    }
}
