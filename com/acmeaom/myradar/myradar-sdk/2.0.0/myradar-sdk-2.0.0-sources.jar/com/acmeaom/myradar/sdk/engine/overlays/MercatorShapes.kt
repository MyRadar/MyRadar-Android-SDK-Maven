package com.acmeaom.myradar.sdk.engine.overlays

import com.acmeaom.myradar.sdk.engine.basemap.FloatList
import com.acmeaom.myradar.sdk.engine.basemap.IntList
import com.acmeaom.myradar.sdk.engine.basemap.LineCap
import com.acmeaom.myradar.sdk.engine.basemap.LineGeometry
import com.acmeaom.myradar.sdk.engine.basemap.LineJoin
import com.acmeaom.myradar.sdk.engine.basemap.RGBA
import com.acmeaom.myradar.sdk.engine.camera.Mat4
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.ScreenPoint
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import com.acmeaom.myradar.sdk.engine.gl.BlendMode
import com.acmeaom.myradar.sdk.engine.gl.GPUMesh
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.gl.StencilMode
import com.acmeaom.myradar.sdk.engine.gl.VertexLayout
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Builds one batch of colored fills or outlines in map coordinates, for overlays (warnings,
 * hurricanes) and annotations, with a color and a width per vertex.
 *
 * Polygons fill with the odd winding rule, one polygon at a time, as the engine's libtess
 * triangulation (`FWTriangulator`, `TESS_WINDING_ODD`) does: self-intersecting shapes fill evenly
 * and holes stay empty, while separate polygons that overlap still blend over each other. Each
 * polygon's triangle fans count coverage in the stencil buffer, then the color draws once
 * wherever the count is odd. Lines are extruded with round joins and draw in one call.
 *
 * Vertices are stored relative to an origin near the shapes, in Web Mercator units, so float
 * precision holds at street zooms.
 */
internal class MercatorShapeBuilder(val origin: Vec2) {
    /** x, y, r, g, b, a */
    val fills = FloatList()
    val fillIndices = IntList()
    /** Each polygon's range of `fillIndices`, in the order added. */
    val polygons = ArrayList<IntRange>()
    /** x, y, ex, ey, half width (points), r, g, b, a, distance along the line, dashed (0 or 1) */
    val lines = FloatList(1024)
    val lineIndices = IntList(1024)
    /** The x extent of everything added, in Web Mercator; may pass 0 or 1 (e.g. longitudes past 180°). */
    var minX = Double.POSITIVE_INFINITY; private set
    var maxX = Double.NEGATIVE_INFINITY; private set

    private fun note(p: Vec2) {
        minX = min(minX, p.x)
        maxX = max(maxX, p.x)
    }

    /** A polygon: its outer ring then its holes, in Web Mercator. `color` is premultiplied. */
    fun addFill(rings: List<List<Vec2>>, color: RGBA) {
        val start = fillIndices.size
        for (ring in rings) {
            val points = if (ring.size > 1 && ring.first() == ring.last()) ring.dropLast(1) else ring
            if (points.size < 3) continue
            val base = fills.size / 6
            for (p in points) {
                note(p)
                fills.add((p.x - origin.x).toFloat()); fills.add((p.y - origin.y).toFloat())
                fills.add(color.r); fills.add(color.g); fills.add(color.b); fills.add(color.a)
            }
            // A fan from the ring's first point; the stencil sorts out what's inside.
            for (i in 1 until points.size - 1) fillIndices.add(base, base + i, base + i + 1)
        }
        if (fillIndices.size > start) polygons.add(start until fillIndices.size)
    }

    /**
     * A line of `width` points, with round joins and caps. `color` is premultiplied. Dashed lines
     * follow the dash pattern the batch is drawn with.
     */
    fun addLine(points: List<Vec2>, width: Float, color: RGBA, closed: Boolean = false, dashed: Boolean = false) {
        val geometry = LineGeometry()
        val close = closed && points.isNotEmpty() && points.last() != points.first()
        val path = FloatArray((points.size + if (close) 1 else 0) * 2)
        for ((i, p) in points.withIndex()) {
            note(p)
            path[2 * i] = (p.x - origin.x).toFloat(); path[2 * i + 1] = (p.y - origin.y).toFloat()
        }
        if (close) { path[path.size - 2] = path[0]; path[path.size - 1] = path[1] }
        geometry.add(path, LineJoin.ROUND, LineCap.ROUND, 2f)
        val base = lines.size / 11
        val v = geometry.vertices.data
        val stride = LineGeometry.FLOATS_PER_VERTEX
        var i = 0
        while (i < geometry.vertices.size) {
            lines.add(v[i]); lines.add(v[i + 1]); lines.add(v[i + 2]); lines.add(v[i + 3])
            lines.add(width / 2); lines.add(color.r); lines.add(color.g); lines.add(color.b); lines.add(color.a)
            lines.add(v[i + 4]); lines.add(if (dashed) 1f else 0f)
            i += stride
        }
        val idx = geometry.indices.data
        for (k in 0 until geometry.indices.size) lineIndices.add(base + idx[k])
    }

    val isEmpty: Boolean get() = fillIndices.size == 0 && lineIndices.size == 0
}

/** GPU meshes for a built batch. */
internal class MercatorShapes(builder: MercatorShapeBuilder) {
    val origin: Vec2 = builder.origin
    private val minX = builder.minX
    private val maxX = builder.maxX
    private val fill = GPUMesh.create(builder.fills.toArray(), builder.fillIndices.toArray(), FILL_LAYOUT)
    private val polygons = builder.polygons.toList()
    private val line = GPUMesh.create(builder.lines.toArray(), builder.lineIndices.toArray(), LINE_LAYOUT)

    /**
     * Draws fills (scaled by `fillOpacity`) then lines (scaled by `lineOpacity`), once per world
     * copy in view. `dash` is the on/off pattern in points for lines added as dashed.
     */
    fun draw(context: RenderContext, fillOpacity: Float = 1f, lineOpacity: Float = 1f, dash: List<Float> = emptyList()) {
        var pattern = dash.take(8)
        // An odd-length pattern repeats to make on/off pairs, as dash arrays do.
        if (pattern.size % 2 == 1) pattern = pattern + pattern
        pattern = pattern.take(8)
        val total = pattern.sum()
        val p = FloatArray(8) { pattern.getOrElse(it) { 0f } }
        val transform = context.transform
        val projection = transform.projectionMatrix
        // Line widths are in points; geometry is in Mercator units.
        val unitsPerPoint = (1 / transform.worldSize).toFloat()
        for (wrap in visibleWraps(transform, minX, maxX)) {
            val m = (projection * Mat4.scale(transform.worldSize, transform.worldSize, 1.0) *
                Mat4.translate(origin.x + wrap, origin.y, 0.0)).toFloatArray()
            if (fill != null && fillOpacity > 0) {
                // Needs a zeroed stencil, which each polygon leaves behind.
                for (polygon in polygons) {
                    val count = context.use("shape_fill_vs", "color_fs", BlendMode.NONE, StencilMode.INVERT) ?: break
                    count.setMat4("u_matrix", m)
                    count.setFloat("u_opacity", fillOpacity)
                    fill.draw(polygon)
                    context.use("shape_fill_vs", "color_fs", stencil = StencilMode.TEST_NONZERO_AND_CLEAR)
                    fill.draw(polygon)
                }
            }
            if (line != null && lineOpacity > 0) {
                val program = context.use("shape_line_vs", "shape_line_fs") ?: continue
                program.setMat4("u_matrix", m)
                program.setFloat("u_opacity", lineOpacity)
                program.setFloat("u_unitsPerPoint", unitsPerPoint)
                program.setVec4("u_dashA", p[0], p[1], p[2], p[3])
                program.setVec4("u_dashB", p[4], p[5], p[6], p[7])
                program.setFloat("u_dashTotal", total)
                line.draw()
            }
        }
    }

    companion object {
        val FILL_LAYOUT = VertexLayout(2, 4)
        val LINE_LAYOUT = VertexLayout(2, 2, 1, 4, 1, 1)

        /**
         * Whole-world offsets at which something spanning `minX..maxX` in Web Mercator x (0..1 by
         * default) intersects the view.
         */
        fun visibleWraps(transform: MapTransform, minX: Double = 0.0, maxX: Double = 1.0): List<Int> {
            val w = transform.width; val h = transform.height
            val projection = transform.projectionMatrix
            val xs = listOf(ScreenPoint(0.0, 0.0), ScreenPoint(w, 0.0), ScreenPoint(0.0, h), ScreenPoint(w, h))
                .mapNotNull { transform.mercatorAt(it, projection)?.x }
            if (xs.isEmpty() || minX > maxX) return listOf(0)
            val viewMin = xs.min(); val viewMax = xs.max()
            // `mercatorAt` is unwrapped around the camera's center, which is in 0..1.
            val first = floor(viewMin - maxX).toInt(); val last = ceil(viewMax - minX).toInt()
            return (first..last).filter { it + minX < viewMax && it + maxX > viewMin }
        }
    }
}
