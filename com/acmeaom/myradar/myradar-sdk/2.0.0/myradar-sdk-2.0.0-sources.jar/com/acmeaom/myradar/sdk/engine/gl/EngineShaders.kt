package com.acmeaom.myradar.sdk.engine.gl

/**
 * The engine's GLSL ES 3.00 shaders, by name. Vertex shaders take interleaved float attributes
 * at locations 0, 1, 2… in the order their [VertexLayout] lists them. Colors are premultiplied.
 *
 * The radar and wind particle fragment shaders are the engine's own ([WeatherShaders]).
 */
internal object EngineShaders {
    private const val HEADER = "#version 300 es\nprecision highp float;\nprecision highp int;\n"

    val vertex: Map<String, String> by lazy {
        mapOf(
            // Base map
            "basemap_fill_vs" to """
                layout(location = 0) in vec2 a_pos;
                uniform mat4 u_matrix;
                void main() { gl_Position = u_matrix * vec4(a_pos, 0.0, 1.0); }
            """,
            "basemap_line_vs" to """
                layout(location = 0) in vec2 a_pos;
                layout(location = 1) in vec2 a_normal;
                layout(location = 2) in float a_distance;
                uniform mat4 u_matrix;
                uniform float u_halfwidth;
                out float v_distance;
                void main() {
                    gl_Position = u_matrix * vec4(a_pos + a_normal * u_halfwidth, 0.0, 1.0);
                    v_distance = a_distance;
                }
            """,
            // A unit quad: positions double as texture coordinates.
            "raster_vs" to """
                layout(location = 0) in vec2 a_pos;
                uniform mat4 u_matrix;
                out vec2 v_uv;
                void main() {
                    gl_Position = u_matrix * vec4(a_pos, 0.0, 1.0);
                    v_uv = a_pos;
                }
            """,
            // A full-screen triangle.
            "fullscreen_vs" to """
                void main() {
                    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
                    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
                }
            """,
            // Shapes (warnings, hurricanes, annotations)
            "shape_fill_vs" to """
                layout(location = 0) in vec2 a_pos;
                layout(location = 1) in vec4 a_color;
                uniform mat4 u_matrix;
                uniform float u_opacity;
                out vec4 v_color;
                void main() {
                    gl_Position = u_matrix * vec4(a_pos, 0.0, 1.0);
                    v_color = a_color * u_opacity;
                }
            """,
            "shape_line_vs" to """
                layout(location = 0) in vec2 a_pos;
                layout(location = 1) in vec2 a_normal;
                layout(location = 2) in float a_width;
                layout(location = 3) in vec4 a_color;
                layout(location = 4) in float a_distance;
                layout(location = 5) in float a_dashed;
                uniform mat4 u_matrix;
                uniform float u_opacity;
                uniform float u_unitsPerPoint;
                out vec4 v_color;
                out float v_distance;
                out float v_dashed;
                void main() {
                    vec2 pos = a_pos + a_normal * a_width * u_unitsPerPoint;
                    gl_Position = u_matrix * vec4(pos, 0.0, 1.0);
                    v_color = a_color * u_opacity;
                    v_distance = a_distance / u_unitsPerPoint;
                    v_dashed = a_dashed;
                }
            """,
            // Labels
            "text_vs" to """
                layout(location = 0) in vec2 a_pos;
                layout(location = 1) in vec2 a_uv;
                layout(location = 2) in vec4 a_fill;
                layout(location = 3) in vec4 a_halo;
                layout(location = 4) in vec3 a_params;
                uniform vec2 u_screen;
                uniform vec2 u_atlasSize;
                out vec2 v_uv;
                out vec4 v_fill;
                out vec4 v_halo;
                out vec3 v_params;
                void main() {
                    gl_Position = vec4(a_pos.x / u_screen.x * 2.0 - 1.0, 1.0 - a_pos.y / u_screen.y * 2.0, 0.0, 1.0);
                    v_uv = a_uv / u_atlasSize;
                    v_fill = a_fill;
                    v_halo = a_halo;
                    v_params = a_params;
                }
            """,
            "icon_vs" to """
                layout(location = 0) in vec2 a_pos;
                layout(location = 1) in vec2 a_uv;
                layout(location = 2) in float a_opacity;
                uniform vec2 u_screen;
                uniform vec2 u_atlasSize;
                out vec2 v_uv;
                out float v_opacity;
                void main() {
                    gl_Position = vec4(a_pos.x / u_screen.x * 2.0 - 1.0, 1.0 - a_pos.y / u_screen.y * 2.0, 0.0, 1.0);
                    v_uv = a_uv / u_atlasSize;
                    v_opacity = a_opacity;
                }
            """,
            // Lightning and other map stamps
            "marker_vs" to """
                layout(location = 0) in vec2 a_pos;
                layout(location = 1) in vec2 a_corner;
                uniform mat4 u_matrix;
                uniform vec2 u_sizeNdc;
                out vec2 v_uv;
                void main() {
                    gl_Position = u_matrix * vec4(a_pos, 0.0, 1.0);
                    gl_Position.xy += a_corner * u_sizeNdc * gl_Position.w;
                    // Image rows run top down; clip space y runs up.
                    v_uv = vec2(a_corner.x + 0.5, 0.5 - a_corner.y);
                }
            """,
            "flash_vs" to """
                layout(location = 0) in vec2 a_pos;
                uniform mat4 u_matrix;
                out vec2 v_offset;
                void main() {
                    v_offset = a_pos;
                    gl_Position = u_matrix * vec4(a_pos, 0.0, 1.0);
                }
            """,
        ).mapValues { HEADER + it.value.trimIndent() } + WeatherShaders.vertex
    }

    val fragment: Map<String, String> by lazy {
        mapOf(
            "solid_fs" to """
                uniform vec4 u_color;
                out vec4 frag_color;
                void main() { frag_color = u_color; }
            """,
            "color_fs" to """
                in vec4 v_color;
                out vec4 frag_color;
                void main() { frag_color = v_color; }
            """,
            // Dashes: `u_dash` holds up to two on/off pairs in tile units; `u_dashTotal` 0 means solid.
            "line_fs" to """
                in float v_distance;
                uniform vec4 u_color;
                uniform vec4 u_dash;
                uniform float u_dashTotal;
                out vec4 frag_color;
                void main() {
                    if (u_dashTotal > 0.0) {
                        float t = mod(v_distance, u_dashTotal);
                        bool on = t < u_dash.x || (t >= u_dash.x + u_dash.y && t < u_dash.x + u_dash.y + u_dash.z);
                        if (!on) discard;
                    }
                    frag_color = u_color;
                }
            """,
            "raster_fs" to """
                in vec2 v_uv;
                uniform sampler2D u_tex;
                uniform float u_opacity;
                out vec4 frag_color;
                void main() { frag_color = texture(u_tex, v_uv) * u_opacity; }
            """,
            // Dashes in points: up to four on/off pairs; `u_dashTotal` 0 draws solid.
            "shape_line_fs" to """
                in vec4 v_color;
                in float v_distance;
                in float v_dashed;
                uniform vec4 u_dashA;
                uniform vec4 u_dashB;
                uniform float u_dashTotal;
                out vec4 frag_color;
                void main() {
                    if (v_dashed > 0.5 && u_dashTotal > 0.0) {
                        float t = mod(v_distance, u_dashTotal);
                        float pattern[8] = float[8](u_dashA.x, u_dashA.y, u_dashA.z, u_dashA.w,
                                                    u_dashB.x, u_dashB.y, u_dashB.z, u_dashB.w);
                        float edge = 0.0;
                        for (int i = 0; i < 8; i++) {
                            edge += pattern[i];
                            if (t < edge) {
                                if ((i & 1) == 1) discard;
                                break;
                            }
                        }
                    }
                    frag_color = v_color;
                }
            """,
            // Mapbox GL's SDF text: the glyph edge at 0.75, halos widening it by their width.
            "text_fs" to """
                in vec2 v_uv;
                in vec4 v_fill;
                in vec4 v_halo;
                in vec3 v_params;
                uniform sampler2D u_tex;
                uniform float u_isHalo;
                uniform float u_gamma;
                out vec4 frag_color;
                void main() {
                    float fontScale = v_params.z;
                    float dist = texture(u_tex, v_uv).r;
                    vec4 color;
                    float buff;
                    float gamma;
                    if (u_isHalo > 0.5) {
                        if (v_params.x <= 0.0) discard;
                        color = v_halo;
                        buff = (6.0 - v_params.x / fontScale) / 8.0;
                        gamma = (v_params.y * 1.19 / 8.0 + u_gamma) / fontScale;
                    } else {
                        color = v_fill;
                        buff = 0.75;
                        gamma = u_gamma / fontScale;
                    }
                    frag_color = color * smoothstep(buff - gamma, buff + gamma, dist);
                }
            """,
            "icon_fs" to """
                in vec2 v_uv;
                in float v_opacity;
                uniform sampler2D u_tex;
                out vec4 frag_color;
                void main() { frag_color = texture(u_tex, v_uv) * v_opacity; }
            """,
            "marker_fs" to """
                in vec2 v_uv;
                uniform sampler2D u_tex;
                uniform float u_alpha;
                out vec4 frag_color;
                void main() { frag_color = texture(u_tex, v_uv) * u_alpha; }
            """,
            // The engine's flash, `frag_color *= 1 + 1.5 * radius / |d|²`, as `dst * (1 + src)`
            // blending split over passes because the source tops out at 1.
            "flash_fs" to """
                in vec2 v_offset;
                uniform float u_radius;
                uniform float u_height;
                uniform float u_passes;
                out vec4 frag_color;
                void main() {
                    vec3 d = vec3(v_offset, u_height);
                    float factor = 1.0 + 1.5 * u_radius / dot(d, d);
                    frag_color = vec4(vec3(pow(factor, 1.0 / u_passes) - 1.0), 0.0);
                }
            """,
        ).mapValues { HEADER + it.value.trimIndent() } + WeatherShaders.fragment
    }
}
