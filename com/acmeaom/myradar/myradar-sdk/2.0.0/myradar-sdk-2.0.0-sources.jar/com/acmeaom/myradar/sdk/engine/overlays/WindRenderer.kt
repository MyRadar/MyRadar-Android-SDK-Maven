package com.acmeaom.myradar.sdk.engine.overlays

import android.opengl.GLES30
import android.util.Log
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.Mat4
import com.acmeaom.myradar.sdk.engine.camera.ScreenPoint
import com.acmeaom.myradar.sdk.engine.gl.GLContext
import com.acmeaom.myradar.sdk.engine.gl.GPUTexture
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.gl.VertexLayout
import com.acmeaom.myradar.sdk.engine.radar.DataImageDecoder
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.engine.tiles.TileCover
import com.acmeaom.myradar.sdk.engine.tiles.TileID
import com.acmeaom.myradar.sdk.internal.GatewayConfiguration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.FloatBuffer
import java.nio.IntBuffer
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.random.Random

// Wind particles. Port of the engine's `WindParticleModule`, `ParticleVectorBitmapLayer` and
// `ParticlesGraphic`:
//
// - Data: 256-pixel WebP tiles at zooms 1–4 of the surface wind 15-minute slot nearest now,
//   refreshed every 30 minutes. Each pixel holds u (R, G) and v (B, A) as 16-bit fixed point
//   (value × 100 + 32768, in m/s), so the tiles are decoded without premultiplying.
// - Simulation (20 steps a second at most): particles in the engine's Web Mercator meters (y
//   down) move by the bilinearly sampled wind times a zoom-dependent speed factor, age by one a
//   step, and are reseeded evenly across the view when they die. Each step's positions go into
//   one of 84 trail slots, linked into a ribbon of triangles from the last three steps.
// - Drawing: the engine's particle shader (`particle_fs`), colored by speed from the NOAA wind
//   palette (0–50 knots), faded by age and the layer opacity (0.65 by default).

internal data class WindSettings(
    val enabled: Boolean = false,
    val opacity: Float = 0.65f,
)

/** The wind particle layer. Main thread only; [dispose] when the map goes away. */
internal class WindRenderer(private val network: EngineNetwork) {
    var onNeedsDisplay: (() -> Unit)? = null

    var settings = WindSettings()
        set(value) {
            val oldValue = field
            if (value == oldValue) return
            field = value
            if (value.enabled != oldValue.enabled) {
                if (value.enabled) startRefreshing() else stop()
            }
            onNeedsDisplay?.invoke()
        }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    /** Stops loading and releases the particle buffers. */
    fun dispose() {
        scope.cancel()
        simulation = null
    }

    // MARK: Tiles

    /** A decoded wind tile (`ParticleVectorBitmapTile`). Pixels are RGBA with R in the low byte. */
    internal class WindTile(
        val z: Int,
        val x: Int,
        val y: Int,
        val pixels: IntArray,
        val width: Int,
        val height: Int,
    ) {
        private val side: Float get() = MERCATOR_BOUND * 2 / (1 shl z).toFloat()

        fun contains(mx: Float, my: Float): Boolean {
            val side = side
            val ox = x * side - MERCATOR_BOUND
            val oy = y * side - MERCATOR_BOUND
            return mx >= ox && mx < ox + side && my >= oy && my < oy + side
        }

        /** `ParticleVectorBitmapTile::sample`: the wind in m/s, bilinearly interpolated. */
        fun sample(mx: Float, my: Float, out: FloatArray) {
            if (width <= 1 || height <= 1) {
                out[0] = 0f; out[1] = 0f
                return
            }
            val side = side
            val mapWidth = MERCATOR_BOUND * 2
            val oneOverSide = 0.5.pow(z).toFloat()
            val originX = x * oneOverSide * mapWidth - MERCATOR_BOUND
            val originY = (y * oneOverSide - 0.5f) * mapWidth
            var px = (mx - originX) / side * width
            var py = (my - originY) / side * height
            px = maxOf(minOf(px, (width - 1).toFloat()), 0f)
            py = maxOf(minOf(py, (height - 1).toFloat()), 0f)
            val x0 = floor(px).toInt(); val x1 = minOf(ceil(px).toInt(), width - 1)
            val y0 = floor(py).toInt(); val y1 = minOf(ceil(py).toInt(), height - 1)
            val u = px - x0; val v = py - y0
            val p0 = pixels[y0 * width + x0]; val p1 = pixels[y0 * width + x1]
            val p2 = pixels[y1 * width + x0]; val p3 = pixels[y1 * width + x1]
            out[0] = (1 - u) * ((1 - v) * ucomp(p0) + v * ucomp(p2)) + u * ((1 - v) * ucomp(p1) + v * ucomp(p3))
            out[1] = (1 - u) * ((1 - v) * vcomp(p0) + v * vcomp(p2)) + u * ((1 - v) * vcomp(p1) + v * vcomp(p3))
        }

        companion object {
            /** u: (R << 8 | G); value × 100 + 32768, 0 meaning no data. */
            fun ucomp(i: Int): Float {
                val raw = (i and 0xFF) shl 8 or ((i ushr 8) and 0xFF)
                return if (raw == 0) 0f else (raw - 32768) / 100f
            }

            /** v: (B << 8 | A). */
            fun vcomp(i: Int): Float {
                val raw = ((i ushr 16) and 0xFF) shl 8 or ((i ushr 24) and 0xFF)
                return if (raw == 0) 0f else (raw - 32768) / 100f
            }
        }
    }

    private var baseURL: String? = null
    private val tiles = HashMap<TileID, WindTile>()
    private val tileOrder = ArrayList<WindTile>()
    private val loading = HashSet<TileID>()
    private val failed = HashMap<TileID, Double>()
    private var refreshJob: Job? = null

    /**
     * Whether the feed may poll. The map turns it off while it isn't drawing (detached or in the
     * background), which also lets a discarded map be collected.
     */
    var feedsActive = true
        set(value) {
            if (value == field) return
            field = value
            if (!value) {
                refreshJob?.cancel()
                refreshJob = null
            } else if (settings.enabled) {
                startRefreshing()
            }
        }

    private fun startRefreshing() {
        refreshJob?.cancel()
        if (!feedsActive) return
        refreshJob = scope.launch {
            while (isActive) {
                refreshBaseURL()
                delay(REFRESH_INTERVAL_MS)
            }
        }
    }

    private fun stop() {
        refreshJob?.cancel()
        refreshJob = null
        baseURL = null
        tiles.clear()
        tileOrder.clear()
        loading.clear()
        failed.clear()
        simulation = null
    }

    /**
     * `WindParticleModule::formatUrl`: the 15-minute slot nearest now (wind can be requested
     * ahead of time), surface winds ("/z"), time in hex seconds.
     */
    private fun refreshBaseURL() {
        val url = baseURL(System.currentTimeMillis() / 1000.0)
        if (url == baseURL) return
        baseURL = url
        tiles.clear()
        tileOrder.clear()
        loading.clear()
        failed.clear()
        onNeedsDisplay?.invoke()
    }

    private fun requestTiles(transform: MapTransform) {
        val baseURL = baseURL ?: return
        val zoom = transform.zoom.roundToInt().coerceIn(1, 4)
        val wanted = TileCover.tiles(transform, zoom, 64).map { it.canonical }
        for (tile in wanted) {
            if (tiles.containsKey(tile) || tile in loading) continue
            val at = failed[tile]
            if (at != null && System.currentTimeMillis() / 1000.0 - at < 30) continue
            val url = "$baseURL/${tile.z}/${tile.x}/${tile.y}.webp"
            loading.add(tile)
            scope.launch(Dispatchers.Main) {
                val decoded = try {
                    val data = network.data(url)
                    withContext(Dispatchers.Default) { decode(data, tile) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    null
                }
                if (this@WindRenderer.baseURL != baseURL) return@launch
                loading.remove(tile)
                if (decoded != null) {
                    tiles[tile] = decoded
                    // Newest last, as the engine appends; lookups prefer the current zoom anyway.
                    tileOrder.add(decoded)
                    if (tileOrder.size > 128) {
                        val dropped = tileOrder.removeAt(0)
                        tiles.remove(TileID(dropped.z, dropped.x, dropped.y))
                    }
                } else {
                    failed[tile] = System.currentTimeMillis() / 1000.0
                }
            }
        }
    }

    // MARK: Simulation

    /** `ParticlesGraphic`'s buffers and state, sized for the view (in points). */
    private class Simulation(val viewWidth: Double, val viewHeight: Double, private val gl: GLContext) {
        // 30,000 particles for a 2560 × 1440 point view, scaled by area; the preference
        // default of 5000 caps the count the engine settles at.
        val maxParticles = maxOf((30000.0 / (2560 * 1440) * (viewWidth * viewHeight)).toInt(), 1)
        val particles = minOf(5000, maxParticles)
        /** x, y, offset, generation, birth time, prev x, prev y, speed factor per vertex. */
        val vertices = FloatArray(SIM_FRAMES * maxParticles * FLOATS_PER_VERTEX)
        val indices = IntArray(SIM_FRAMES * maxParticles * 3)
        val ages = IntArray(maxParticles) { Random.nextInt(0, 255) }
        var activeFrame = 0
        var simTime = 0
        var lastStep = 0.0

        // `updateAnimationSpace`.
        var sampleOriginX = 0f
        var sampleOriginY = 0f
        var sampleSizeX = 1f
        var sampleSizeY = 1f
        var indexSpaceWidth = 1f
        var indexSpaceHeight = 1f
        var metersPerPoint = 1f

        // The GL copies: the vertex and index buffers, updated by the slots each step changes.
        private val vao = IntArray(1)
        private val buffers = IntArray(2)

        init {
            GLES30.glGenVertexArrays(1, vao, 0)
            GLES30.glGenBuffers(2, buffers, 0)
            GLES30.glBindVertexArray(vao[0])
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, buffers[0])
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vertices.size * 4, FloatBuffer.wrap(vertices),
                GLES30.GL_DYNAMIC_DRAW)
            LAYOUT.apply()
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, buffers[1])
            GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, indices.size * 4, IntBuffer.wrap(indices),
                GLES30.GL_DYNAMIC_DRAW)
            GLES30.glBindVertexArray(0)
        }

        /** Uploads the vertices of trail slot `frame`. */
        fun uploadVertices(frame: Int) {
            val start = frame * maxParticles * FLOATS_PER_VERTEX
            val count = particles * FLOATS_PER_VERTEX
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, buffers[0])
            GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, start * 4, count * 4,
                FloatBuffer.wrap(vertices, start, count))
        }

        /** Uploads the triangles of trail slot `frame`. */
        fun uploadIndices(frame: Int) {
            val start = 3 * frame * particles
            val count = 3 * particles
            GLES30.glBindVertexArray(0)
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, buffers[1])
            GLES30.glBufferSubData(GLES30.GL_ELEMENT_ARRAY_BUFFER, start * 4, count * 4,
                IntBuffer.wrap(indices, start, count))
        }

        fun draw(indexCount: Int) {
            GLES30.glBindVertexArray(vao[0])
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, indexCount, GLES30.GL_UNSIGNED_INT, 0)
        }

        protected fun finalize() {
            gl.deleteLater(GLContext.KIND_VAO, vao[0])
            gl.deleteLater(GLContext.KIND_BUFFER, buffers[0])
            gl.deleteLater(GLContext.KIND_BUFFER, buffers[1])
        }

        companion object {
            const val SIM_FRAMES = 84
            const val FLOATS_PER_VERTEX = 8
            /** Position, offset, generation, birth time, previous position, speed factor. */
            val LAYOUT = VertexLayout(2, 1, 1, 1, 2, 1)
        }
    }

    private var simulation: Simulation? = null
    private val velocity = FloatArray(2)

    /**
     * `ParticlesGraphic::updateAnimationSpace`: the view's bounds in Mercator meters, reseeded
     * evenly with an index grid of the same aspect ratio.
     */
    private fun updateAnimationSpace(sim: Simulation, transform: MapTransform) {
        val w = transform.width
        val h = transform.height
        val projection = transform.projectionMatrix
        val corners = listOf(ScreenPoint(0.0, 0.0), ScreenPoint(w, 0.0), ScreenPoint(0.0, h), ScreenPoint(w, h))
            .mapNotNull { transform.mercatorAt(it, projection) }
        if (corners.isEmpty()) return
        val world = MERCATOR_BOUND.toDouble() * 2
        val xs = corners.map { ((it.x - 0.5) * world).toFloat() }
        val ys = corners.map { ((it.y - 0.5) * world).toFloat() }
        // `FWWrap(x, FWWebMercatorBound)`: into [-bound, bound).
        sim.sampleOriginX = wrap(xs.min())
        sim.sampleOriginY = ys.min()
        sim.sampleSizeX = maxOf(xs.max() - xs.min(), 1f)
        sim.sampleSizeY = maxOf(ys.max() - ys.min(), 1f)
        sim.metersPerPoint = (world / transform.worldSize).toFloat()
        val aspect = sim.sampleSizeX / sim.sampleSizeY
        sim.indexSpaceWidth = sqrt(sim.particles / aspect)
        sim.indexSpaceHeight = sim.particles / sim.indexSpaceWidth
    }

    /** `ParticlesGraphic::animate`: one simulation step. */
    private fun animate(sim: Simulation, lastFrameTimeMs: Int) {
        // `_zoomFactor = FWTransformXYScale(screenToMap) / √2`, where the scale is already meters
        // per point: the engine's particles move √2 slower than the name suggests.
        val zoomFactor = sim.metersPerPoint / sqrt(2f)
        val d = zoomFactor / 2f.pow(6) * 200
        val speedFactor = minOf(lastFrameTimeMs, 100).toFloat() / 1000 * d
        val floats = sim.vertices
        val indices = sim.indices
        val frames = Simulation.SIM_FRAMES
        val prevFrame = sim.activeFrame
        sim.activeFrame = (sim.activeFrame + 1) % frames
        val active = sim.activeFrame
        val prevPrevFrame = (active + frames - 2) % frames
        val nextFrame = (active + 1) % frames
        val nextNextFrame = (active + 2) % frames
        val trailCount = sim.particles
        sim.simTime += 1
        var activeTile: WindTile? = null
        for (i in 0 until sim.particles) {
            val current = (i + sim.maxParticles * active) * 8
            val last = (i + sim.maxParticles * prevFrame) * 8
            System.arraycopy(floats, last, floats, current, 8)
            val currentVertex = i + active * sim.maxParticles
            val prevVertex = i + prevFrame * sim.maxParticles
            val prevPrevVertex = i + prevPrevFrame * sim.maxParticles
            // The next two steps' triangles are the tail of this slot's last generation.
            for (f in intArrayOf(nextFrame, nextNextFrame)) {
                val t = 3 * (i + f * trailCount)
                indices[t] = 0; indices[t + 1] = 0; indices[t + 2] = 0
            }
            val tri = 3 * (i + active * trailCount)
            floats[current + 4] = sim.simTime.toFloat() // birth time
            floats[current + 2] = active.toFloat() // offset
            val offset = (active % 2) * 2 - 1
            val age = sim.ages[i]
            if (age == 1) {
                reseed(sim, floats, current, i)
                floats[current + 3] = (floats[last + 3] + 1) % frames.toFloat() // generation
                indices[tri] = 0; indices[tri + 1] = 0; indices[tri + 2] = 0
                sim.ages[i] = age - 1
            } else if (age == 0) {
                sim.ages[i] = (Random.nextFloat() * 30 + 225).toInt()
                indices[tri] = 0; indices[tri + 1] = 0; indices[tri + 2] = 0
            } else {
                val x = floats[current]
                val y = floats[current + 1]
                // `FWWrap(x, FWWebMercatorBound)`.
                val wrappedX = wrap(x)
                if (activeTile == null || !activeTile.contains(wrappedX, y)) {
                    activeTile = tile(wrappedX, y)
                }
                if (activeTile != null) {
                    activeTile.sample(wrappedX, y, velocity)
                } else {
                    velocity[0] = 0f; velocity[1] = 0f
                }
                floats[current + 5] = x
                floats[current + 6] = y
                floats[current + 0] = x + velocity[0] * speedFactor
                floats[current + 1] = y - velocity[1] * speedFactor
                floats[current + 7] = speedFactor
                sim.ages[i] = age - 1
                if (offset == -1) {
                    indices[tri] = currentVertex; indices[tri + 1] = prevVertex; indices[tri + 2] = prevPrevVertex
                } else {
                    indices[tri] = prevVertex; indices[tri + 1] = currentVertex; indices[tri + 2] = prevPrevVertex
                }
            }
        }
        sim.uploadVertices(active)
        for (f in intArrayOf(active, nextFrame, nextNextFrame)) sim.uploadIndices(f)
    }

    /** The tile for a point: the current zoom's tiles are newest, so search from the end. */
    private fun tile(x: Float, y: Float): WindTile? {
        for (i in tileOrder.indices.reversed()) if (tileOrder[i].contains(x, y)) return tileOrder[i]
        return null
    }

    /** `ParticlesGraphic::reseed` on the flat map: an even spread over the sample space. */
    private fun reseed(sim: Simulation, floats: FloatArray, base: Int, index: Int) {
        val i = index.toFloat()
        val x = (i + Random.nextFloat()) % sim.indexSpaceWidth / sim.indexSpaceWidth * sim.sampleSizeX +
            sim.sampleOriginX
        val y = (i / sim.indexSpaceWidth + Random.nextFloat()) / sim.indexSpaceHeight * sim.sampleSizeY +
            sim.sampleOriginY
        floats[base] = x
        floats[base + 1] = y
    }

    // MARK: Drawing

    /**
     * Steps the simulation (at most 20 times a second) and draws the trails. Returns true while
     * the layer is animating.
     */
    fun draw(context: RenderContext): Boolean {
        if (!settings.enabled) return false
        val transform = context.transform
        requestTiles(transform)
        val existing = simulation
        if (existing == null || existing.viewWidth != transform.width || existing.viewHeight != transform.height) {
            simulation = Simulation(transform.width, transform.height, context.gl)
        }
        val sim = simulation ?: return true
        val palette = palette ?: GPUTexture.rgba(paletteBytes(), PALETTE_WIDTH, 1)?.also { palette = it } ?: return true

        // `simulationLoop`: rate limited to 20 steps a second.
        val now = context.now
        val elapsed = if (sim.lastStep > 0) now - sim.lastStep else 0.05
        if (elapsed >= 0.05) {
            sim.lastStep = now
            updateAnimationSpace(sim, transform)
            if (tileOrder.isNotEmpty()) animate(sim, (elapsed * 1000).toInt())
        }

        val program = context.use("particle_vs", "particle_fs") ?: return true
        // Mercator meters (y down) to clip space.
        val w = MERCATOR_BOUND.toDouble() * 2
        val sizeNdc = 0.5f * sqrt((2 / transform.width.toFloat()).pow(2) + (2 / transform.height.toFloat()).pow(2))
        program.setVec4Array("per_frame_fs_ubo_particle", floatArrayOf(settings.opacity, 0f, 0f, 0f))
        palette.bind(program, 0, "u_palette")
        val projection = transform.projectionMatrix
        val minX = sim.sampleOriginX.toDouble() / w + 0.5
        val maxX = minX + sim.sampleSizeX.toDouble() / w
        program.setFloat("u_size", sizeNdc)
        program.setFloat("u_sim_time", sim.simTime.toFloat())
        program.setFloat("u_trail_decay_rate", 0.9858498f)
        for (wrap in MercatorShapes.visibleWraps(transform, minX, maxX)) {
            val m = projection *
                Mat4.scale(transform.worldSize / w, transform.worldSize / w, 1.0) *
                Mat4.translate(w / 2 + wrap * w, w / 2, 0.0)
            program.setMat4("u_map_to_ndc", m.toFloatArray())
            sim.draw(sim.particles * Simulation.SIM_FRAMES * 3)
        }
        return true
    }

    private var palette: GPUTexture? = null

    companion object {
        /** `FWWebMercatorBound`. */
        const val MERCATOR_BOUND: Float = 20_037_508.342789244f

        private const val REFRESH_INTERVAL_MS = 30 * 60 * 1000L
        private const val PALETTE_WIDTH = 32
        private const val LOG_TAG = "MyRadarSDK"

        /** `FWWrap(x, FWWebMercatorBound)`: into [-bound, bound). */
        private fun wrap(x: Float): Float = x - 2 * MERCATOR_BOUND * floor((x + MERCATOR_BOUND) / (2 * MERCATOR_BOUND))

        /**
         * `WindParticleModule::formatUrl` for a time in seconds since 1970: the 15-minute slot
         * nearest it, in hex seconds, for surface winds.
         */
        fun baseURL(now: Double): String {
            val t = now + 7.5 * 60
            val slot = (t - t % (15 * 60)).toLong()
            return GatewayConfiguration.endpoint("/z" + slot.toString(16).uppercase())
        }

        /** Decodes without premultiplying (`decodeWithoutPremultiply`): the alpha channel is data. */
        fun decode(data: ByteArray, tile: TileID): WindTile? {
            val image = DataImageDecoder.decode(data)
            if (image == null) {
                Log.w(LOG_TAG, "Undecodable wind tile ${tile.z}/${tile.x}/${tile.y}")
                return null
            }
            return windTile(image.bytes, image.width, image.height, tile)
        }

        /** A wind tile from straight RGBA bytes. */
        fun windTile(rgba: ByteArray, width: Int, height: Int, tile: TileID): WindTile {
            val pixels = IntArray(width * height) { p ->
                val o = p * 4
                // As a little-endian 32-bit RGBA pixel: R in the low byte.
                (rgba[o].toInt() and 0xFF) or ((rgba[o + 1].toInt() and 0xFF) shl 8) or
                    ((rgba[o + 2].toInt() and 0xFF) shl 16) or ((rgba[o + 3].toInt() and 0xFF) shl 24)
            }
            return WindTile(tile.z, tile.x, tile.y, pixels, width, height)
        }

        /**
         * `colorForSpeedTable(0)`: the NOAA wind speed colors, 0–50 knots across 32 pixels,
         * premultiplied for drawing. The engine writes the first alpha as `066`, an octal literal: 54.
         */
        fun paletteBytes(): ByteArray {
            val colors = arrayOf(
                floatArrayOf(54f, 219f, 219f, 219f), floatArrayOf(111f, 215f, 151f, 211f),
                floatArrayOf(166f, 216f, 115f, 218f), floatArrayOf(199f, 114f, 30f, 176f),
                floatArrayOf(229f, 28f, 108f, 193f), floatArrayOf(255f, 1f, 218f, 172f),
                floatArrayOf(255f, 1f, 203f, 20f), floatArrayOf(255f, 255f, 213f, 0f),
                floatArrayOf(255f, 255f, 110f, 0f), floatArrayOf(255f, 214f, 17f, 21f),
                floatArrayOf(255f, 148f, 2f, 17f),
            ) // a, r, g, b
            val maxIndex = (colors.size - 1).toFloat()
            val pixels = ByteArray(PALETTE_WIDTH * 4)
            for (i in 0 until PALETTE_WIDTH) {
                val f = (i + 0.5f) / PALETTE_WIDTH * maxIndex
                val lo = f.toInt()
                val hi = if ((lo + 1).toFloat() <= maxIndex) lo + 1 else lo
                val ah = f - lo
                val al = 1 - ah
                fun lerp(a: Float, b: Float) = floor(a * al + b * ah)
                val c = colors[lo]
                val d = colors[hi]
                val a = lerp(c[0], d[0])
                val r = lerp(c[1], d[1]); val g = lerp(c[2], d[2]); val b = lerp(c[3], d[3])
                pixels[i * 4] = (r * a / 255).roundToInt().toByte()
                pixels[i * 4 + 1] = (g * a / 255).roundToInt().toByte()
                pixels[i * 4 + 2] = (b * a / 255).roundToInt().toByte()
                pixels[i * 4 + 3] = a.toInt().toByte()
            }
            return pixels
        }
    }
}
