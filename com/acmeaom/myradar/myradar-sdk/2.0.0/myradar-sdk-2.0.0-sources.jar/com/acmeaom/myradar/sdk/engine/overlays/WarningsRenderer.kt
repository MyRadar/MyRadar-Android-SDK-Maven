package com.acmeaom.myradar.sdk.engine.overlays

import com.acmeaom.myradar.sdk.LatLng
import com.acmeaom.myradar.sdk.engine.basemap.RGBA
import com.acmeaom.myradar.sdk.engine.basemap.jsonObject
import com.acmeaom.myradar.sdk.engine.basemap.jsonObjects
import com.acmeaom.myradar.sdk.engine.basemap.parseJson
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.internal.EngineKeys
import com.acmeaom.myradar.sdk.internal.GatewayConfiguration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/*
 * National Weather Service watches and warnings. Port of the engine's `FWWarnings`: the alerts
 * feed polled every 20 seconds, filtered by phenomenon code, ordered by the NWS map's priority
 * table, each drawn as a fill at half the color's alpha times the layer opacity under a full
 * opacity outline (2.5 points of the alert color over 4.5 points of black). Ordinary warnings
 * draw under the radar; the "topmost" phenomena, PDS and emergency alerts draw above it.
 */

/** What the warnings layer shows, from the map's preferences. */
internal data class WarningsSettings(
    val showWarnings: Boolean = false,
    val showWatches: Boolean = false,
    val fillShapes: Boolean = true,
    val warningsAlpha: Float = 0.4f,
    val watchesAlpha: Float = 0.2f,
    val enabledTags: List<String> = EngineKeys.defaultWarningsTags.split(","),
    val topmostPhenomena: List<String> = "FA,FF,FL,SV,TO,TR,TI,HU,HI,MA,WS,BZ".split(","),
)

/** Draws the warnings layer. Main thread only. */
internal class WarningsRenderer(private val network: EngineNetwork) {
    var onNeedsDisplay: (() -> Unit)? = null

    var settings: WarningsSettings = WarningsSettings()
        set(value) {
            if (value == field) return
            field = value
            if (value.showWarnings || value.showWatches) startPolling() else stopPolling()
            rebuild()
        }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var warnings: List<Warning> = emptyList()
    private var contentHash = 0
    private var pollJob: Job? = null
    private var underRadar: List<Batch> = emptyList()
    /** The warnings drawn, for taps. */
    private var shown: List<Warning> = emptyList()
    private var overRadar: List<Batch> = emptyList()

    private class Batch(val shapes: MercatorShapes, val fillAlpha: Float)

    /** Stops polling. The renderer can't be used afterwards. */
    fun dispose() {
        scope.cancel()
        pollJob = null
    }

    // MARK: Feed

    /**
     * Whether the feed may poll. The map turns it off while it isn't drawing (detached or in the
     * background), which also lets a discarded map be collected.
     */
    var feedsActive = true
        set(value) {
            if (value == field) return
            field = value
            if (!value) stopPolling() else if (settings.showWarnings || settings.showWatches) startPolling()
        }

    private fun startPolling() {
        if (pollJob != null || !feedsActive) return
        pollJob = scope.launch {
            while (isActive) {
                val data = try {
                    network.data(FEED_URL)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    null
                }
                if (data != null) {
                    val hash = data.contentHashCode()
                    val parsed = withContext(Dispatchers.Default) { parse(data) }
                    if (hash != contentHash) {
                        contentHash = hash
                        warnings = parsed
                        rebuild()
                    }
                }
                delay(UPDATE_INTERVAL_MS)
            }
        }
    }

    private fun stopPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    /** One alert from the feed. */
    class Warning(
        val phenomenon: String,
        val significance: String,
        val emphasis: String?,
        /** The alert color, opaque. */
        val color: RGBA,
        val priority: Int,
        /** Polygons (outer ring then holes) in Web Mercator. */
        val polygons: List<List<List<Vec2>>>,
        val properties: Map<String, Any?>,
        /** The GeoJSON feature, as taps report it. */
        val feature: Map<String, Any?>,
    ) {
        val isWatchAdvisoryOrStatement: Boolean
            get() = significance == "A" || significance == "Y" || significance == "S"
        val isWarning: Boolean get() = significance == "W"
    }

    // MARK: Graphics

    /**
     * `FWWarnings::updateGraphics`'s grouping: the alerts shown (by significance switch and tag),
     * split into ordinary warnings, "topmost" warnings, watches, PDS and emergency alerts.
     */
    class Groups(
        val warns: List<Warning>,
        val topmost: List<Warning>,
        val watches: List<Warning>,
        val pds: List<Warning>,
        val emergency: List<Warning>,
    )

    /**
     * `FWWarnings::updateGraphics`: groups, then a batch per group with priorities drawn least
     * important first.
     */
    private fun rebuild() {
        underRadar = emptyList()
        overRadar = emptyList()
        val s = settings
        val g = classify(warnings, s)
        fun batch(group: List<Warning>, alpha: Float): Batch? {
            val first = group.firstOrNull()?.polygons?.firstOrNull()?.firstOrNull()?.firstOrNull() ?: return null
            val builder = MercatorShapeBuilder(first)
            // Higher priority numbers are less important and draw first, underneath.
            val sorted = group.sortedByDescending { it.priority }
            for (w in sorted) {
                // `FWWarning::fillColor`: the color at half alpha, premultiplied.
                val fill = RGBA(w.color.r * 0.5f, w.color.g * 0.5f, w.color.b * 0.5f, 0.5f)
                for (polygon in w.polygons) builder.addFill(polygon, fill)
            }
            for (priority in sorted.map { it.priority }.toSortedSet().reversed()) {
                val level = sorted.filter { it.priority == priority }
                for (w in level) for (polygon in w.polygons) for (ring in polygon) {
                    builder.addLine(ring, 4.5f, RGBA.black, closed = true)
                }
                for (w in level) for (polygon in w.polygons) for (ring in polygon) {
                    builder.addLine(ring, 2.5f, w.color, closed = true)
                }
            }
            return if (builder.isEmpty) null else Batch(MercatorShapes(builder), if (s.fillShapes) alpha else 0f)
        }
        shown = g.warns + g.topmost + g.watches + g.pds + g.emergency
        // Draw order back to front, as the engine's weights put them.
        underRadar = listOfNotNull(batch(g.watches, s.watchesAlpha), batch(g.warns, s.warningsAlpha))
        overRadar = listOfNotNull(batch(g.pds, s.warningsAlpha), batch(g.emergency, s.warningsAlpha),
            batch(g.topmost, s.warningsAlpha))
        onNeedsDisplay?.invoke()
    }

    /** Ordinary warnings and watches, under the radar. */
    fun drawUnderRadar(context: RenderContext) {
        for (batch in underRadar) batch.shapes.draw(context, fillOpacity = batch.fillAlpha)
    }

    /** Topmost, PDS and emergency alerts, over the radar. */
    fun drawOverRadar(context: RenderContext) {
        for (batch in overRadar) batch.shapes.draw(context, fillOpacity = batch.fillAlpha)
    }

    /**
     * The warnings under a point, as their GeoJSON features with `"object_type": "warning"`
     * (the engine's hit results).
     */
    fun features(mercator: Vec2): List<Map<String, Any?>> = hits(shown, mercator)

    companion object {
        private val FEED_URL = GatewayConfiguration.endpoint("/live/alerts/v2/geojson")
        private const val UPDATE_INTERVAL_MS = 20_000L

        fun parse(data: ByteArray): List<Warning> {
            val json = jsonObject(parseJson(data)) ?: return emptyList()
            val features = jsonObjects(json["features"]) ?: return emptyList()
            return features.mapNotNull { feature -> parseFeature(feature) }
        }

        private fun parseFeature(feature: Map<String, Any?>): Warning? {
            val properties = jsonObject(feature["properties"]) ?: return null
            val geometry = jsonObject(feature["geometry"]) ?: return null
            val type = geometry["type"] as? String ?: return null
            val coordinates = geometry["coordinates"] ?: return null
            val polygons: List<List<List<Vec2>>> = when (type) {
                "Polygon" -> listOf((coordinates as? List<*> ?: emptyList<Any?>()).map(::ring))
                "MultiPolygon" -> (coordinates as? List<*> ?: emptyList<Any?>()).map { polygon ->
                    (polygon as? List<*> ?: emptyList<Any?>()).map(::ring)
                }
                else -> return null
            }
            // `FWColor::colorFromSloppyColorFormatString`, with alpha forced opaque.
            var hex = (properties["color"] as? String ?: "000000").trim()
            if (hex.startsWith("#")) hex = hex.substring(1)
            val color = (RGBA.fromCss("#$hex") ?: RGBA.black).copy(a = 1f)
            val priority = PRIORITIES[hex.uppercase()] ?: LEAST_PRIORITY
            return Warning(
                phenomenon = properties["phenomenon"] as? String ?: "",
                significance = properties["significance"] as? String ?: "",
                emphasis = properties["emphasis"] as? String,
                color = color,
                priority = priority,
                polygons = polygons,
                properties = properties,
                feature = feature,
            )
        }

        /** A GeoJSON ring in Web Mercator; empty unless every position is a list of numbers. */
        private fun ring(raw: Any?): List<Vec2> {
            val positions = raw as? List<*> ?: return emptyList()
            val result = ArrayList<Vec2>(positions.size)
            for (position in positions) {
                val c = position as? List<*> ?: return emptyList()
                if (c.any { it !is Double }) return emptyList()
                if (c.size >= 2) result.add(MapTransform.mercator(LatLng(c[1] as Double, c[0] as Double)))
            }
            return result
        }

        fun classify(warnings: List<Warning>, s: WarningsSettings): Groups {
            val wildcard = s.enabledTags.contains("nws.*")
            fun shouldShow(w: Warning): Boolean {
                if (w.isWatchAdvisoryOrStatement && !s.showWatches) return false
                if (w.isWarning && !s.showWarnings) return false
                if (wildcard) return true
                return s.enabledTags.contains("nws.${w.phenomenon}.${w.significance}".lowercase())
            }
            val warns = ArrayList<Warning>(); val topmost = ArrayList<Warning>(); val watches = ArrayList<Warning>()
            val pds = ArrayList<Warning>(); val emergency = ArrayList<Warning>()
            for (w in warnings) {
                if (!shouldShow(w)) continue
                when {
                    w.emphasis == "PDS" -> pds.add(w)
                    w.emphasis == "EMERGENCY" -> emergency.add(w)
                    w.isWarning -> if (s.topmostPhenomena.contains(w.phenomenon)) topmost.add(w) else warns.add(w)
                    w.isWatchAdvisoryOrStatement -> watches.add(w)
                }
            }
            return Groups(warns, topmost, watches, pds, emergency)
        }

        /** The features of `warnings` with a polygon under `mercator` (tried one world either side). */
        fun hits(warnings: List<Warning>, mercator: Vec2): List<Map<String, Any?>> = warnings.filter { w ->
            w.polygons.any { polygon ->
                val outer = polygon.firstOrNull() ?: return@any false
                doubleArrayOf(-1.0, 0.0, 1.0).any { wrap ->
                    val p = mercator + Vec2(wrap, 0.0)
                    AnnotationsRenderer.contains(outer, p) &&
                        polygon.drop(1).none { AnnotationsRenderer.contains(it, p) }
                }
            }
        }.map { w -> w.feature + ("object_type" to "warning") }

        /**
         * Priority by alert color, from the NWS map (https://www.weather.gov/help-map), as the
         * engine builds its table.
         */
        const val LEAST_PRIORITY = 60
        val PRIORITIES: Map<String, Int> = run {
            val table = listOf(
                1 to "FD6347", 2 to "FF0000", 3 to "FF8C00", 4 to "FFA500", 5 to "8B0000", 6 to "8B0000",
                7 to "00FFFF", 8 to "FA8072", 9 to "7FFF00", 10 to "FFB6C1", 11 to "4B0082", 12 to "4B0082",
                13 to "4B0082", 14 to "A0522D", 15 to "1E90FF", 16 to "FFB6C1", 17 to "C0C0C0", 18 to "B524F7",
                19 to "CD5C5C", 20 to "DC143C", 21 to "DC143C", 22 to "FFA500", 23 to "FF4500", 24 to "C71585",
                25 to "8B008B", 26 to "FF69B4", 27 to "DAA520", 28 to "B22222", 29 to "9400D3", 30 to "D2691E",
                31 to "FF00FF", 32 to "1E90FF", 33 to "8B4513", 34 to "2F4F4F", 35 to "A9A9A9", 36 to "228B22",
                37 to "228B22", 38 to "00FF00", 39 to "228B22", 40 to "FFE4C4", 41 to "FFE4C4", 42 to "008B8B",
                43 to "C71585", 44 to "FFFF00", 45 to "DB7093", 46 to "2E8B57", 47 to "DDA0DD", 48 to "00FF00",
                49 to "B0C4DE", 50 to "0000FF", 51 to "9400D3", 52 to "483D8B", 53 to "FF1493", 54 to "DB7FF7",
                55 to "FF00FF", 56 to "9932CC", 57 to "FF00FF",
            )
            // Like the engine's map, a color listed twice keeps its last priority.
            val result = HashMap<String, Int>()
            for ((priority, hex) in table) result[hex] = priority
            result
        }
    }
}
