package com.acmeaom.myradar.sdk.engine.basemap

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.acmeaom.myradar.sdk.engine.camera.Mat4
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.gl.BlendMode
import com.acmeaom.myradar.sdk.engine.gl.GPUMesh
import com.acmeaom.myradar.sdk.engine.gl.GPUTexture
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.gl.StencilMode
import com.acmeaom.myradar.sdk.engine.gl.VertexLayout
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.engine.tiles.TileCache
import com.acmeaom.myradar.sdk.engine.tiles.TileCover
import com.acmeaom.myradar.sdk.engine.tiles.TileID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** A vector tile's GPU geometry, per style layer. */
internal class VectorTileData(val extent: Float) {
    val fills = HashMap<String, GPUMesh>()
    val lines = HashMap<String, GPUMesh>()
    /** Features of each symbol layer (by layer id), filtered, for label placement. */
    var symbols: Map<String, List<VectorTileFeature>> = emptyMap()
    /** Each symbol layer's label candidates, worked out once: a tile's style zoom never changes. */
    val labelCandidates = HashMap<String, List<LabelRenderer.LabelCandidate>>()
}

/** CPU-side geometry for a vector tile, built off the main thread. */
internal class VectorTileBuild {
    var extent = 4096f
    val fills = HashMap<String, FillGeometry>()
    val lines = HashMap<String, LineGeometry>()
    /** Features of each symbol layer (by layer id), for label placement. */
    val symbols = HashMap<String, List<VectorTileFeature>>()
}

/**
 * Draws a base map style: loads the style and its sources, keeps a cache of tiles per source,
 * builds tile geometry off the main thread and draws background, fill, line and raster layers in
 * style order. Each tile's drawing is clipped to its own square with the stencil buffer, so the
 * buffer around vector tile geometry never draws twice, and a tile that's still loading is
 * covered by its nearest loaded ancestor.
 */
internal class BasemapRenderer(private val network: EngineNetwork) {
    /** Called on the main thread whenever something new is ready to draw. */
    var onNeedsDisplay: (() -> Unit)? = null

    var style: MapStyleSheet? = null; private set
    private var labels: LabelRenderer? = null

    /** Multiplies label text and icon sizes. */
    var textScale = 1f
        set(value) {
            field = value
            labels?.textScale = value
        }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var styleUrl: String? = null
    private var styleJob: Job? = null

    private val vectorTiles = HashMap<String, TileCache<VectorTileData>>()
    private val rasterTiles = HashMap<String, TileCache<GPUTexture>>()
    private var lastRenderSets: Map<String, List<TileID>> = emptyMap()

    private val unitQuad by lazy {
        GPUMesh.create(floatArrayOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f), intArrayOf(0, 1, 2, 0, 2, 3), POSITION_LAYOUT)
    }

    fun dispose() {
        scope.cancel()
    }

    // MARK: Style loading

    fun load(url: String) {
        if (url == styleUrl) return
        styleUrl = url
        styleJob?.cancel()
        style = null
        labels = null
        vectorTiles.values.forEach { it.removeAll() }
        rasterTiles.values.forEach { it.removeAll() }
        vectorTiles.clear()
        rasterTiles.clear()
        styleJob = scope.launch {
            val sheet = runCatching { MapStyleSheet.parse(network.data(url)) }.getOrNull()
            if (sheet == null) {
                Log.w(LOG_TAG, "Couldn't load the base map style $url")
                return@launch
            }
            for ((id, source) in sheet.sources.toList()) {
                val tileJson = source.tileJsonUrl ?: continue
                val data = runCatching { network.data(tileJson) }.getOrNull() ?: continue
                sheet.resolve(id, data)
            }
            ensureActive()
            if (styleUrl != url) return@launch
            style = sheet
            labels = LabelRenderer(network, sheet).also {
                it.onNeedsDisplay = { onNeedsDisplay?.invoke() }
                it.textScale = textScale
            }
            onNeedsDisplay?.invoke()
        }
    }

    // MARK: Drawing

    /** The background color of the current style, for clearing the frame. */
    fun clearColor(cameraZoom: Double): RGBA {
        val zoom = vectorTileZoom(cameraZoom, 0, 14) + STYLE_ZOOM_OFFSET
        val layer = style?.layers?.firstOrNull { it.kind == StyleLayerKind.BACKGROUND }
            ?: return RGBA(0.1f, 0.1f, 0.12f, 1f)
        val color = layer.backgroundColor?.evaluate(zoom) ?: RGBA.black
        val opacity = (layer.backgroundOpacity?.evaluate(zoom) ?: 1.0).toFloat()
        return RGBA(color.r, color.g, color.b, color.a * opacity)
    }

    /** Draws every layer of the style. */
    fun draw(context: RenderContext) {
        val style = style ?: return
        val transform = context.transform
        val styleZoom = transform.styleZoom
        val projection = transform.projectionMatrix

        // Work out which tiles each source draws this frame, and request what's missing.
        val renderSets = HashMap<String, List<TileID>>()
        for ((id, source) in style.sources) {
            if (source.tiles.isEmpty()) continue
            when (source.kind) {
                StyleSourceKind.VECTOR -> renderSets[id] = renderSetVector(source, transform)
                StyleSourceKind.RASTER -> renderSets[id] = renderSetRaster(source, transform)
                StyleSourceKind.GEOJSON -> Unit
            }
        }
        lastRenderSets = renderSets

        var clippedSource: String? = null
        for (layer in style.layers) {
            if (!layer.visible) continue
            when (layer.kind) {
                // The background is the clear color; symbols are drawn by the label renderer.
                StyleLayerKind.BACKGROUND, StyleLayerKind.SYMBOL -> continue
                StyleLayerKind.FILL, StyleLayerKind.LINE, StyleLayerKind.RASTER -> {
                    val sourceId = layer.source ?: continue
                    val tiles = renderSets[sourceId] ?: continue
                    if (tiles.isEmpty()) continue
                    if (clippedSource != sourceId) {
                        writeClipMasks(context, tiles, projection)
                        clippedSource = sourceId
                    }
                    for ((index, tile) in tiles.withIndex()) {
                        // Vector layers show by the tile's style zoom; raster layers by the camera's.
                        val zoom = if (layer.kind == StyleLayerKind.RASTER) styleZoom else styleZoom(tile)
                        if (!layer.isVisible(zoom)) continue
                        val reference = index + 1
                        when (layer.kind) {
                            StyleLayerKind.FILL -> drawFill(context, layer, tile, sourceId, projection, reference)
                            StyleLayerKind.LINE -> drawLine(context, layer, tile, sourceId, projection, reference)
                            StyleLayerKind.RASTER -> drawRaster(context, layer, tile, sourceId, projection, reference)
                            else -> Unit
                        }
                    }
                }
            }
        }
    }

    /**
     * Draws the style's labels for the vector tiles drawn this frame. Call after everything that
     * labels should sit on top of. Returns true while labels are fading in or out.
     */
    fun drawLabels(context: RenderContext): Boolean {
        val style = style ?: return false
        val labels = labels ?: return false
        val tiles = HashMap<String, List<Pair<TileID, VectorTileData>>>()
        for ((id, source) in style.sources) {
            if (source.kind != StyleSourceKind.VECTOR) continue
            val cache = vectorTiles[id] ?: continue
            tiles[id] = lastRenderSets[id]?.mapNotNull { tile -> cache.peek(tile.canonical)?.let { tile to it } }.orEmpty()
        }
        return labels.draw(context, style, tiles)
    }

    /**
     * Writes each tile's index + 1 into the stencil buffer over its square, lowest zoom first so a
     * fallback ancestor only keeps the area its loaded descendants don't cover. Clears the stencil
     * first.
     */
    private fun writeClipMasks(context: RenderContext, tiles: List<TileID>, projection: Mat4) {
        val quad = unitQuad ?: return
        context.clearStencil()
        for ((index, tile) in tiles.withIndex()) {
            val program = context.use("basemap_fill_vs", "solid_fs", BlendMode.NONE, StencilMode.WRITE, index + 1) ?: return
            program.setMat4("u_matrix", context.transform.tileMatrix(tile.z, tile.x, tile.y, tile.wrap, 1.0, projection))
            program.setVec4("u_color", 0f, 0f, 0f, 0f)
            quad.draw()
        }
    }

    /** Tile units per screen point for a tile at the current zoom. */
    private fun unitsPerPoint(tile: TileID, extent: Float, transform: MapTransform): Float {
        val tilePoints = transform.worldSize / 2.0.pow(tile.z)
        return extent / tilePoints.toFloat()
    }

    private fun drawFill(context: RenderContext, layer: StyleLayer, tile: TileID, source: String, projection: Mat4,
                         reference: Int) {
        val data = vectorTiles[source]?.peek(tile.canonical) ?: return
        val mesh = data.fills[layer.id] ?: return
        val zoom = styleZoom(tile)
        val color = (layer.fillColor?.evaluate(zoom) ?: RGBA.black)
            .premultiplied((layer.fillOpacity?.evaluate(zoom) ?: 1.0).toFloat())
        val program = context.use("basemap_fill_vs", "solid_fs", stencil = StencilMode.TEST_EQUAL, reference = reference)
            ?: return
        program.setMat4("u_matrix", context.transform.tileMatrix(tile.z, tile.x, tile.y, tile.wrap,
            data.extent.toDouble(), projection))
        program.setVec4("u_color", color.r, color.g, color.b, color.a)
        mesh.draw()
    }

    private fun drawLine(context: RenderContext, layer: StyleLayer, tile: TileID, source: String, projection: Mat4,
                         reference: Int) {
        val data = vectorTiles[source]?.peek(tile.canonical) ?: return
        val mesh = data.lines[layer.id] ?: return
        val zoom = styleZoom(tile)
        val color = (layer.lineColor?.evaluate(zoom) ?: RGBA.black)
            .premultiplied((layer.lineOpacity?.evaluate(zoom) ?: 1.0).toFloat())
        val width = (layer.lineWidth?.evaluate(zoom) ?: 1.0).toFloat()
        val units = unitsPerPoint(tile, data.extent, context.transform)
        // Dash lengths are in line widths; the shader works in tile units.
        val dash = FloatArray(4)
        var total = 0f
        val pattern = layer.lineDashArray?.evaluate(zoom)
        if (pattern != null && pattern.size >= 2) {
            val scale = max(width, 1f) * units
            for ((i, value) in pattern.take(4).withIndex()) {
                dash[i] = value.toFloat() * scale
                total += dash[i]
            }
            if (pattern.size % 2 == 1) total = 0f
        }
        val program = context.use("basemap_line_vs", "line_fs", stencil = StencilMode.TEST_EQUAL, reference = reference)
            ?: return
        program.setMat4("u_matrix", context.transform.tileMatrix(tile.z, tile.x, tile.y, tile.wrap,
            data.extent.toDouble(), projection))
        program.setFloat("u_halfwidth", max(width, 0.5f) / 2 * units)
        program.setVec4("u_color", color.r, color.g, color.b, color.a)
        program.setVec4("u_dash", dash[0], dash[1], dash[2], dash[3])
        program.setFloat("u_dashTotal", total)
        mesh.draw()
    }

    private fun drawRaster(context: RenderContext, layer: StyleLayer, tile: TileID, source: String, projection: Mat4,
                           reference: Int) {
        val texture = rasterTiles[source]?.peek(tile.canonical) ?: return
        val quad = unitQuad ?: return
        val opacity = (layer.rasterOpacity?.evaluate(context.transform.styleZoom) ?: 1.0).toFloat()
        if (opacity <= 0) return
        val program = context.use("raster_vs", "raster_fs", stencil = StencilMode.TEST_EQUAL, reference = reference)
            ?: return
        program.setMat4("u_matrix", context.transform.tileMatrix(tile.z, tile.x, tile.y, tile.wrap, 1.0, projection))
        program.setFloat("u_opacity", opacity)
        texture.bind(program, 0, "u_tex")
        quad.draw()
    }

    // MARK: Tile sets

    private fun renderSetVector(source: StyleSource, transform: MapTransform): List<TileID> {
        val z = vectorTileZoom(transform.zoom, source.minZoom, source.maxZoom)
        val cache = vectorTiles.getOrPut(source.id) { TileCache(160) }
        return renderSet(TileCover.tiles(transform, z), cache) { loadVectorTile(it, source) }
    }

    private fun renderSetRaster(source: StyleSource, transform: MapTransform): List<TileID> {
        val z = floor(transform.styleZoom + log2(512 / source.tileSize)).toInt().coerceIn(source.minZoom, source.maxZoom)
        val cache = rasterTiles.getOrPut(source.id) { TileCache(120) }
        return renderSet(TileCover.tiles(transform, z), cache) { loadRasterTile(it, source) }
    }

    /**
     * The ideal tiles that are loaded, plus loaded ancestors standing in for the rest, lowest zoom
     * first. Requests the ideal tiles that aren't loaded yet.
     */
    private fun <T : Any> renderSet(ideal: List<TileID>, cache: TileCache<T>, load: (TileID) -> Unit): List<TileID> {
        val result = ArrayList<TileID>()
        val included = HashSet<TileID>()
        cache.retainOnly(ideal.mapTo(HashSet()) { it.canonical })
        for (tile in ideal) {
            if (cache[tile.canonical] != null) {
                if (included.add(tile)) result.add(tile)
                continue
            }
            if (!cache.isLoading(tile.canonical)) load(tile.canonical)
            var ancestor = tile.parent
            var depth = 0
            while (ancestor != null && depth < 6) {
                if (cache[ancestor.canonical] != null) {
                    if (included.add(ancestor)) result.add(ancestor)
                    break
                }
                ancestor = ancestor.parent
                depth++
            }
        }
        return result.sortedBy { it.z }
    }

    private fun loadVectorTile(tile: TileID, source: StyleSource) {
        val template = source.tiles.firstOrNull() ?: return
        val style = style ?: return
        val cache = vectorTiles[source.id] ?: return
        val wanted = style.sourceLayers(source.id)
        val layers = style.layers.filter {
            it.source == source.id &&
                (it.kind == StyleLayerKind.FILL || it.kind == StyleLayerKind.LINE || it.kind == StyleLayerKind.SYMBOL)
        }
        val job = scope.launch {
            val data = runCatching { network.data(tile.url(template)) }.getOrNull()
            if (data == null) {
                vectorTiles[source.id]?.failed(tile)
                return@launch
            }
            val build = withContext(Dispatchers.Default) { build(tile, data, layers, wanted) }
            ensureActive()
            val tileData = VectorTileData(build.extent)
            for ((id, g) in build.fills) {
                GPUMesh.create(g.vertices.toArray(), g.indices.toArray(), POSITION_LAYOUT)?.let { tileData.fills[id] = it }
            }
            for ((id, g) in build.lines) {
                GPUMesh.create(g.vertices.toArray(), g.indices.toArray(), LINE_LAYOUT)?.let { tileData.lines[id] = it }
            }
            tileData.symbols = build.symbols
            vectorTiles[source.id]?.store(tile, tileData)
            onNeedsDisplay?.invoke()
        }
        cache.loading(tile, job)
    }

    private fun loadRasterTile(tile: TileID, source: StyleSource) {
        val template = source.tiles.firstOrNull() ?: return
        val cache = rasterTiles[source.id] ?: return
        val job = scope.launch {
            val image = runCatching {
                val data = network.data(tile.url(template))
                withContext(Dispatchers.Default) { RGBAImage.decode(data) }
            }.getOrNull()
            if (image == null) {
                rasterTiles[source.id]?.failed(tile)
                return@launch
            }
            ensureActive()
            val texture = GPUTexture.rgba(image.bytes, image.width, image.height, mipmaps = true)
            if (texture == null) {
                rasterTiles[source.id]?.failed(tile)
                return@launch
            }
            rasterTiles[source.id]?.store(tile, texture)
            onNeedsDisplay?.invoke()
        }
        cache.loading(tile, job)
    }

    companion object {
        private const val LOG_TAG = "MyRadarSDK"
        val POSITION_LAYOUT = VertexLayout(2)
        val LINE_LAYOUT = VertexLayout(2, 2, 1)

        /**
         * The engine evaluates a style at a vector tile's zoom plus this (`VectorTile::ZOOM_OFFSET`),
         * the same for the whole tile.
         */
        const val STYLE_ZOOM_OFFSET = 1.1

        /**
         * The vector tile zoom the engine draws at a camera zoom: tiles split once they'd cover more
         * than 2 × (512√2 × 0.95)² points (`VectorTileLayer` edge length, `FWQuadTreeTiledLayer` area rule).
         */
        fun vectorTileZoom(cameraZoom: Double, minZoom: Int, maxZoom: Int): Int {
            val edge = 512 * sqrt(2.0) * 0.95
            val z = ceil(cameraZoom - ln(edge * sqrt(2.0) / 256) / ln(2.0)).toInt()
            return min(max(z, max(minZoom, 3)), maxZoom)
        }

        fun styleZoom(tile: TileID): Double = tile.z + STYLE_ZOOM_OFFSET

        /** Decodes a vector tile and builds the geometry of every fill and line layer that uses it. */
        fun build(tile: TileID, data: ByteArray, layers: List<StyleLayer>, wanted: Set<String>): VectorTileBuild {
            val build = VectorTileBuild()
            val decoded = VectorTileDecoder.decode(data, wanted)
            build.extent = decoded.values.firstOrNull()?.extent ?: 4096f
            val tileZoom = styleZoom(tile)
            for (layer in layers) {
                val vt = layer.sourceLayer?.let { decoded[it] } ?: continue
                // The engine evaluates a whole tile at one style zoom; past the source's max zoom the
                // same tile is drawn at higher camera zooms, but still at that style zoom.
                if (!layer.isVisible(tileZoom)) continue
                when (layer.kind) {
                    StyleLayerKind.FILL -> {
                        val geometry = FillGeometry()
                        for (f in vt.features) {
                            if (f.type == GeometryType.POLYGON && layer.filter.matches(f.properties, f.type, f.id)) {
                                geometry.add(f.geometry)
                            }
                        }
                        if (!geometry.isEmpty) build.fills[layer.id] = geometry
                    }
                    StyleLayerKind.LINE -> {
                        val join = LineJoin.of(layer.lineJoin?.evaluate(tileZoom))
                        val cap = LineCap.of(layer.lineCap?.evaluate(tileZoom))
                        val geometry = LineGeometry()
                        for (f in vt.features) {
                            if (f.type == GeometryType.POINT || !layer.filter.matches(f.properties, f.type, f.id)) continue
                            for (line in f.geometry) geometry.add(line, join, cap, layer.lineMiterLimit.toFloat())
                        }
                        if (!geometry.isEmpty) build.lines[layer.id] = geometry
                    }
                    StyleLayerKind.SYMBOL -> {
                        val matching = vt.features.filter { layer.filter.matches(it.properties, it.type, it.id) }
                        if (matching.isNotEmpty()) build.symbols[layer.id] = matching
                    }
                    else -> Unit
                }
            }
            return build
        }
    }
}

/** Decoded 8-bit RGBA pixels (premultiplied) from an image file. */
internal class RGBAImage(val bytes: ByteArray, val width: Int, val height: Int) {
    companion object {
        fun decode(data: ByteArray): RGBAImage? {
            val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val bitmap = BitmapFactory.decodeByteArray(data, 0, data.size, options) ?: return null
            val argb = if (bitmap.config == Bitmap.Config.ARGB_8888) bitmap else bitmap.copy(Bitmap.Config.ARGB_8888, false)
            // ARGB_8888 is R, G, B, A in memory, premultiplied.
            val buffer = ByteBuffer.allocate(argb.byteCount)
            argb.copyPixelsToBuffer(buffer)
            return RGBAImage(buffer.array(), argb.width, argb.height)
        }
    }
}
