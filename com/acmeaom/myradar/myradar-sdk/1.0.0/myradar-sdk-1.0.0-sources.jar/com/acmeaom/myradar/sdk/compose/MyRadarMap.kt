package com.acmeaom.myradar.sdk.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.acmeaom.myradar.sdk.CoordinateRegion
import com.acmeaom.myradar.sdk.MapCamera
import com.acmeaom.myradar.sdk.MapMarker
import com.acmeaom.myradar.sdk.MapPolygon
import com.acmeaom.myradar.sdk.MapPolyline
import com.acmeaom.myradar.sdk.MapStyle
import com.acmeaom.myradar.sdk.MyRadarMapListener
import com.acmeaom.myradar.sdk.MyRadarMapView
import com.acmeaom.myradar.sdk.Overlay
import com.acmeaom.myradar.sdk.RadarProduct
import java.util.Date

/**
 * A Jetpack Compose map displaying MyRadar base maps, animated radar and data overlays.
 *
 * Every parameter describes the desired state; the map is updated whenever a value changes.
 * Camera parameters ([camera], [visibleRegion]) move the map only when their value changes, so
 * the user can pan freely in between.
 *
 * ```kotlin
 * MyRadarMap(
 *     modifier = Modifier.fillMaxSize(),
 *     initialCamera = MapCamera(LatLng(35.22, -97.44), zoom = 6f),
 *     overlays = setOf(Overlay.Warnings, Overlay.Lightning),
 * )
 * ```
 *
 * @param initialCamera Where the map starts. Applied once, when the map is created.
 * @param radarOpacity The radar layer opacity, or `null` for the SDK default.
 * @param overlays The overlays to show. Overlays not in the set are hidden.
 * @param overlayOpacities Opacity per overlay; overlays not in the map keep their current opacity.
 * @param camera When non-null and changed, moves the map to this center and zoom.
 * @param visibleRegion When non-null and changed, fits the map to this region.
 * @param scrubberPosition When non-null and changed by the app, pauses the radar on that position.
 * @param onScrubberPositionChange Receives the engine's playhead as the animation plays.
 * @param onMapViewCreated Gives access to the underlying [MyRadarMapView] for anything not
 *   covered by the parameters, such as snapshots.
 */
@Composable
public fun MyRadarMap(
    modifier: Modifier = Modifier,
    initialCamera: MapCamera? = null,
    mapStyle: MapStyle = MapStyle.Gray,
    radarProduct: RadarProduct = RadarProduct.Radar,
    radarEnabled: Boolean = true,
    radarPlaying: Boolean = true,
    radarOpacity: Float? = null,
    overlays: Set<Overlay> = emptySet(),
    overlayOpacities: Map<Overlay, Float> = emptyMap(),
    polygons: List<MapPolygon> = emptyList(),
    polylines: List<MapPolyline> = emptyList(),
    markers: List<MapMarker> = emptyList(),
    camera: MapCamera? = null,
    cameraAnimated: Boolean = true,
    visibleRegion: CoordinateRegion? = null,
    visibleRegionAnimated: Boolean = true,
    scrubberPosition: Float? = null,
    onScrubberPositionChange: ((Float) -> Unit)? = null,
    onRadarFrame: ((Date?) -> Unit)? = null,
    onMarkerTap: ((MapMarker) -> Unit)? = null,
    onPolylineTap: ((MapPolyline) -> Unit)? = null,
    onPolygonTap: ((MapPolygon) -> Unit)? = null,
    onMapStoppedMoving: ((MyRadarMapView) -> Unit)? = null,
    onMapViewCreated: ((MyRadarMapView) -> Unit)? = null,
) {
    val state = remember { AppliedState() }

    // Callbacks are read through State so the listener always calls the latest lambdas.
    val currentOnScrubber = rememberUpdatedState(onScrubberPositionChange)
    val currentOnRadarFrame = rememberUpdatedState(onRadarFrame)
    val currentOnMarkerTap = rememberUpdatedState(onMarkerTap)
    val currentOnPolylineTap = rememberUpdatedState(onPolylineTap)
    val currentOnPolygonTap = rememberUpdatedState(onPolygonTap)
    val currentOnStopped = rememberUpdatedState(onMapStoppedMoving)

    AndroidView(
        modifier = modifier,
        factory = { context ->
            MyRadarMapView(context).apply {
                initialCamera?.let { setCenter(it.center, it.zoom, animated = false) }
                listener = object : MyRadarMapListener {
                    override fun onRadarFrame(mapView: MyRadarMapView, date: Date?) {
                        currentOnRadarFrame.value?.invoke(date)
                    }

                    override fun onRadarScrubberPosition(mapView: MyRadarMapView, position: Float) {
                        state.lastReportedScrubber = position
                        currentOnScrubber.value?.invoke(position)
                    }

                    override fun onMarkerTap(mapView: MyRadarMapView, marker: MapMarker) {
                        currentOnMarkerTap.value?.invoke(marker)
                    }

                    override fun onPolylineTap(mapView: MyRadarMapView, polyline: MapPolyline) {
                        currentOnPolylineTap.value?.invoke(polyline)
                    }

                    override fun onPolygonTap(mapView: MyRadarMapView, polygon: MapPolygon) {
                        currentOnPolygonTap.value?.invoke(polygon)
                    }

                    override fun onMapStoppedMoving(mapView: MyRadarMapView) {
                        currentOnStopped.value?.invoke(mapView)
                    }
                }
                onMapViewCreated?.invoke(this)
            }
        },
        update = { mapView ->
            if (mapView.mapStyle != mapStyle) mapView.mapStyle = mapStyle
            if (mapView.radar.isEnabled != radarEnabled) mapView.radar.isEnabled = radarEnabled
            if (mapView.radar.product != radarProduct) mapView.radar.product = radarProduct
            if (radarOpacity != null && mapView.radar.opacity != radarOpacity) mapView.radar.opacity = radarOpacity

            // Only apply play/pause when the requested value changes, so scrubbing (which
            // pauses engine-side) is not immediately overridden.
            if (state.lastAppliedPlaying != radarPlaying) {
                state.lastAppliedPlaying = radarPlaying
                mapView.radar.isPlaying = radarPlaying
            }
            if (state.lastAppliedOverlays != overlays) {
                for (overlay in Overlay.entries) {
                    mapView.setOverlay(overlay, overlay in overlays)
                }
                state.lastAppliedOverlays = overlays
            }
            if (state.lastAppliedOverlayOpacities != overlayOpacities) {
                for ((overlay, opacity) in overlayOpacities) {
                    mapView.setOpacity(opacity, overlay)
                }
                state.lastAppliedOverlayOpacities = overlayOpacities
            }

            // The setters compare against the current value, so these are cheap when unchanged.
            mapView.polygons = polygons
            mapView.polylines = polylines
            mapView.markers = markers

            // Push scrubber values that originate in the app (for example a Slider).
            if (scrubberPosition != null && scrubberPosition != state.lastReportedScrubber) {
                state.lastReportedScrubber = scrubberPosition
                mapView.radar.scrubberPosition = scrubberPosition
            }

            // Move the camera only when the requested region or camera changes.
            if (visibleRegion != state.lastAppliedRegion) {
                state.lastAppliedRegion = visibleRegion
                visibleRegion?.let { mapView.setVisibleRegion(it, visibleRegionAnimated) }
            }
            if (camera != state.lastAppliedCamera) {
                state.lastAppliedCamera = camera
                camera?.let { mapView.setCenter(it.center, it.zoom, cameraAnimated) }
            }
        },
    )
}

/** Values last pushed to the map view, so updates are applied only when they change. */
private class AppliedState {
    var lastAppliedPlaying: Boolean? = null
    var lastAppliedOverlays: Set<Overlay>? = null
    var lastAppliedOverlayOpacities: Map<Overlay, Float>? = null
    var lastReportedScrubber: Float? = null
    var lastAppliedRegion: CoordinateRegion? = null
    var lastAppliedCamera: MapCamera? = null
}
