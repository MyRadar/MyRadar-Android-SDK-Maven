package com.acmeaom.myradar.sdk

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import androidx.annotation.Keep
import androidx.annotation.MainThread
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.findViewTreeLifecycleOwner
import com.acmeaom.android.tectonic.android.TectonicMapSurfaceView
import com.acmeaom.myradar.sdk.internal.AnnotationEncoder
import com.acmeaom.myradar.sdk.internal.NOT_CONFIGURED_MESSAGE
import com.acmeaom.myradar.sdk.internal.PreferenceStore
import com.acmeaom.myradar.sdk.internal.TectonicBridge
import com.acmeaom.myradar.sdk.internal.TectonicGlobalBridge
import com.acmeaom.myradar.sdk.internal.TectonicKeys
import org.json.JSONArray
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.util.Date
import kotlin.math.abs

/**
 * An interactive weather map view displaying MyRadar base maps and animated radar.
 *
 * `MyRadarMapView` is the primary entry point of the MyRadar Android SDK. Add it to your view
 * hierarchy like any other view, in code or in XML; the radar animation is enabled and playing
 * by default.
 *
 * ```kotlin
 * val mapView = MyRadarMapView(context)
 * mapView.center = LatLng(35.2, -97.4)
 * mapView.zoomLevel = 6f
 * container.addView(mapView)
 * ```
 *
 * [MyRadarSdk.configure] must be called first. Without an API key the map makes no network
 * requests, and shows a notice saying the SDK is not configured.
 *
 * Rendering starts automatically when the view is attached to a window whose lifecycle owner
 * is started, and stops when the view is detached or the owner stops (for example when the app
 * moves to the background).
 *
 * All methods must be called on the main thread.
 */
@MainThread
public class MyRadarMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    // MARK: Public API

    /** Receives map movement, radar animation and tap events. */
    public var listener: MyRadarMapListener? = null

    /** The base map appearance. Defaults to [MapStyle.Gray]. */
    public var mapStyle: MapStyle
        get() = MapStyle.fromEngineValue(preferences.int(TectonicKeys.MAP_TILE_TYPE, MapStyle.Gray.engineValue))
            ?: MapStyle.Gray
        set(value) = preferences.set(TectonicKeys.MAP_TILE_TYPE, value.engineValue)

    /** The coordinate at the center of the viewport. Setting it cancels a camera animation. */
    public var center: LatLng
        get() = surface.mapCenter().let { LatLng(it.latitude, it.longitude) }
        set(value) {
            cancelCameraAnimation()
            applyCenter(value)
        }

    /** The map zoom level. Valid values are typically between 2.5 (continental) and 15 (street). */
    public var zoomLevel: Float
        get() = surface.zoom
        set(value) {
            cancelCameraAnimation()
            surface.zoom = value
        }

    /** Map rotation in degrees clockwise from north. */
    public var heading: Float
        get() = surface.heading
        set(value) {
            surface.heading = value
        }

    /** Perspective tilt in degrees from straight down. */
    public var tilt: Float
        get() = surface.tilt
        set(value) {
            surface.tilt = value
        }

    /** Moves the viewport to a coordinate and zoom level, optionally animated. */
    public fun setCenter(center: LatLng, zoomLevel: Float, animated: Boolean) {
        cancelCameraAnimation()
        if (!animated || !isAttachedToWindow) {
            applyCenter(center)
            surface.zoom = zoomLevel
            return
        }
        animateCamera(center, zoomLevel)
    }

    /** Moves the viewport to a camera, optionally animated. */
    public fun setCamera(camera: MapCamera, animated: Boolean) {
        setCenter(camera.center, camera.zoom, animated)
    }

    /**
     * Moves the viewport so that a coordinate region is visible, optionally animated.
     *
     * The zoom that fits the region depends on the view's size, so a call made before the map
     * has been laid out is applied (without animation) once its size is known.
     */
    public fun setVisibleRegion(region: CoordinateRegion, animated: Boolean) {
        if (!hasSurfaceSize) {
            cancelCameraAnimation()
            pendingRegion = region
            applyCenter(region.center)
            return
        }
        pendingRegion = null
        setCenter(region.center, zoomLevelFor(region), animated)
    }

    /**
     * Moves the viewport so that all given coordinates are visible, with padding.
     *
     * @param coordinates The coordinates that must be on screen. Invalid coordinates are ignored.
     * @param paddingFraction Extra span added around the bounding box, as a fraction of its size.
     * @param animated Whether to animate the camera change.
     */
    @JvmOverloads
    public fun setVisibleCoordinates(coordinates: List<LatLng>, paddingFraction: Double = 0.3, animated: Boolean) {
        CoordinateRegion.fitting(coordinates, paddingFraction)?.let { setVisibleRegion(it, animated) }
    }

    /**
     * Computes the zoom level that fits a coordinate region in the current viewport. The view
     * must have been laid out for the result to be meaningful.
     */
    public fun zoomLevelFor(region: CoordinateRegion): Float =
        surface.zoomForRegion(region.north.toFloat(), region.east.toFloat(), region.south.toFloat(), region.west.toFloat())

    // MARK: Polygons, polylines and markers

    /** Lines drawn on top of the weather layers. Replacing the list redraws them. */
    public var polylines: List<MapPolyline> = emptyList()
        set(value) {
            if (field == value) return
            field = value
            pushShapes()
        }

    /** Filled areas drawn on top of the weather layers, beneath polylines and markers. */
    public var polygons: List<MapPolygon> = emptyList()
        set(value) {
            if (field == value) return
            field = value
            pushShapes()
        }

    /** Icons and labels pinned to coordinates. Replacing the list redraws them. */
    public var markers: List<MapMarker> = emptyList()
        set(value) {
            if (field == value) return
            field = value
            pushMarkers()
            updateAnnotationLayerStatus()
        }

    // MARK: Overlays

    /** Shows or hides an additional data overlay. */
    public fun setOverlay(overlay: Overlay, enabled: Boolean) {
        preferences.set(overlay.statusPreferenceKey, enabled)
    }

    /** Whether an overlay is currently shown. */
    public fun isOverlayEnabled(overlay: Overlay): Boolean = preferences.bool(overlay.statusPreferenceKey)

    /**
     * Sets an overlay's opacity in `0..1`. Ignored for overlays where [Overlay.supportsOpacity]
     * is `false`. For [Overlay.Warnings] the value applies to warnings, and watches are drawn
     * at half of it.
     */
    public fun setOpacity(opacity: Float, overlay: Overlay) {
        val clamped = opacity.coerceIn(0f, 1f)
        for ((key, scale) in overlay.opacityPreferenceKeys) {
            preferences.set(key, clamped * scale)
        }
    }

    /** The overlay's current opacity, or `null` if the overlay has no opacity control. */
    public fun opacity(overlay: Overlay): Float? {
        val primary = overlay.opacityPreferenceKeys.firstOrNull() ?: return null
        val fallback = overlay.defaultOpacity ?: return null
        return preferences.float(primary.first, fallback)
    }

    /**
     * Advanced escape hatch: sets a raw Tectonic engine preference.
     *
     * Most apps should use the typed API instead. Pass `null` to restore the engine default for
     * the key. Values must be a [Boolean], [Int], [Float] or [String], matching the type the
     * engine declares for the key.
     */
    public fun setAdvancedPreference(key: String, value: Any?) {
        preferences.set(key, value)
    }

    // MARK: Rendering and snapshots

    /**
     * Whether the map is actively rendering.
     *
     * Managed automatically from attachment and lifecycle; use [setRenderingEnabled] only if you
     * need manual control.
     */
    public var isRenderingEnabled: Boolean = false
        private set

    /**
     * Manually starts or stops rendering. Rendering must be stopped while the app is in the
     * background.
     */
    public fun setRenderingEnabled(enabled: Boolean) {
        if (enabled == isRenderingEnabled) return
        isRenderingEnabled = enabled
        if (enabled) surface.onResume() else surface.onPause()
    }

    /**
     * Captures the currently displayed map as a bitmap and delivers it on the main thread, or
     * delivers `null` if the map is not rendering.
     */
    public fun snapshot(callback: (Bitmap?) -> Unit) {
        if (!isRenderingEnabled) {
            callback(null)
            return
        }
        surface.takeScreenShot { callback(it) }
    }

    public companion object {
        /**
         * Open source licenses and attributions that must be presented within your app, for
         * example on an about or legal screen.
         */
        @JvmStatic
        public fun licensesAndAttributions(context: Context): List<Attribution> =
            listOf("tectonic_attributions.json", "data_attributions.json").flatMap { name ->
                runCatching {
                    val array = JSONArray(context.assets.open(name).bufferedReader().use { it.readText() })
                    (0 until array.length()).mapNotNull { i ->
                        val entry = array.optJSONObject(i) ?: return@mapNotNull null
                        val title = entry.optString("name").takeIf { it.isNotEmpty() } ?: return@mapNotNull null
                        Attribution(title, entry.optString("url").takeIf { it.isNotEmpty() })
                    }
                }.getOrDefault(emptyList())
            }

        /** Matches the engine's own "map stopped" debounce. */
        private const val MAP_STOPPED_DELAY_MS = 150L
        private const val CAMERA_ANIMATION_MS = 700L
        private const val LOG_TAG = "MyRadarSDK"
    }

    /** Controls the animated radar layer. */
    public val radar: RadarAnimation

    // MARK: Private

    private val preferences: PreferenceStore
    /**
     * The engine holds its delegates weakly, so this field is what keeps the bridge alive. It is
     * never read; consumer-rules.pro stops R8 from removing it.
     */
    @Keep
    private val bridge: TectonicBridge
    private val surface: TectonicMapSurfaceView
    private val mainHandler = Handler(Looper.getMainLooper())
    private val mapStoppedRunnable = Runnable { listener?.onMapStoppedMoving(this) }
    private var lastMarkerMapHeading = 0.0
    private var cameraAnimator: ValueAnimator? = null
    private var pendingRegion: CoordinateRegion? = null
    private var hasSurfaceSize = false
    private var lifecycleOwner: LifecycleOwner? = null
    private var configurationNotice: TextView? = null

    private val lifecycleObserver = LifecycleEventObserver { _, event ->
        when (event) {
            Lifecycle.Event.ON_START -> setRenderingEnabled(isAttachedToWindow)
            Lifecycle.Event.ON_STOP -> setRenderingEnabled(false)
            else -> Unit
        }
    }

    /** Learns the surface size so region fitting can run; added after the engine's own callback. */
    private val surfaceCallback = object : SurfaceHolder.Callback {
        override fun surfaceCreated(holder: SurfaceHolder) = Unit

        override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            hasSurfaceSize = width > 0 && height > 0
            if (hasSurfaceSize) {
                pendingRegion?.let { region ->
                    pendingRegion = null
                    setCenter(region.center, zoomLevelFor(region), animated = false)
                }
            }
        }

        override fun surfaceDestroyed(holder: SurfaceHolder) {
            hasSurfaceSize = false
        }
    }

    init {
        TectonicGlobalBridge.installOnce(context)

        preferences = PreferenceStore(TectonicKeys.initialValues())
        bridge = TectonicBridge(preferences)
        radar = RadarAnimation(preferences)
        surface = TectonicMapSurfaceView(context)

        bridge.owner = WeakReference(this)
        preferences.onChange = { key ->
            // The engine expects change notifications on the main thread.
            if (Looper.myLooper() == Looper.getMainLooper()) {
                surface.onPrefChanged(key)
            } else {
                mainHandler.post { surface.onPrefChanged(key) }
            }
        }

        // The preference delegate must be in place before the map delegate: setting the map
        // delegate creates the engine's modules, which read their preferences immediately.
        surface.setPrefDelegate(bridge)
        surface.setMapDelegate(bridge)
        surface.holder.addCallback(surfaceCallback)
        addView(surface, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // A sensible default viewport: continental United States.
        surface.setMapCenter(39.5f, -98.35f)
        surface.zoom = 4f

        updateConfigurationNotice()
    }

    /**
     * Without an API key the SDK refuses every request, so the map would stay empty with no
     * explanation. Say why, on the map itself and in the log.
     */
    private fun updateConfigurationNotice() {
        val configured = MyRadarSdk.isConfigured
        if (configured) {
            configurationNotice?.let(::removeView)
            configurationNotice = null
            return
        }
        if (configurationNotice != null) return
        Log.e(LOG_TAG, NOT_CONFIGURED_MESSAGE)
        val density = resources.displayMetrics.density
        configurationNotice = TextView(context).apply {
            text = NOT_CONFIGURED_MESSAGE
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(217, 160, 20, 20))
            val padding = (16 * density).toInt()
            setPadding(padding, padding, padding, padding)
        }
        addView(configurationNotice, LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    // MARK: Lifecycle

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // The app may have configured the SDK after creating this view.
        updateConfigurationNotice()
        val owner = findViewTreeLifecycleOwner()
        lifecycleOwner = owner
        if (owner != null) {
            // Delivers ON_START immediately when the owner is already started.
            owner.lifecycle.addObserver(lifecycleObserver)
        } else {
            setRenderingEnabled(windowVisibility == View.VISIBLE)
        }
    }

    override fun onDetachedFromWindow() {
        lifecycleOwner?.lifecycle?.removeObserver(lifecycleObserver)
        lifecycleOwner = null
        cancelCameraAnimation()
        mainHandler.removeCallbacks(mapStoppedRunnable)
        setRenderingEnabled(false)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        // Without a lifecycle owner, follow window visibility instead.
        if (lifecycleOwner == null && isAttachedToWindow) {
            setRenderingEnabled(visibility == View.VISIBLE)
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        // A touch takes the camera away from a running animation.
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) cancelCameraAnimation()
        return false
    }

    // MARK: Camera

    private fun applyCenter(value: LatLng) {
        // The engine rejects (and in debug builds, throws on) a center at null island.
        if (abs(value.latitude) < 0.01 && abs(value.longitude) < 0.01) return
        surface.setMapCenter(value.latitude.toFloat(), value.longitude.toFloat())
    }

    private fun animateCamera(target: LatLng, targetZoom: Float) {
        val start = center
        val startZoom = surface.zoom
        // Take the short way around the antimeridian.
        var lonDelta = target.longitude - start.longitude
        if (lonDelta > 180) lonDelta -= 360 else if (lonDelta < -180) lonDelta += 360
        val latDelta = target.latitude - start.latitude
        val zoomDelta = targetZoom - startZoom
        cameraAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = CAMERA_ANIMATION_MS
            interpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
            addUpdateListener { animator ->
                val f = animator.animatedValue as Float
                var lon = start.longitude + lonDelta * f
                if (lon > 180) lon -= 360 else if (lon < -180) lon += 360
                applyCenter(LatLng(start.latitude + latDelta * f, lon))
                surface.zoom = startZoom + zoomDelta * f
            }
            start()
        }
    }

    private fun cancelCameraAnimation() {
        cameraAnimator?.cancel()
        cameraAnimator = null
    }

    // MARK: Annotations

    private fun pushShapes() {
        preferences.set(TectonicKeys.LOCAL_GEOJSON_SHAPES, AnnotationEncoder.shapesGeoJson(polygons, polylines))
        updateAnnotationLayerStatus()
    }

    private fun pushMarkers() {
        lastMarkerMapHeading = surface.heading.toDouble()
        preferences.set(TectonicKeys.LOCAL_GEOJSON_MARKERS, AnnotationEncoder.markersGeoJson(markers, lastMarkerMapHeading))
    }

    private fun updateAnnotationLayerStatus() {
        val enabled = polylines.isNotEmpty() || polygons.isNotEmpty() || markers.isNotEmpty()
        preferences.set(TectonicKeys.LOCAL_GEOJSON_STATUS, enabled)
    }

    // MARK: Engine events (main thread, from TectonicBridge)

    internal fun handleMapMoved() {
        // Marker icons are rotated relative to the screen, so re-push them when the map rotates.
        if (markers.any { it.heading != null } && abs(surface.heading - lastMarkerMapHeading) > 0.5) {
            pushMarkers()
        }
        listener?.onMapMoved(this)
        // The Android engine does not report when movement ends; debounce as the engine does on iOS.
        mainHandler.removeCallbacks(mapStoppedRunnable)
        mainHandler.postDelayed(mapStoppedRunnable, MAP_STOPPED_DELAY_MS)
    }

    internal fun handleRadarFrame(date: Date?) {
        radar.currentFrameDate = date
        listener?.onRadarFrame(this, date)
    }

    internal fun handleScrubberPosition(position: Float) {
        radar.reportedScrubberPosition = position
        listener?.onRadarScrubberPosition(this, position)
    }

    internal fun handleRadarPalette(json: String?) {
        listener?.onRadarPalette(this, json)
    }

    /**
     * Routes engine hit results to the typed marker, polyline and polygon callbacks, falling
     * back to the raw graphics callback for anything else.
     */
    internal fun handleGraphicsTap(json: String, pointDp: PointF) {
        val hits = runCatching { JSONArray(json) }.getOrNull() ?: return
        val unhandled = mutableListOf<String>()
        for (i in 0 until hits.length()) {
            val hit = hits.optJSONObject(i) ?: continue
            val objectType = hit.optString(AnnotationEncoder.OBJECT_TYPE_KEY)
            val id = hit.opt(AnnotationEncoder.FEATURE_ID_KEY)?.takeIf { it != JSONObject.NULL }?.toString()
            val handled = id != null && when (objectType) {
                AnnotationEncoder.MARKER_OBJECT_TYPE ->
                    markers.firstOrNull { it.id == id }?.also { listener?.onMarkerTap(this, it) } != null
                AnnotationEncoder.POLYLINE_OBJECT_TYPE ->
                    polylines.firstOrNull { it.id == id }?.also { listener?.onPolylineTap(this, it) } != null
                AnnotationEncoder.POLYGON_OBJECT_TYPE ->
                    polygons.firstOrNull { it.id == id }?.also { listener?.onPolygonTap(this, it) } != null
                else -> false
            }
            // SDK annotations that no longer exist are dropped, as on iOS; anything else is raw.
            val isSdkType = objectType in setOf(
                AnnotationEncoder.MARKER_OBJECT_TYPE,
                AnnotationEncoder.POLYLINE_OBJECT_TYPE,
                AnnotationEncoder.POLYGON_OBJECT_TYPE,
            )
            if (!handled && !(isSdkType && id != null)) unhandled.add(hit.toString())
        }
        if (unhandled.isNotEmpty()) {
            listener?.onGraphicsTap(this, unhandled, pointDp)
        }
    }
}
