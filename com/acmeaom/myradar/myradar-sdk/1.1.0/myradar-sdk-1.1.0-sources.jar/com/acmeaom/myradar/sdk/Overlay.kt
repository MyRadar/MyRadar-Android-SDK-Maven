package com.acmeaom.myradar.sdk

import com.acmeaom.myradar.sdk.internal.TectonicKeys

/**
 * Additional data overlays that can be toggled on the map.
 *
 * Radar is the primary layer and is controlled separately through [MyRadarMapView.radar];
 * these overlays render on top of the base map alongside the radar animation. All overlays
 * are off by default.
 */
public enum class Overlay(
    /** A short human-readable name, useful for building overlay pickers. */
    public val displayName: String,
    internal val statusPreferenceKey: String,
    /**
     * The engine's default opacity for this overlay, or `null` when it is not adjustable.
     */
    public val defaultOpacity: Float?,
) {
    /** National Weather Service watch, warning and advisory polygons. */
    Warnings("Warnings", TectonicKeys.WARNINGS_STATUS, 0.4f),

    /**
     * Lightning strike markers for the two hours ending at the displayed radar frame.
     *
     * Requires the radar layer to be enabled; lightning data is synchronized to the radar timeline.
     */
    Lightning("Lightning", TectonicKeys.LIGHTNING_MARKERS_STATUS, null),

    /**
     * A brief full-map flash effect when lightning occurs in the displayed frame.
     *
     * Requires the radar layer to be enabled. Usually combined with [Lightning].
     */
    LightningFlashes("Lightning Flashes", TectonicKeys.LIGHTNING_EFFECT_STATUS, null),

    /** Active tropical cyclones: storm center, past and forecast track, and forecast cone. */
    Hurricanes("Hurricanes", TectonicKeys.HURRICANES_STATUS, 0.65f),

    /** Animated surface wind particles. */
    Wind("Wind", TectonicKeys.WIND_STATUS, 0.65f);

    /**
     * Whether [MyRadarMapView.setOpacity] applies to this overlay.
     * Lightning markers and flashes have no opacity control in the engine.
     */
    public val supportsOpacity: Boolean get() = defaultOpacity != null

    /**
     * Preference keys that carry this overlay's opacity, with the factor applied to each.
     * Warnings use two keys: watches are drawn at half the warning opacity so the two stay
     * distinguishable, matching the engine's default ratio.
     */
    internal val opacityPreferenceKeys: List<Pair<String, Float>>
        get() = when (this) {
            Warnings -> listOf(TectonicKeys.WARNINGS_ALPHA to 1f, TectonicKeys.WATCHES_ALPHA to 0.5f)
            Hurricanes -> listOf(TectonicKeys.HURRICANES_OPACITY to 1f)
            Wind -> listOf(TectonicKeys.WIND_OPACITY to 1f)
            Lightning, LightningFlashes -> emptyList()
        }
}
