package com.acmeaom.myradar.sdk.internal

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl

/** Where the SDK's requests go and how they are signed. */
internal class GatewayConfiguration private constructor(val apiKey: String) {

    private val baseUrl: HttpUrl get() = GATEWAY_URL

    /**
     * Maps an engine request onto its destination, or returns null if the SDK must not make it.
     *
     * Base maps (styles, TileJSON, tiles, sprites) load directly from [BASE_MAP_HOST], unsigned.
     * Every other MyRadar request goes to the gateway, which mounts each backend's original path
     * at its root, so the request keeps its path and query and only changes host. Requests to any
     * other host are refused.
     */
    fun route(url: HttpUrl): HttpUrl? = when {
        isGateway(url) || isBaseMap(url) -> url
        url.host == MYRADAR_DOMAIN || url.host.endsWith(".$MYRADAR_DOMAIN") -> baseUrl.newBuilder()
            .encodedPath(baseUrl.encodedPath.trimEnd('/') + url.encodedPath)
            .encodedQuery(url.encodedQuery)
            .build()
        else -> null
    }

    /** Whether a request is addressed to this gateway. */
    fun isGateway(url: HttpUrl): Boolean =
        url.scheme == baseUrl.scheme && url.host == baseUrl.host && url.port == baseUrl.port

    companion object {
        /**
         * The MyRadar API gateway: the only host the SDK sends API requests to. Fixed; apps cannot
         * point the SDK at another one.
         */
        val GATEWAY_URL: HttpUrl = "https://sdkwrapperapi.azure-api.net".toHttpUrl()

        /**
         * The one host the SDK contacts directly, without the API key: MyRadar's base map server.
         * Every base map style references only this host (style JSON, TileJSON, tiles, sprites).
         */
        const val BASE_MAP_HOST = "map2.acmeaom.com"

        /** Whether a request is for base map data, which bypasses the gateway. */
        fun isBaseMap(url: HttpUrl): Boolean = url.isHttps && url.host == BASE_MAP_HOST && url.port == 443

        /** Header the gateway expects the key in. */
        const val HEADER_FIELD = "Ocp-Apim-Subscription-Key"

        /** The engine's data hosts are all subdomains of this domain. */
        private const val MYRADAR_DOMAIN = "acmeaom.com"

        fun create(apiKey: String): GatewayConfiguration {
            val key = apiKey.trim()
            require(key.isNotEmpty()) { "MyRadar API key must not be empty" }
            return GatewayConfiguration(key)
        }

        /**
         * The process-wide configuration, read by the HTTP layer for every request. Until it is
         * set, the SDK makes no network requests at all, base maps included.
         */
        @Volatile
        var current: GatewayConfiguration? = null
    }
}
