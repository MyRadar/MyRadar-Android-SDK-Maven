package com.acmeaom.myradar.sdk.internal

import com.acmeaom.myradar.sdk.FlightAirport
import com.acmeaom.myradar.sdk.FlightException
import com.acmeaom.myradar.sdk.FlightException.Reason
import com.acmeaom.myradar.sdk.FlightInfo
import com.acmeaom.myradar.sdk.FlightPosition
import com.acmeaom.myradar.sdk.FlightTrackPoint
import com.acmeaom.myradar.sdk.LatLng
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.time.Instant
import java.util.concurrent.TimeUnit

/**
 * Flight data from the MyRadar API gateway: which departure a flight number refers to right
 * now, where it is, the route it filed and the track it has flown.
 */
internal object FlightData {

    // MARK: Idents

    /** `ua 1` → `UA1`. Returns null for anything that can't be a flight number, callsign or registration. */
    fun normalizeIdent(raw: String): String? {
        val ident = raw.uppercase().filter { it != ' ' && it != '-' }
        val valid = ident.length in 2..8 && ident.all { it in 'A'..'Z' || it in '0'..'9' } && ident.any { it.isDigit() }
        return ident.takeIf { valid }
    }

    /** `UA1` → `UA 1`, the way it's printed on tickets. */
    fun formatFlightNumber(ident: String): String =
        Regex("^([A-Z0-9]{2})(\\d+[A-Z]?)$").matchEntire(ident)?.let { "${it.groupValues[1]} ${it.groupValues[2]}" } ?: ident

    // MARK: Parsing (gateway responses; only the fields the SDK reads)

    private fun JSONObject.str(key: String): String? = optString(key, "").takeIf { !isNull(key) && it.isNotEmpty() }

    private fun JSONObject.num(key: String): Double? = if (has(key) && !isNull(key)) optDouble(key).takeIf { it.isFinite() } else null

    fun instant(s: String?): Instant? = s?.let { runCatching { Instant.parse(it) }.getOrNull() }

    private fun airport(a: JSONObject?): FlightAirport? {
        a ?: return null
        val iata = a.str("code_iata")
        val icao = a.str("code_icao")
        val code = iata ?: icao ?: a.str("code") ?: return null
        val name = a.str("name") ?: code
        return FlightAirport(code, iata, icao, name, a.str("city") ?: name, coordinate = null)
    }

    private fun position(p: JSONObject): FlightPosition = FlightPosition(
        coordinate = LatLng(p.getDouble("latitude"), p.getDouble("longitude")),
        // Reported in hundreds of feet.
        altitudeFeet = p.num("altitude")?.times(100),
        groundSpeedKnots = p.num("groundspeed"),
        heading = p.num("heading"),
        timestamp = instant(p.str("timestamp")) ?: Instant.now(),
        // `P` is a position projected (estimated) from the flight plan.
        isEstimated = p.str("update_type") == "P",
    )

    /** The filed route from a flat lat, lng, lat, lng, ... list; its first and last points are the airports. */
    fun waypoints(flat: JSONArray?): List<LatLng> {
        flat ?: return emptyList()
        return (0 until flat.length() - 1 step 2).mapNotNull { i ->
            val lat = flat.optDouble(i)
            val lng = flat.optDouble(i + 1)
            if (lat.isFinite() && lng.isFinite()) LatLng(lat, lng) else null
        }
    }

    fun track(raw: JSONObject?): List<FlightTrackPoint> {
        val positions = raw?.optJSONArray("positions") ?: return emptyList()
        return (0 until positions.length()).mapNotNull { i ->
            val p = positions.optJSONObject(i) ?: return@mapNotNull null
            FlightTrackPoint(
                coordinate = LatLng(p.getDouble("latitude"), p.getDouble("longitude")),
                altitudeFeet = p.num("altitude")?.times(100),
                timestamp = instant(p.str("timestamp")) ?: Instant.EPOCH,
            )
        }
    }

    private fun JSONObject.time(key: String): Long? = instant(str(key))?.toEpochMilli()

    /**
     * The departure of a flight number to show: the one in the air, otherwise the one that
     * landed most recently (within a day), otherwise the next one scheduled.
     */
    fun chooseFlight(flights: List<JSONObject>, nowMs: Long = System.currentTimeMillis()): JSONObject? {
        val live = flights.filter { !it.optBoolean("cancelled", false) }
        live.filter { it.str("actual_off") != null && it.str("actual_on") == null }
            .maxByOrNull { it.time("actual_off") ?: 0 }?.let { return it }
        live.filter { f -> f.time("actual_on")?.let { nowMs - it < 24 * 3_600_000L } ?: false }
            .maxByOrNull { it.time("actual_on") ?: 0 }?.let { return it }
        fun out(f: JSONObject) = f.time("scheduled_out") ?: f.time("scheduled_off")
        live.filter { f -> out(f)?.let { it >= nowMs - 3_600_000L } ?: false }
            .minByOrNull { out(it) ?: 0 }?.let { return it }
        return live.firstOrNull() ?: flights.firstOrNull()
    }

    /** Combines the three responses into a FlightInfo. */
    fun flightInfo(f: JSONObject, position: JSONObject?, track: JSONObject?): FlightInfo {
        val route = waypoints(position?.optJSONArray("waypoints"))
        var origin = airport(f.optJSONObject("origin"))
        var destination = airport(f.optJSONObject("destination"))
        // The filed route starts and ends at the airports, which places them on the map.
        if (route.size >= 2) {
            origin = origin?.copy(coordinate = route.first())
            destination = destination?.copy(coordinate = route.last())
        }
        val landed = f.str("actual_on") != null || f.str("actual_in") != null
        fun date(a: String, b: String) = instant(f.str(a) ?: f.str(b))
        return FlightInfo(
            flightId = f.getString("fa_flight_id"),
            ident = f.str("ident_iata")?.let(::formatFlightNumber) ?: f.str("ident") ?: f.str("ident_icao") ?: "",
            identIata = f.str("ident_iata"),
            identIcao = f.str("ident_icao"),
            operatorCode = f.str("operator_icao"),
            aircraftType = f.str("aircraft_type"),
            registration = f.str("registration"),
            status = f.str("status") ?: "",
            isAirborne = f.str("actual_off") != null && !landed,
            hasLanded = landed,
            isCancelled = f.optBoolean("cancelled", false),
            origin = origin,
            destination = destination,
            scheduledDeparture = date("scheduled_out", "scheduled_off"),
            actualDeparture = date("actual_off", "actual_out"),
            scheduledArrival = date("scheduled_in", "scheduled_on"),
            estimatedArrival = if (landed) null else date("estimated_on", "estimated_in"),
            actualArrival = date("actual_on", "actual_in"),
            progress = f.num("progress_percent")?.div(100),
            position = position?.optJSONObject("last_position")?.let(::position),
            plannedRoute = route,
            track = track(track),
        )
    }

    // MARK: Gateway requests

    /** Signed by the gateway interceptors, like every other SDK request; no other host is reachable. */
    private val client by lazy {
        OkHttpClient.Builder()
            .callTimeout(20, TimeUnit.SECONDS)
            .addInterceptor(GatewayRoutingInterceptor)
            .addNetworkInterceptor(GatewayEnforcingInterceptor)
            .build()
    }

    private class HttpStatus(val code: Int) : IOException("HTTP $code")

    private suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        val url = GatewayConfiguration.GATEWAY_URL.toString().trimEnd('/') + path
        client.newCall(Request.Builder().url(url).build()).execute().use { response ->
            if (response.code != 200) throw HttpStatus(response.code)
            JSONObject(response.body.string())
        }
    }

    /** A part of the flight that may be missing (no position before departure); cancellation still propagates. */
    private suspend fun getOrNull(path: String): JSONObject? = try {
        get(path)
    } catch (e: IOException) {
        null
    } catch (e: org.json.JSONException) {
        null
    }

    private fun failure(e: Throwable, ident: String): FlightException = when {
        e is FlightException -> e
        e is HttpStatus && e.code == 401 -> FlightException(Reason.KeyRejected, ident, "The MyRadar API key was not accepted")
        e is HttpStatus && e.code == 429 -> FlightException(Reason.Unavailable, ident, "Flight data is busy; try again in a minute")
        e is HttpStatus -> FlightException(Reason.Unavailable, ident, "Flight data did not respond (HTTP ${e.code})")
        e is GatewayRequestRefused -> FlightException(Reason.KeyRejected, ident, e.message ?: NOT_CONFIGURED_MESSAGE)
        else -> FlightException(Reason.Unavailable, ident, "Flight data did not respond (${e.message})")
    }

    private fun pathSegment(s: String): String = java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    /**
     * Looks a flight number up and gathers its position, filed route and track. Throws a
     * FlightException when the flight can't be shown at all; a missing position or track only
     * leaves that part out. [flightId] keeps following a departure already shown.
     */
    suspend fun lookUp(raw: String, flightId: String? = null): FlightInfo {
        val ident = normalizeIdent(raw)
            ?: throw FlightException(Reason.InvalidIdent, raw, "\"$raw\" is not a flight number")
        if (GatewayConfiguration.current == null) throw FlightException(Reason.KeyRejected, ident, NOT_CONFIGURED_MESSAGE)
        val flights = try {
            val body = get("/aeroapi/flights/${pathSegment(ident)}?ident_type=designator&max_pages=1")
            val list = body.optJSONArray("flights") ?: JSONArray()
            (0 until list.length()).mapNotNull { list.optJSONObject(it) }
        } catch (e: HttpStatus) {
            // An unknown flight number answers 400 or 404 rather than an empty list.
            if (e.code == 400 || e.code == 404) throw FlightException(Reason.NotFound, ident, "No flight $ident was found")
            throw failure(e, ident)
        } catch (e: IOException) {
            throw failure(e, ident)
        }
        val flight = flights.firstOrNull { it.optString("fa_flight_id") == flightId } ?: chooseFlight(flights)
            ?: throw FlightException(Reason.NotFound, ident, "No flight $ident was found")
        val id = pathSegment(flight.getString("fa_flight_id"))
        return coroutineScope {
            val position = async { getOrNull("/aeroapi/flights/$id/position") }
            val track = async { getOrNull("/aeroapi/flights/$id/track") }
            flightInfo(flight, position.await(), track.await())
        }
    }
}
