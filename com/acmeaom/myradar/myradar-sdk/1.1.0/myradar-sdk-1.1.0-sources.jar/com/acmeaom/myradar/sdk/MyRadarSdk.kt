package com.acmeaom.myradar.sdk

import com.acmeaom.myradar.sdk.internal.GatewayConfiguration

/**
 * SDK-level information and configuration.
 */
public object MyRadarSdk {

    /** The version of the MyRadar Android SDK. */
    public const val VERSION: String = BuildConfig.SDK_VERSION

    /**
     * Sets the API key the SDK authenticates with. Required: the SDK sends every request (weather
     * data and base maps) to the MyRadar API gateway and never contacts any other host. Until this
     * is called, map views make no network requests and display a "not configured" notice.
     *
     * Call this once, before creating any [MyRadarMapView] or `MyRadarMap`, for example in
     * `Application.onCreate`.
     *
     * ```kotlin
     * MyRadarSdk.configure(apiKey = "<your key>")
     * ```
     *
     * @param apiKey The subscription key issued to your app.
     * @throws IllegalArgumentException if the key is blank.
     */
    @JvmStatic
    public fun configure(apiKey: String) {
        GatewayConfiguration.current = GatewayConfiguration.create(apiKey)
    }

    /** Whether [configure] has been called. */
    @JvmStatic
    public val isConfigured: Boolean
        get() = GatewayConfiguration.current != null
}
