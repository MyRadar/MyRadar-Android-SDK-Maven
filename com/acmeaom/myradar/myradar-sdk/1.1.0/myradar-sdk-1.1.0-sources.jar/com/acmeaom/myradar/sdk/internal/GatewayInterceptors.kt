package com.acmeaom.myradar.sdk.internal

import android.util.Log
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException

/** A request the SDK refused to send. The engine treats it like any network failure. */
internal class GatewayRequestRefused(message: String) : IOException(message)

/**
 * Application interceptor: moves every engine request onto the API gateway (base maps excepted,
 * see [GatewayConfiguration.route]), or refuses it. Runs once per call, before any network activity.
 */
internal object GatewayRoutingInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val gateway = GatewayConfiguration.current
            ?: throw GatewayRequestRefused(NOT_CONFIGURED_MESSAGE)
        val routed = gateway.route(request.url)
            ?: throw GatewayRequestRefused(
                "Refused request to ${request.url.host}: the MyRadar SDK only contacts its API gateway and base map server")
        return chain.proceed(request.newBuilder().url(routed).build())
    }
}

/**
 * Network interceptor: sees every request that actually goes on the wire, including redirects
 * OkHttp follows on its own. It signs gateway requests, sends base map requests unsigned, and
 * refuses anything else, so the key only ever reaches the gateway and no other host is contacted.
 */
internal object GatewayEnforcingInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val gateway = GatewayConfiguration.current
            ?: throw GatewayRequestRefused(NOT_CONFIGURED_MESSAGE)
        val outgoing = when {
            gateway.isGateway(request.url) ->
                request.newBuilder().header(GatewayConfiguration.HEADER_FIELD, gateway.apiKey).build()
            GatewayConfiguration.isBaseMap(request.url) ->
                request.newBuilder().removeHeader(GatewayConfiguration.HEADER_FIELD).build()
            else -> throw GatewayRequestRefused(
                "Refused redirect to ${request.url.host}: the MyRadar SDK only contacts its API gateway and base map server")
        }
        val response = chain.proceed(outgoing)
        // Opt-in request log: adb shell setprop log.tag.MyRadarSDK VERBOSE
        if (Log.isLoggable(LOG_TAG, Log.VERBOSE)) {
            val signed = outgoing.header(GatewayConfiguration.HEADER_FIELD) != null
            Log.v(LOG_TAG, "${request.method} ${request.url.host}${request.url.encodedPath} " +
                "${if (signed) "[key]" else "[no key]"} -> ${response.code}")
        }
        return response
    }
}

private const val LOG_TAG = "MyRadarSDK"

internal const val NOT_CONFIGURED_MESSAGE =
    "MyRadar SDK is not configured: call MyRadarSdk.configure(apiKey) before creating a map"
