package com.acmeaom.myradar.sdk.internal

/**
 * String constants for the Tectonic preference keys the SDK wraps. The key strings must match
 * the identifier names used by the engine (TectonicPreferences.h, with "Key" appended).
 * Kept identical to the iOS SDK's `TectonicKeys`.
 */
internal object TectonicKeys {
    // Base map
    const val MAP_TILE_TYPE = "kMapTileType2Key"

    // Weather animation (radar)
    const val WEATHER_ANIMATION_STATUS = "kWeatherAnimationStatusKey"
    const val WEATHER_ANIMATION_TYPE = "kWeatherAnimationTypeKey"
    const val WEATHER_ANIMATION_SCRUBBER_STATUS = "kWeatherAnimationScrubberStatusKey"
    const val WEATHER_ANIMATION_SCRUBBER = "kWeatherAnimationScrubberKey"

    // Per-product opacity keys
    const val MORPH_RADAR_OPACITY = "kWeatherAnimationMorphRadarOpacityKey"
    const val HD_RADAR_OPACITY = "kWeatherAnimationHdRadarOpacityKey"
    const val SD_RADAR_OPACITY = "kWeatherAnimationSdRadarOpacityKey"

    // Per-product loop length keys (minutes of history shown per loop)
    const val MORPH_RADAR_LOOP_LENGTH = "kWeatherAnimationMorphRadarLoopLengthKey"
    const val HD_RADAR_LOOP_LENGTH = "kWeatherAnimationHdRadarLoopLengthKey"
    const val SD_RADAR_LOOP_LENGTH = "kWeatherAnimationSdRadarLoopLengthKey"

    // Lightning
    const val LIGHTNING_MARKERS_STATUS = "kLightningMarkersStatusKey"
    const val LIGHTNING_EFFECT_STATUS = "kLightningEffectStatusKey"

    // Host-supplied GeoJSON (used for polygons, polylines and markers)
    const val LOCAL_GEOJSON_STATUS = "kLocalGeoJsonStatusKey"
    const val LOCAL_GEOJSON_ALPHA = "kLocalGeoJsonAlphaKey"
    const val LOCAL_GEOJSON_SHAPES = "kLocalGeoJsonContentsKey"
    const val LOCAL_GEOJSON_MARKERS = "kLocalGeoJsonContents2Key"

    // Watches / warnings
    const val WARNINGS_STATUS = "kWarningsStatusKey"
    const val WARNINGS_ENABLED_TAGS = "kWarningsEnabledTags4Key"
    const val WARNINGS_ALPHA = "kWarningsAlphaKey" // engine default 0.4
    const val WATCHES_ALPHA = "kWatchesAlphaKey" // engine default 0.2

    // Overlay opacity (engine defaults 0.65)
    const val HURRICANES_OPACITY = "kHurricanesOpacityKey"
    const val WIND_OPACITY = "kWindOpacityKey"

    /**
     * Feeds the engine polls whenever the warnings layer is on, regardless of tags. The SDK
     * points them at a bundled empty GeoJSON document so no request is made.
     */
    const val WARNINGS_AUSTRALIA_URL = "kWarningsAusUrl4Key"
    const val NON_WEATHER_EMERGENCY_MESSAGES_URL = "kNonWeatherEmergencyMessagesUrlKey"

    /**
     * A `resource://` URL resolves to an APK asset with no network access. Unlike iOS, the
     * Android engine treats a missing asset as a debug-build crash, so the SDK ships this file
     * (an empty FeatureCollection) in its assets.
     */
    const val DISABLED_FEED_URL = "resource://myradar-sdk-disabled-feed.json"

    // Hurricanes. Module version 4 reads the v3 feed and exposes each element behind its own
    // key; the SDK enables the core elements and leaves the satellite feeds (areas of interest,
    // wind speed forecast, time of arrival, spaghetti plots) off.
    const val HURRICANES_STATUS = "kHurricanesStatusKey"
    const val HURRICANES_MODULE_VERSION = "kHurricanesTectonicModuleVersionKey"
    const val HURRICANES_TRACK_ENABLED = "kHurricanesTrackEnabledKey"
    const val HURRICANES_PAST_TRACK_ENABLED = "kHurricanesPastTrackEnabledKey"
    const val HURRICANES_CONE_ENABLED = "kHurricanesConeEnabledKey"
    const val HURRICANES_STORM_CENTER_ENABLED = "kHurricanesStormCenterEnabledKey"

    // Wind particles
    const val WIND_STATUS = "kWindStatusKey"

    /** Suffix of the engine's feature flag keys, all of which default to enabled for SDK builds. */
    const val FEATURE_FLAG_SUFFIX = "FeatureFlagKey"

    /**
     * National Weather Service watch, warning and advisory tags.
     *
     * The engine default also includes Australian and French alerts plus the NWS Special
     * Weather Statement and Hazardous Weather Outlook feeds, each of which costs an extra network
     * poll. The SDK narrows the default to NWS weather products only; hosts can widen it with
     * [com.acmeaom.myradar.sdk.MyRadarMapView.setAdvancedPreference].
     */
    val defaultWarningsTags: String = listOf(
        "nws.av.a", "nws.av.w", "nws.bz.a", "nws.bz.w", "nws.ds.w", "nws.du.w", "nws.du.y",
        "nws.eh.a", "nws.eh.w", "nws.fa.a", "nws.fa.w", "nws.ff.a", "nws.ff.w", "nws.fg.y",
        "nws.fl.a", "nws.fl.w", "nws.fw.a", "nws.fw.w", "nws.gl.a", "nws.gl.w", "nws.hi.a",
        "nws.hi.w", "nws.ht.y", "nws.hu.a", "nws.hu.w", "nws.hw.a", "nws.hw.w", "nws.hz.a",
        "nws.hz.w", "nws.is.w", "nws.le.a", "nws.le.w", "nws.ma.w", "nws.rp.s", "nws.ss.a",
        "nws.ss.w", "nws.su.w", "nws.su.y", "nws.sv.a", "nws.sv.w", "nws.ti.a", "nws.ti.w",
        "nws.to.a", "nws.to.w", "nws.tr.a", "nws.tr.w", "nws.ts.a", "nws.ts.w", "nws.ty.a",
        "nws.ty.w", "nws.wc.a", "nws.wc.w", "nws.ws.a", "nws.ws.w", "nws.ww.y", "nws.zf.y",
        "nws.zr.y",
    ).joinToString(",")

    /**
     * The preference values every map view starts with. Endpoint URLs keep their engine defaults:
     * the HTTP layer moves every request onto the API gateway (see GatewayConfiguration.route).
     */
    fun initialValues(): Map<String, Any> = buildMap {
        // Radar on by default: it is the point of this SDK.
        put(WEATHER_ANIMATION_STATUS, true)
        put(WEATHER_ANIMATION_TYPE, 3)
        // Limit the warnings layer to NWS products so the engine does not poll the
        // international and statement feeds.
        put(WARNINGS_ENABLED_TAGS, defaultWarningsTags)
        // US only for now: silence the two alert feeds the engine would poll regardless of tags.
        put(WARNINGS_AUSTRALIA_URL, DISABLED_FEED_URL)
        put(NON_WEATHER_EMERGENCY_MESSAGES_URL, DISABLED_FEED_URL)
        // Host-drawn shapes and markers render fully opaque; colors carry their own alpha.
        put(LOCAL_GEOJSON_ALPHA, 1f)
        // Hurricanes: single v3 feed with center, tracks and cone; satellite feeds stay off.
        put(HURRICANES_MODULE_VERSION, 4)
        put(HURRICANES_TRACK_ENABLED, true)
        put(HURRICANES_PAST_TRACK_ENABLED, true)
        put(HURRICANES_CONE_ENABLED, true)
        put(HURRICANES_STORM_CENTER_ENABLED, true)
    }
}
