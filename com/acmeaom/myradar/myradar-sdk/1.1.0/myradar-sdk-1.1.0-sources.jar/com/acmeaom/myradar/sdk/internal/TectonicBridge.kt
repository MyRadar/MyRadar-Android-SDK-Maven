package com.acmeaom.myradar.sdk.internal

import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import com.acmeaom.android.tectonic.TectonicDelegate
import com.acmeaom.android.tectonic.TectonicPreferenceDelegate
import com.acmeaom.myradar.sdk.MyRadarMapView
import java.lang.ref.WeakReference
import java.util.Date

/**
 * Implements the engine's delegate interfaces on behalf of a [MyRadarMapView], keeping all
 * Tectonic types out of the public API.
 *
 * The engine holds its delegates weakly, so the owning map view keeps a strong reference to
 * this object. Preference getters are called from internal engine threads and only touch the
 * thread-safe [PreferenceStore]. Event callbacks arrive on the main thread (the engine posts
 * them there) and are forwarded to the owner.
 */
internal class TectonicBridge(
    private val preferences: PreferenceStore,
) : TectonicDelegate, TectonicPreferenceDelegate {

    /** Set by the map view after construction. Read on the main thread only. */
    var owner: WeakReference<MyRadarMapView> = WeakReference(null)

    private val mainHandler = Handler(Looper.getMainLooper())

    // MARK: Preference queries (any thread)

    override fun havePrefValue(key: String): Boolean =
        key.endsWith(TectonicKeys.FEATURE_FLAG_SUFFIX) || preferences.contains(key)

    override fun getBoolPref(key: String): Boolean =
        // Feature flags default to enabled for SDK builds.
        if (key.endsWith(TectonicKeys.FEATURE_FLAG_SUFFIX) && !preferences.contains(key)) true
        else preferences.bool(key)

    override fun getStringPref(key: String): String? = preferences.string(key)

    override fun getFloatPref(key: String): Float = preferences.float(key)

    override fun getIntPref(key: String): Int = preferences.int(key)

    // MARK: Viewport events

    override fun mapMoved(eventSource: Int) {
        forwardToOwner { it.handleMapMoved() }
    }

    // MARK: Weather animation events

    override fun onTimestampUpdate(
        timeStampMillis: Long,
        status: TectonicDelegate.TectonicWeatherAnimationFrameStatus,
        metaData: String?,
    ) {
        val date = if (status == TectonicDelegate.TectonicWeatherAnimationFrameStatus.TectonicWeatherAnimationFrameStatusOk &&
            timeStampMillis > 0
        ) Date(timeStampMillis) else null
        forwardToOwner { it.handleRadarFrame(date) }
    }

    override fun onScrubberUpdate(computedScrubberValue: Float) {
        forwardToOwner { it.handleScrubberPosition(computedScrubberValue) }
    }

    override fun onWeatherAnimationPaletteUpdate(json: String?) {
        forwardToOwner { it.handleRadarPalette(json) }
    }

    // MARK: Graphics interaction

    override fun graphicsClickedForTouch(json: String, pointDp: PointF) {
        forwardToOwner { it.handleGraphicsTap(json, pointDp) }
    }

    // MARK: Helpers

    /** The engine posts these callbacks to the main thread; hop there defensively anyway. */
    private inline fun forwardToOwner(crossinline body: (MyRadarMapView) -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            owner.get()?.let(body)
        } else {
            mainHandler.post { owner.get()?.let(body) }
        }
    }
}
