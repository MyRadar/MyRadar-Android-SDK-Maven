package com.acmeaom.myradar.sdk

/**
 * The base map appearance rendered beneath weather layers.
 *
 * @property engineValue The engine's map tile type identifier.
 */
public enum class MapStyle(internal val engineValue: Int, public val displayName: String) {
    /** Grayscale base map (default), optimized for weather overlay contrast. */
    Gray(0, "Gray"),
    /** Standard road map. */
    Roads(1, "Roads"),
    /** Satellite/aerial imagery. */
    Aerial(2, "Aerial"),
    /** Topographic map. */
    Topographic(18, "Topographic"),
    /** Dark vector base map. */
    Dark(20, "Dark"),
    /** Light vector base map. */
    Light(21, "Light");

    internal companion object {
        fun fromEngineValue(value: Int): MapStyle? = entries.firstOrNull { it.engineValue == value }
    }
}
