package com.acmeaom.myradar.sdk.internal

/**
 * Thread-safe backing store for Tectonic preference values.
 *
 * The engine queries preference values from arbitrary internal threads through
 * `TectonicPreferenceDelegate`, so all access to the underlying map is guarded by a lock.
 */
internal class PreferenceStore(initialValues: Map<String, Any> = emptyMap()) {

    /**
     * Invoked on the calling thread whenever a stored value changes. The owner is responsible
     * for forwarding the change to the engine on the main thread.
     */
    @Volatile
    var onChange: ((String) -> Unit)? = null

    private val lock = Any()
    private val values = HashMap(initialValues)

    fun contains(key: String): Boolean = synchronized(lock) { values.containsKey(key) }

    /** Returns the stored value for a Tectonic preference key, or null to use the engine default. */
    fun value(key: String): Any? = synchronized(lock) { values[key] }

    /**
     * Stores a value (or removes it when null so the engine default applies) and notifies the
     * observer if the value actually changed.
     */
    fun set(key: String, value: Any?) {
        val old = synchronized(lock) {
            if (value == null) values.remove(key) else values.put(key, value)
        }
        if (old != value) {
            onChange?.invoke(key)
        }
    }

    // Typed accessors. Numbers are coerced so a value stored as Int satisfies a float key and
    // vice versa; the engine asks for the type its preference table declares.

    fun bool(key: String, default: Boolean = false): Boolean = value(key) as? Boolean ?: default

    fun float(key: String, default: Float = 0f): Float = (value(key) as? Number)?.toFloat() ?: default

    fun int(key: String, default: Int = 0): Int = (value(key) as? Number)?.toInt() ?: default

    fun string(key: String): String? = value(key)?.toString()
}
