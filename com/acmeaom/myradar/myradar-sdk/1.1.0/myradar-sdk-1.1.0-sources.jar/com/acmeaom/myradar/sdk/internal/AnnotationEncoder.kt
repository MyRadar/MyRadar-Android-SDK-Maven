package com.acmeaom.myradar.sdk.internal

import android.content.res.Resources
import android.graphics.Bitmap
import android.util.Base64
import android.util.DisplayMetrics
import com.acmeaom.myradar.sdk.MapMarker
import com.acmeaom.myradar.sdk.MapPolygon
import com.acmeaom.myradar.sdk.MapPolyline
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt

/**
 * Converts public polygon, polyline and marker values into the GeoJSON documents that the
 * engine's host-supplied GeoJSON layer renders. See the Tectonic README, "GeoJSON Feature
 * Properties", for the property names used here. Mirrors the iOS SDK's `AnnotationEncoder`.
 */
internal object AnnotationEncoder {

    /** Object types stamped on every feature so taps can be routed back to the right API. */
    const val POLYLINE_OBJECT_TYPE = "myradar_polyline"
    const val POLYGON_OBJECT_TYPE = "myradar_polygon"
    const val MARKER_OBJECT_TYPE = "myradar_marker"

    /** Hit results echo the feature id and object type under these keys. */
    const val FEATURE_ID_KEY = "tectonic_geojson_feature_id"
    const val OBJECT_TYPE_KEY = "tectonic_object_type"

    /** Engine dash units are 1.5 dp. */
    private const val DASH_UNIT_DP = 1.5f

    // MARK: Shapes (polygons under polylines, in one document)

    fun shapesGeoJson(polygons: List<MapPolygon>, polylines: List<MapPolyline>): String =
        serialize(polygonFeatures(polygons) + polylineFeatures(polylines))

    private fun polygonFeatures(polygons: List<MapPolygon>): List<Map<String, Any>> =
        polygons.mapNotNull { polygon ->
            if (polygon.coordinates.size < 3) return@mapNotNull null
            val ring = polygon.coordinates.map { listOf(it.longitude, it.latitude) }.toMutableList()
            if (ring.first() != ring.last()) ring.add(ring.first()) // GeoJSON rings must be closed
            val properties = linkedMapOf<String, Any>(
                "object_type" to POLYGON_OBJECT_TYPE,
                "tappable" to true,
                "fill" to hexColor(polygon.fillColor),
                // "00000000" (clear) is the engine's convention for no outline.
                "stroke" to (polygon.strokeColor?.let(::hexColor) ?: "00000000"),
                "strokeWidth" to polygon.strokeWidthDp.toDouble(),
            )
            addUserInfo(properties, polygon.userInfo)
            feature(polygon.id, mapOf("type" to "Polygon", "coordinates" to listOf(ring)), properties)
        }

    private fun polylineFeatures(polylines: List<MapPolyline>): List<Map<String, Any>> =
        polylines.mapNotNull { line ->
            if (line.coordinates.size < 2) return@mapNotNull null
            val properties = linkedMapOf<String, Any>(
                "object_type" to POLYLINE_OBJECT_TYPE,
                "tappable" to true,
                "stroke" to hexColor(line.color),
                "strokeWidth" to line.widthDp.toDouble(),
            )
            line.outlineColor?.let {
                properties["stroke-outline"] = hexColor(it)
                properties["stroke-outline-width"] = (line.widthDp + 2).toDouble()
            }
            val dash = line.dashPattern
            if (!dash.isNullOrEmpty()) {
                properties["line-dasharray"] = dash.take(8).map { (it / DASH_UNIT_DP).toDouble() }
            }
            addUserInfo(properties, line.userInfo)
            feature(
                line.id,
                mapOf("type" to "LineString", "coordinates" to line.coordinates.map { listOf(it.longitude, it.latitude) }),
                properties,
            )
        }

    // MARK: Markers

    /**
     * @param mapHeading The map's current rotation. The engine rotates icons relative to the
     *   screen, so true headings are corrected by this amount.
     * @param encodeImage Turns a runtime bitmap into the engine's base64 `image_data` payload.
     */
    fun markersGeoJson(
        markers: List<MapMarker>,
        mapHeading: Double,
        encodeImage: (Bitmap) -> String? = ::base64Png,
    ): String {
        val features = markers.map { marker ->
            val properties = linkedMapOf<String, Any>(
                "object_type" to MARKER_OBJECT_TYPE,
                "tappable" to true,
            )
            when (val icon = marker.icon) {
                is MapMarker.Icon.Asset -> properties["icon_asset"] = icon.name
                is MapMarker.Icon.Image -> encodeImage(icon.bitmap)?.let { properties["image_data"] = it }
                is MapMarker.Icon.Text -> {
                    properties["display_text"] = icon.text
                    properties["display_color"] = hexColor(icon.color)
                    properties["text-halo-color"] = hexColor(0xFF000000.toInt())
                }
            }
            marker.heading?.let { heading ->
                var relative = (heading - mapHeading) % 360
                if (relative < 0) relative += 360
                // The engine treats 0 as "no rotation"; nudge so a true north heading still rotates.
                properties["display_heading"] = if (relative == 0.0) 0.001 else relative
            }
            addUserInfo(properties, marker.userInfo)
            feature(
                marker.id,
                mapOf("type" to "Point", "coordinates" to listOf(marker.coordinate.longitude, marker.coordinate.latitude)),
                properties,
            )
        }
        return serialize(features)
    }

    // MARK: Helpers

    private fun feature(id: String, geometry: Map<String, Any>, properties: Map<String, Any>) =
        mapOf("type" to "Feature", "id" to id, "geometry" to geometry, "properties" to properties)

    private fun addUserInfo(properties: MutableMap<String, Any>, userInfo: Map<String, String>) {
        for ((key, value) in userInfo) {
            if (!isReserved(key)) properties[key] = value
        }
    }

    private fun serialize(features: List<Map<String, Any>>): String =
        if (features.isEmpty()) "" else JsonWriter.write(mapOf("type" to "FeatureCollection", "features" to features))

    /** Property names the engine reserves or that the SDK sets itself. */
    private fun isReserved(key: String): Boolean =
        key.startsWith("tectonic_") || key == "object_type" || key == "tappable" || key == "hoverable"

    /**
     * Engine color format: AARRGGBB hex with premultiplied color channels. The engine composites
     * fills and strokes as premultiplied alpha, so a straight-alpha color would render washed out.
     */
    fun hexColor(argb: Int): String {
        val a = (argb ushr 24) and 0xFF
        fun premultiplied(channel: Int) = (channel * a / 255.0).roundToInt()
        val r = premultiplied((argb shr 16) and 0xFF)
        val g = premultiplied((argb shr 8) and 0xFF)
        val b = premultiplied(argb and 0xFF)
        return String.format("%02X%02X%02X%02X", a, r, g, b)
    }

    /** Cache of base64 PNG payloads keyed by bitmap identity, so moving markers do not re-encode. */
    private val imageDataCache = object : LinkedHashMap<IdentityKey, String>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<IdentityKey, String>) = size > 32
    }

    private class IdentityKey(val bitmap: Bitmap) {
        override fun equals(other: Any?) = other is IdentityKey && other.bitmap === bitmap
        override fun hashCode() = System.identityHashCode(bitmap)
    }

    /**
     * Encodes the bitmap at 2x its dp size, because the engine decodes `image_data` at scale 2,
     * and returns it as base64 PNG.
     */
    private fun base64Png(bitmap: Bitmap): String? = synchronized(imageDataCache) {
        val key = IdentityKey(bitmap)
        imageDataCache[key]?.let { return it }
        // Bitmaps without a density are treated as being in device pixels.
        val density = bitmap.density.takeIf { it != Bitmap.DENSITY_NONE }
            ?: Resources.getSystem().displayMetrics.densityDpi
        val scale = 2f * DisplayMetrics.DENSITY_DEFAULT / density
        val width = (bitmap.width * scale).roundToInt().coerceAtLeast(1)
        val height = (bitmap.height * scale).roundToInt().coerceAtLeast(1)
        val scaled = if (width == bitmap.width && height == bitmap.height) {
            bitmap
        } else {
            Bitmap.createScaledBitmap(bitmap, width, height, true)
        }
        val bytes = ByteArrayOutputStream()
        val compressed = scaled.compress(Bitmap.CompressFormat.PNG, 100, bytes)
        if (scaled !== bitmap) scaled.recycle()
        if (!compressed) return null
        Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP).also { imageDataCache[key] = it }
    }
}
