package com.acmeaom.myradar.sdk.internal

import android.content.Context
import android.util.Log
import com.acmeaom.android.tectonic.TectonicGlobalDelegate
import com.acmeaom.android.tectonic.TectonicGlobalState
import com.acmeaom.myradar.sdk.MyRadarSdk
import okhttp3.Cache
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.SimpleTimeZone
import java.util.TimeZone

/**
 * Process-wide engine delegate: performs the engine's HTTP requests, signs those bound for the
 * API gateway, formats dates for hurricane labels and logs engine errors.
 */
internal class TectonicGlobalBridge private constructor(context: Context) : TectonicGlobalDelegate {

    /**
     * The engine's built-in client has no HTTP cache. Tiles and feeds are cached by their
     * `Expires` headers, as `NSURLCache` does for the iOS SDK.
     */
    private val client = OkHttpClient.Builder()
        .cache(Cache(File(context.cacheDir, "myradar-sdk-http"), HTTP_CACHE_BYTES))
        // Every request is moved onto the API gateway or refused; see GatewayInterceptors.kt.
        .addInterceptor(GatewayRoutingInterceptor)
        .addNetworkInterceptor(GatewayEnforcingInterceptor)
        .build()

    /** All engine traffic goes through [client], which only ever talks to the API gateway. */
    override fun newCallFromRequest(request: Request): Call = client.newCall(request)

    override fun shortDateString(timestamp: Long, tzName: String?, tzOffset: Double): String {
        // Unknown zone names resolve to GMT; the engine also supplies the offset in seconds.
        var zone = tzName?.let(TimeZone::getTimeZone) ?: TimeZone.getDefault()
        if (zone.id == "GMT" && tzOffset != 0.0) {
            zone = SimpleTimeZone((tzOffset * 1000).toInt(), "GMT")
        }
        val formatter = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        formatter.timeZone = zone
        return formatter.format(Date(timestamp))
    }

    override fun logNonFatal(s: String?, fileName: String?, lineNumber: Int) {
        Log.w(TAG, "Tectonic non-fatal ($fileName:$lineNumber): $s")
    }

    override fun logFatal(s: String?, fileName: String?, lineNumber: Int) {
        Log.e(TAG, "Tectonic fatal ($fileName:$lineNumber): $s")
    }

    companion object {
        private const val TAG = "MyRadarSDK"
        private const val HTTP_CACHE_BYTES = 100L * 1024 * 1024

        @Volatile private var installed = false

        /** Installs the global delegate exactly once per process. */
        fun installOnce(context: Context) {
            if (installed) return
            synchronized(this) {
                if (installed) return
                TectonicGlobalState.globalDelegate = TectonicGlobalBridge(context.applicationContext)
                installed = true
                Log.i(TAG, "MyRadar Android SDK ${MyRadarSdk.VERSION}")
            }
        }
    }
}
