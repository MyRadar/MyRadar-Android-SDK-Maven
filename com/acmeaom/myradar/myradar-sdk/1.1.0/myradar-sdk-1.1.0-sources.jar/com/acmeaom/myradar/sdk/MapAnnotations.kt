package com.acmeaom.myradar.sdk

import android.graphics.Bitmap
import android.graphics.Color
import androidx.annotation.ColorInt

/**
 * A line drawn on the map through a sequence of coordinates, such as a route or flight path.
 *
 * Assign polylines to [MyRadarMapView.polylines] (or the `polylines` parameter of the Compose
 * `MyRadarMap`). Replacing the list redraws the layer.
 *
 * @property id A stable identifier. Reported back in [MyRadarMapListener.onPolylineTap].
 * @property coordinates The vertices of the line, in order.
 * @property color The stroke color, as an ARGB color int. Defaults to white.
 * @property widthDp The stroke width in dp. Defaults to 3.
 * @property dashPattern Alternating dash and gap lengths in dp, or `null` for a solid line.
 * @property outlineColor An optional contrasting outline drawn around the stroke.
 * @property userInfo Arbitrary values returned with tap events.
 */
public data class MapPolyline @JvmOverloads constructor(
    val id: String,
    val coordinates: List<LatLng>,
    @ColorInt val color: Int = Color.WHITE,
    val widthDp: Float = 3f,
    val dashPattern: List<Float>? = null,
    @ColorInt val outlineColor: Int? = null,
    val userInfo: Map<String, String> = emptyMap(),
)

/**
 * A filled area on the map, such as a flood zone, service area or geofence.
 *
 * Assign polygons to [MyRadarMapView.polygons]. Polygons draw beneath polylines and markers.
 *
 * @property id A stable identifier. Reported back in [MyRadarMapListener.onPolygonTap].
 * @property coordinates The outer ring, in order. It is closed automatically.
 * @property fillColor The fill color. Use the color's alpha for translucency; defaults to 35% blue.
 * @property strokeColor The outline color, or `null` for no outline.
 * @property strokeWidthDp The outline width in dp. Defaults to 1.
 * @property userInfo Arbitrary values returned with tap events.
 */
public data class MapPolygon @JvmOverloads constructor(
    val id: String,
    val coordinates: List<LatLng>,
    @ColorInt val fillColor: Int = DEFAULT_FILL_COLOR,
    @ColorInt val strokeColor: Int? = null,
    val strokeWidthDp: Float = 1f,
    val userInfo: Map<String, String> = emptyMap(),
) {
    public companion object {
        /** 35% opaque blue. */
        @ColorInt public const val DEFAULT_FILL_COLOR: Int = 0x59007AFF
    }
}

/**
 * An icon or text label pinned to a coordinate, such as an aircraft or an airport.
 *
 * Assign markers to [MyRadarMapView.markers]. Replacing the list redraws the layer, which is
 * cheap enough to do every few seconds for moving objects.
 *
 * @property id A stable identifier. Reported back in [MyRadarMapListener.onMarkerTap].
 * @property coordinate Where the marker is anchored.
 * @property icon The marker's appearance.
 * @property heading Rotation in degrees clockwise from true north, or `null` to leave the icon
 *   upright. Supply an icon that points north when unrotated.
 * @property userInfo Arbitrary values returned with tap events.
 */
public data class MapMarker @JvmOverloads constructor(
    val id: String,
    val coordinate: LatLng,
    val icon: Icon,
    val heading: Double? = null,
    val userInfo: Map<String, String> = emptyMap(),
) {
    /** What a marker displays. */
    public sealed interface Icon {
        /**
         * An image packaged with your app, looked up by name: first as an asset file (`name`,
         * `name@2x.png`, `name.png`), then as a drawable resource of that name.
         */
        public data class Asset(val name: String) : Icon

        /**
         * An image provided at runtime. Its size on screen follows the bitmap's density, so a
         * bitmap created for the display (the default for [Bitmap.createBitmap]) keeps its
         * dp size. Reuse the same [Bitmap] instance across updates; encoded images are cached
         * by instance.
         */
        public class Image(public val bitmap: Bitmap) : Icon {
            override fun equals(other: Any?): Boolean = other is Image && other.bitmap === bitmap
            override fun hashCode(): Int = System.identityHashCode(bitmap)
            override fun toString(): String = "Image(${bitmap.width}x${bitmap.height})"
        }

        /** A short text label, for example an airport code. */
        public data class Text @JvmOverloads constructor(
            val text: String,
            @ColorInt val color: Int = Color.WHITE,
        ) : Icon
    }
}
