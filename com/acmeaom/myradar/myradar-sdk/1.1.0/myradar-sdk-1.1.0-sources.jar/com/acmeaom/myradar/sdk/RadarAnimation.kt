package com.acmeaom.myradar.sdk

import androidx.annotation.MainThread
import com.acmeaom.myradar.sdk.internal.PreferenceStore
import com.acmeaom.myradar.sdk.internal.TectonicKeys
import java.util.Date

/**
 * Controls the animated weather (radar) layer of a [MyRadarMapView].
 *
 * Access through [MyRadarMapView.radar]:
 * ```kotlin
 * mapView.radar.isEnabled = true
 * mapView.radar.pause()
 * mapView.radar.scrubberPosition = 0.5f
 * ```
 */
@MainThread
public class RadarAnimation internal constructor(private val preferences: PreferenceStore) {

    // MARK: Layer state

    /** Whether the weather animation layer is displayed. Defaults to `true`. */
    public var isEnabled: Boolean
        get() = preferences.bool(TectonicKeys.WEATHER_ANIMATION_STATUS, default = true)
        set(value) = preferences.set(TectonicKeys.WEATHER_ANIMATION_STATUS, value)

    /** The weather product being animated. Defaults to [RadarProduct.Radar]. */
    public var product: RadarProduct
        get() = RadarProduct.fromEngineValue(
            preferences.int(TectonicKeys.WEATHER_ANIMATION_TYPE, RadarProduct.Radar.engineValue),
        ) ?: RadarProduct.Radar
        set(value) = preferences.set(TectonicKeys.WEATHER_ANIMATION_TYPE, value.engineValue)

    /** Layer opacity in `0..1` for the current [product]. Defaults to `0.65`. */
    public var opacity: Float
        get() = preferences.float(product.opacityPreferenceKey, default = 0.65f)
        set(value) = preferences.set(product.opacityPreferenceKey, value.coerceIn(0f, 1f))

    /**
     * The length of the animation loop in minutes for the current [product], or `null` to use
     * the engine default.
     */
    public var loopLengthMinutes: Int?
        get() = (preferences.value(product.loopLengthPreferenceKey) as? Number)?.toInt()
        set(value) = preferences.set(product.loopLengthPreferenceKey, value)

    // MARK: Playback

    /**
     * Whether the animation timeline is advancing. Defaults to `true`.
     *
     * When paused, the frame indicated by [scrubberPosition] stays on screen.
     */
    public var isPlaying: Boolean
        get() = !preferences.bool(TectonicKeys.WEATHER_ANIMATION_SCRUBBER_STATUS, default = false)
        set(value) = preferences.set(TectonicKeys.WEATHER_ANIMATION_SCRUBBER_STATUS, !value)

    /** Resumes the animation. */
    public fun play() {
        isPlaying = true
    }

    /** Pauses the animation on the current frame. */
    public fun pause() {
        isPlaying = false
    }

    /**
     * Position of the timeline scrubber in `0..1`, where `1` is the most recent frame.
     *
     * Setting this pauses the animation and jumps to the requested frame. While the animation
     * is playing, this reflects the engine-reported playhead.
     */
    public var scrubberPosition: Float
        get() = reportedScrubberPosition
        set(value) {
            val clamped = value.coerceIn(0f, 1f)
            reportedScrubberPosition = clamped
            if (isPlaying) pause()
            preferences.set(TectonicKeys.WEATHER_ANIMATION_SCRUBBER, clamped)
        }

    /** The timestamp of the radar frame currently displayed, or `null` while loading. */
    public var currentFrameDate: Date? = null
        internal set

    /** Latest playhead position reported by the engine. */
    internal var reportedScrubberPosition: Float = 1f
}
