package com.acmeaom.myradar.sdk

/**
 * A geographic coordinate in degrees.
 *
 * @property latitude Degrees north of the equator, in `-90..90`.
 * @property longitude Degrees east of the prime meridian, in `-180..180`.
 */
public data class LatLng(val latitude: Double, val longitude: Double) {

    /** Whether both components are finite and within their valid ranges. */
    public val isValid: Boolean
        get() = latitude.isFinite() && longitude.isFinite() &&
            latitude in -90.0..90.0 && longitude in -180.0..180.0
}

/**
 * A rectangular area of the map described by its center and its extent in degrees,
 * the Android counterpart of MapKit's `MKCoordinateRegion` used by the iOS SDK.
 *
 * @property center The coordinate at the middle of the region.
 * @property latitudeDelta The north-to-south extent in degrees.
 * @property longitudeDelta The east-to-west extent in degrees.
 */
public data class CoordinateRegion(
    val center: LatLng,
    val latitudeDelta: Double,
    val longitudeDelta: Double,
) {
    /** Northern edge latitude. */
    public val north: Double get() = center.latitude + latitudeDelta / 2
    /** Southern edge latitude. */
    public val south: Double get() = center.latitude - latitudeDelta / 2
    /** Eastern edge longitude. */
    public val east: Double get() = center.longitude + longitudeDelta / 2
    /** Western edge longitude. */
    public val west: Double get() = center.longitude - longitudeDelta / 2

    public companion object {
        /**
         * Computes a region that contains all the coordinates, or `null` if there are none.
         *
         * @param coordinates The coordinates to contain. Invalid coordinates are ignored.
         * @param paddingFraction Extra span added around the bounding box, as a fraction of its size.
         */
        @JvmStatic
        @JvmOverloads
        public fun fitting(coordinates: List<LatLng>, paddingFraction: Double = 0.3): CoordinateRegion? {
            val valid = coordinates.filter { it.isValid }
            if (valid.isEmpty()) return null
            val minLat = valid.minOf { it.latitude }
            val maxLat = valid.maxOf { it.latitude }
            val minLon = valid.minOf { it.longitude }
            val maxLon = valid.maxOf { it.longitude }
            val latDelta = maxOf((maxLat - minLat) * (1 + paddingFraction), 0.05)
            val lonDelta = maxOf((maxLon - minLon) * (1 + paddingFraction), 0.05)
            return CoordinateRegion(
                center = LatLng((minLat + maxLat) / 2, (minLon + maxLon) / 2),
                latitudeDelta = minOf(latDelta, 170.0),
                longitudeDelta = minOf(lonDelta, 350.0),
            )
        }
    }
}

/**
 * A viewport described by its center and zoom level.
 *
 * Pass to [MyRadarMapView.setCenter] or to the `camera` parameter of the Compose `MyRadarMap`,
 * which moves the map whenever the value changes.
 *
 * Radar morphing with motion vectors is available for regional views only, roughly zoom 4
 * and closer on a phone. The engine also turns it off when the viewport spans more radar
 * tiles than its mosaic covers, which happens at half-step zooms such as 4.5 or 5.5.
 * Whole-number zoom levels are the safest choice when smooth morphing matters.
 *
 * @property center The coordinate at the center of the viewport.
 * @property zoom The zoom level. Typical values run from 2.5 (continental) to 15 (street).
 */
public data class MapCamera(val center: LatLng, val zoom: Float)

/**
 * An open source license or data attribution that must be displayed in apps using the SDK.
 *
 * @property name The name of the attributed project or data provider.
 * @property url A link to the license text, when available.
 */
public data class Attribution(val name: String, val url: String?)
