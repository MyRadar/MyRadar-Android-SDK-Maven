package com.acmeaom.myradar.sdk.internal

import com.acmeaom.myradar.sdk.LatLng
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A position as (longitude, latitude) in degrees; the longitude may be unwrapped beyond ±180
 * ("unwrapped": 179 → 181 rather than 179 → −179), so lines stay continuous across the date line.
 */
internal data class LngLat(val lng: Double, val lat: Double) {
    constructor(c: LatLng) : this(c.longitude, c.latitude)

    /** The coordinate with its longitude brought back into −180..180. */
    val coordinate: LatLng get() = LatLng(lat, FlightGeometry.normalizedLng(lng))
}

/**
 * Line geometry for flights: following the Earth's curve between distant route points,
 * splitting the planned route at the aircraft, and cutting lines at the date line.
 */
internal object FlightGeometry {

    private const val EARTH_RADIUS_KM = 6371.0
    private const val RAD = Math.PI / 180

    /** `lng` moved by whole turns to lie within 180° of `ref`. */
    fun nearLng(lng: Double, ref: Double): Double = lng + 360 * ((ref - lng) / 360).roundToLong()

    fun normalizedLng(lng: Double): Double {
        val x = (lng + 180) % 360
        return (if (x < 0) x + 360 else x) - 180
    }

    /** Makes a line's longitudes continuous; the first point is moved next to `ref`. */
    fun unwrap(points: List<LngLat>, ref: Double? = null): List<LngLat> {
        var prev = ref
        return points.map { p ->
            val x = prev?.let { nearLng(p.lng, it) } ?: p.lng
            prev = x
            LngLat(x, p.lat)
        }
    }

    /** Great-circle distance in km. */
    fun distanceKm(a: LngLat, b: LngLat): Double {
        val dLat = (b.lat - a.lat) * RAD
        val dLng = (b.lng - a.lng) * RAD
        val h = sin(dLat / 2).pow(2) + cos(a.lat * RAD) * cos(b.lat * RAD) * sin(dLng / 2).pow(2)
        return 2 * EARTH_RADIUS_KM * asin(min(1.0, sqrt(h)))
    }

    /** Points along the great circle from `a` to `b`, `a` excluded and `b` included. */
    private fun greatCircleSteps(a: LngLat, b: LngLat, steps: Int): List<LngLat> {
        val lng1 = a.lng * RAD
        val lat1 = a.lat * RAD
        val lng2 = b.lng * RAD
        val lat2 = b.lat * RAD
        val d = distanceKm(a, b) / EARTH_RADIUS_KM
        val out = (1..steps).map { i ->
            val f = i.toDouble() / steps
            val sa = sin((1 - f) * d) / sin(d)
            val sb = sin(f * d) / sin(d)
            val x = sa * cos(lat1) * cos(lng1) + sb * cos(lat2) * cos(lng2)
            val y = sa * cos(lat1) * sin(lng1) + sb * cos(lat2) * sin(lng2)
            val z = sa * sin(lat1) + sb * sin(lat2)
            LngLat(atan2(y, x) / RAD, atan2(z, sqrt(x * x + y * y)) / RAD)
        }.toMutableList()
        out[out.lastIndex] = b
        return out
    }

    /**
     * Adds points along the great circle wherever two points are more than [maxStepKm] apart, so
     * long legs curve like the flight does. The result is unwrapped.
     */
    fun densify(points: List<LngLat>, maxStepKm: Double = 150.0): List<LngLat> {
        if (points.size < 2) return unwrap(points)
        val out = mutableListOf(points[0])
        for (i in 1 until points.size) {
            val a = points[i - 1]
            val b = points[i]
            val distance = distanceKm(a, b)
            val steps = ceil(distance / maxStepKm).toInt()
            if (steps > 1 && distance < 19_000) out.addAll(greatCircleSteps(a, b, steps)) else out.add(b)
        }
        return unwrap(out)
    }

    data class Projection(val point: LngLat, val index: Int, val distanceKm: Double)

    /** The point of the unwrapped [line] nearest [p], using a local flat projection per segment. */
    fun project(p: LngLat, line: List<LngLat>): Projection? {
        if (line.isEmpty()) return null
        var best: Projection? = null
        for (i in 0 until maxOf(1, line.size - 1)) {
            val a = line[i]
            val b = line[minOf(i + 1, line.lastIndex)]
            val px = nearLng(p.lng, a.lng)
            val k = cos((a.lat + b.lat) / 2 * RAD)
            val dx = (b.lng - a.lng) * k
            val dy = b.lat - a.lat
            val len2 = dx * dx + dy * dy
            val t = if (len2 > 0) (((px - a.lng) * k * dx + (p.lat - a.lat) * dy) / len2).coerceIn(0.0, 1.0) else 0.0
            val point = LngLat(a.lng + t * (b.lng - a.lng), a.lat + t * (b.lat - a.lat))
            val d = distanceKm(point, LngLat(px, p.lat))
            if (best == null || d < best.distanceKm) best = Projection(point, i, d)
        }
        return best
    }

    data class Split(val flown: List<LngLat>, val ahead: List<LngLat>, val aircraft: LngLat)

    /**
     * Splits the planned route at the aircraft: `flown` runs from the origin to the aircraft's
     * place on the route, `ahead` from the aircraft itself to the destination. Both are in the
     * route's unwrapped frame, as is the returned `aircraft`.
     */
    fun split(route: List<LngLat>, aircraft: LngLat): Split {
        val line = densify(route)
        val hit = project(aircraft, line) ?: return Split(emptyList(), emptyList(), aircraft)
        val at = LngLat(nearLng(aircraft.lng, hit.point.lng), aircraft.lat)
        val flown = line.subList(0, hit.index + 1) + hit.point
        val ahead = listOf(at) + line.subList(hit.index + 1, line.size)
        return Split(flown, ahead, at)
    }

    /**
     * Cuts an unwrapped line where it crosses the date line, so each piece stays within
     * −180..180 and draws without wrapping around the world.
     */
    fun cutAtDateLine(line: List<LngLat>): List<List<LatLng>> {
        val first = line.firstOrNull() ?: return emptyList()
        val pieces = mutableListOf<List<LatLng>>()
        var shift = normalizedLng(first.lng) - first.lng
        var current = mutableListOf(first.coordinate)
        for (i in 1 until line.size) {
            val a = line[i - 1]
            val b = line[i]
            // Flight lines are densified, so a segment crosses the date line at most once.
            val bx = b.lng + shift
            if (bx > 180 || bx < -180) {
                val edge = if (bx > 180) 180.0 else -180.0
                val ax = a.lng + shift
                val t = (edge - ax) / (bx - ax)
                val lat = a.lat + t * (b.lat - a.lat)
                current.add(LatLng(lat, edge))
                pieces.add(current)
                current = mutableListOf(LatLng(lat, -edge))
                shift += if (edge > 0) -360 else 360
            }
            current.add(LatLng(b.lat, b.lng + shift))
        }
        pieces.add(current)
        return pieces.filter { it.size >= 2 }
    }
}
