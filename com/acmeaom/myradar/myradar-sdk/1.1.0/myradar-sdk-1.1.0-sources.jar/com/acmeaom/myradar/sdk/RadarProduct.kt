package com.acmeaom.myradar.sdk

import com.acmeaom.myradar.sdk.internal.TectonicKeys

/**
 * The radar product displayed by [RadarAnimation].
 */
public enum class RadarProduct(
    internal val engineValue: Int,
    /** A short human-readable name, useful for building product pickers. */
    public val displayName: String,
    internal val opacityPreferenceKey: String,
    internal val loopLengthPreferenceKey: String,
) {
    /**
     * High-definition morphing radar (default). Smoothly interpolates between scans using
     * motion vectors so the loop plays without stepping between frames.
     *
     * Motion-vector morphing is available for regional views only (roughly zoom 4 and closer
     * on a phone) and is disabled by the engine when the viewport spans more radar tiles than
     * its mosaic covers, which happens at half-step zooms such as 4.5. Continent-wide views
     * fall back to a cross-fade between frames. See [MapCamera].
     */
    Radar(3, "Radar", TectonicKeys.MORPH_RADAR_OPACITY, TectonicKeys.MORPH_RADAR_LOOP_LENGTH),

    /** High-definition radar without morphing. Shows each scan exactly as received. */
    HighDefinitionRadar(1, "HD Radar", TectonicKeys.HD_RADAR_OPACITY, TectonicKeys.HD_RADAR_LOOP_LENGTH),

    /** Standard-definition national composite. Lower resolution, smaller tiles. */
    StandardDefinitionRadar(0, "SD Radar", TectonicKeys.SD_RADAR_OPACITY, TectonicKeys.SD_RADAR_LOOP_LENGTH);

    internal companion object {
        fun fromEngineValue(value: Int): RadarProduct? = entries.firstOrNull { it.engineValue == value }
    }
}
