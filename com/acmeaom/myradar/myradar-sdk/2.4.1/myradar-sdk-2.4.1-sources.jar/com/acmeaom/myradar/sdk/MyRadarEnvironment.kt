package com.acmeaom.myradar.sdk

/**
 * The MyRadar API gateway the SDK sends its requests to, set with [MyRadarSdk.configure].
 *
 * Apps use [PRODUCTION], the default. [DEVELOPMENT] is for MyRadar's own testing of SDK releases
 * before they ship; it may change or be unavailable at any time.
 */
public enum class MyRadarEnvironment(internal val gatewayUrl: String) {
    /** `https://sdkapi.myradar.com`: the gateway for apps. The default. */
    PRODUCTION("https://sdkapi.myradar.com"),

    /** `https://sdkapi.myradar.dev`: MyRadar's development gateway, for testing the SDK itself. */
    DEVELOPMENT("https://sdkapi.myradar.dev"),
}
