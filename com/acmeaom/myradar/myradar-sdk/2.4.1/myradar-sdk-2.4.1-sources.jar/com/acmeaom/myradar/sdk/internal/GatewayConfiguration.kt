package com.acmeaom.myradar.sdk.internal

import com.acmeaom.myradar.sdk.MyRadarEnvironment
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl

/** Where the SDK's requests go and how they are signed. */
internal class GatewayConfiguration private constructor(
    val apiKey: String,
    val environment: MyRadarEnvironment,
) {

    private val baseUrl: HttpUrl = environment.gatewayUrl.toHttpUrl()

    /** Whether a request is addressed to this configuration's gateway (and no other). */
    fun isGateway(url: HttpUrl): Boolean =
        url.scheme == baseUrl.scheme && url.host == baseUrl.host && url.port == baseUrl.port

    companion object {
        /**
         * The environment requests go to: the configured one, else production. The gateway is
         * one of MyRadar's two; apps cannot point the SDK at any other host.
         */
        val environment: MyRadarEnvironment get() = current?.environment ?: MyRadarEnvironment.PRODUCTION

        /** The gateway's base URL, without a trailing slash. */
        val gatewayUrl: String get() = environment.gatewayUrl

        /**
         * A URL on the gateway for a path starting with `/` (which may hold URL template
         * placeholders). Used as is for the flight API and map loads.
         */
        fun endpoint(path: String): String = gatewayUrl + path

        /** The prefix of the maps routes (radar, flow, alerts, lightning, hurricanes, wind). */
        const val MAPS_PREFIX = "/sdk"

        /** A maps route on the gateway: [endpoint] under [MAPS_PREFIX]. */
        fun mapsEndpoint(path: String): String = endpoint(MAPS_PREFIX + path)

        /**
         * The one host the SDK contacts directly, without the API key: MyRadar's base map server.
         * Every base map style references only this host (style JSON, TileJSON, tiles, sprites).
         */
        const val BASE_MAP_HOST = "map2.acmeaom.com"

        /** Whether a request is for base map data, which bypasses the gateway. */
        fun isBaseMap(url: HttpUrl): Boolean = url.isHttps && url.host == BASE_MAP_HOST && url.port == 443

        /** Header the gateway expects the key in. */
        const val HEADER_FIELD = "Ocp-Apim-Subscription-Key"

        fun create(apiKey: String, environment: MyRadarEnvironment = MyRadarEnvironment.PRODUCTION): GatewayConfiguration {
            val key = apiKey.trim()
            require(key.isNotEmpty()) { "MyRadar API key must not be empty" }
            return GatewayConfiguration(key, environment)
        }

        /**
         * The process-wide configuration, read by the HTTP layer for every request. Until it is
         * set, the SDK makes no network requests at all, base maps included.
         */
        @Volatile
        var current: GatewayConfiguration? = null
    }
}

internal const val NOT_CONFIGURED_MESSAGE =
    "MyRadar SDK is not configured: call MyRadarSdk.configure(apiKey) before creating a map"
