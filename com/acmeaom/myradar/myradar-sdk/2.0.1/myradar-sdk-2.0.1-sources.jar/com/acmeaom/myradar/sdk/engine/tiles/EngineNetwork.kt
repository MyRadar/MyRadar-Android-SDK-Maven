package com.acmeaom.myradar.sdk.engine.tiles

import android.content.Context
import android.util.Log
import com.acmeaom.myradar.sdk.internal.GatewayConfiguration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal sealed class EngineNetworkException(message: String) : IOException(message) {
    class RefusedHost(val host: String) : EngineNetworkException("refused host $host")
    class Status(val code: Int) : EngineNetworkException("HTTP $code")
    class NotConfigured : EngineNetworkException("not configured")
}

/**
 * Every request the engine makes goes through here. Requests to the API gateway are signed with
 * the key; requests to the base map host go unsigned, so the key never reaches another host;
 * anything else is refused before it reaches the network. Until the SDK is configured with a
 * key, nothing is requested at all.
 */
internal class EngineNetwork private constructor(private val client: OkHttpClient) {

    /** Fetches a URL, enforcing the host rules. Cancels with the calling coroutine. */
    suspend fun data(url: String): ByteArray {
        val request = signedRequest(url) ?: run {
            val host = url.toHttpUrlOrNull()?.host ?: url
            if (GatewayConfiguration.current == null) throw EngineNetworkException.NotConfigured()
            logRefusalOnce(host)
            throw EngineNetworkException.RefusedHost(host)
        }
        return withContext(Dispatchers.IO) {
            val response = client.newCall(request).await()
            response.use {
                if (!it.isSuccessful) throw EngineNetworkException.Status(it.code)
                it.body.bytes()
            }
        }
    }

    /**
     * The request for a URL: signed for the gateway, unsigned for the base map host, null
     * (refused) for anything else, or for everything before the SDK is configured.
     */
    fun signedRequest(url: String): Request? {
        val gateway = GatewayConfiguration.current ?: return null
        val parsed: HttpUrl = url.toHttpUrlOrNull() ?: return null
        if (!parsed.isHttps) return null
        return when {
            gateway.isGateway(parsed) -> Request.Builder().url(parsed)
                .header(GatewayConfiguration.HEADER_FIELD, gateway.apiKey).build()
            GatewayConfiguration.isBaseMap(parsed) -> Request.Builder().url(parsed).build()
            else -> null
        }
    }

    companion object {
        private const val LOG_TAG = "MyRadarSDK"
        private val loggedRefusals = HashSet<String>()

        private fun logRefusalOnce(host: String) {
            val isNew = synchronized(loggedRefusals) { loggedRefusals.add(host) }
            if (isNew) Log.w(LOG_TAG, "Blocked request to $host: only the MyRadar API gateway and base map host are allowed")
        }

        @Volatile private var shared: EngineNetwork? = null

        /** One client for every map: connections and the disk cache are shared. */
        fun shared(context: Context): EngineNetwork = shared ?: synchronized(this) {
            shared ?: create(File(context.applicationContext.cacheDir, "MyRadarSDK")).also { shared = it }
        }

        /** A client without a disk cache, for tests. */
        fun uncached(): EngineNetwork = EngineNetwork(baseClient().build())

        private fun create(cacheDir: File): EngineNetwork =
            EngineNetwork(baseClient().cache(Cache(cacheDir, 256L shl 20)).build())

        private fun baseClient() = OkHttpClient.Builder()
            // Redirects are followed by OkHttp; a redirect may only stay on an allowed host.
            .addNetworkInterceptor { chain ->
                val request = chain.request()
                val gateway = GatewayConfiguration.current
                val allowed = gateway != null && request.url.isHttps &&
                    (gateway.isGateway(request.url) || GatewayConfiguration.isBaseMap(request.url))
                if (!allowed) throw EngineNetworkException.RefusedHost(request.url.host)
                chain.proceed(request)
            }
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .dispatcher(okhttp3.Dispatcher().apply { maxRequestsPerHost = 6 })
    }
}

private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    enqueue(object : Callback {
        override fun onResponse(call: Call, response: Response) = cont.resume(response)
        override fun onFailure(call: Call, e: IOException) {
            if (!cont.isCancelled) cont.resumeWithException(e)
        }
    })
    cont.invokeOnCancellation { runCatching { cancel() } }
}
