package com.acmeaom.myradar.sdk.internal

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl

/** Where the SDK's requests go and how they are signed. */
internal class GatewayConfiguration private constructor(val apiKey: String) {

    private val baseUrl: HttpUrl get() = GATEWAY_URL

    /** Whether a request is addressed to this gateway. */
    fun isGateway(url: HttpUrl): Boolean =
        url.scheme == baseUrl.scheme && url.host == baseUrl.host && url.port == baseUrl.port

    companion object {
        /**
         * The MyRadar API gateway: the only host the SDK sends API requests to. Fixed; apps cannot
         * point the SDK at another one.
         */
        val GATEWAY_URL: HttpUrl = "https://sdkwrapperapi.azure-api.net".toHttpUrl()

        /** A URL on the gateway for a path starting with `/` (which may hold URL template placeholders). */
        fun endpoint(path: String): String = GATEWAY_URL.toString().trimEnd('/') + path

        /**
         * The one host the SDK contacts directly, without the API key: MyRadar's base map server.
         * Every base map style references only this host (style JSON, TileJSON, tiles, sprites).
         */
        const val BASE_MAP_HOST = "map2.acmeaom.com"

        /** Whether a request is for base map data, which bypasses the gateway. */
        fun isBaseMap(url: HttpUrl): Boolean = url.isHttps && url.host == BASE_MAP_HOST && url.port == 443

        /** Header the gateway expects the key in. */
        const val HEADER_FIELD = "Ocp-Apim-Subscription-Key"

        fun create(apiKey: String): GatewayConfiguration {
            val key = apiKey.trim()
            require(key.isNotEmpty()) { "MyRadar API key must not be empty" }
            return GatewayConfiguration(key)
        }

        /**
         * The process-wide configuration, read by the HTTP layer for every request. Until it is
         * set, the SDK makes no network requests at all, base maps included.
         */
        @Volatile
        var current: GatewayConfiguration? = null
    }
}

internal const val NOT_CONFIGURED_MESSAGE =
    "MyRadar SDK is not configured: call MyRadarSdk.configure(apiKey) before creating a map"
