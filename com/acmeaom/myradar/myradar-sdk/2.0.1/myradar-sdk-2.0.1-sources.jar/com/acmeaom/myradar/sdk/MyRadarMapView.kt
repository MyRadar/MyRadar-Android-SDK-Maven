package com.acmeaom.myradar.sdk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.annotation.MainThread
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.findViewTreeLifecycleOwner
import com.acmeaom.myradar.sdk.engine.MapEngineListener
import com.acmeaom.myradar.sdk.engine.MapEngineView
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.engine.camera.ScreenPoint
import com.acmeaom.myradar.sdk.engine.overlays.AnnotationsRenderer
import com.acmeaom.myradar.sdk.engine.overlays.HurricanesSettings
import com.acmeaom.myradar.sdk.engine.overlays.LightningSettings
import com.acmeaom.myradar.sdk.engine.overlays.WarningsSettings
import com.acmeaom.myradar.sdk.engine.overlays.WindSettings
import com.acmeaom.myradar.sdk.engine.radar.RadarSettings
import com.acmeaom.myradar.sdk.internal.FlightController
import com.acmeaom.myradar.sdk.internal.NOT_CONFIGURED_MESSAGE
import com.acmeaom.myradar.sdk.internal.PreferenceStore
import com.acmeaom.myradar.sdk.internal.isEndpoint
import com.acmeaom.myradar.sdk.internal.EngineKeys
import org.json.JSONArray
import org.json.JSONObject
import java.util.Date
import kotlin.math.abs
import kotlin.math.max

/**
 * An interactive weather map view displaying MyRadar base maps and animated radar.
 *
 * `MyRadarMapView` is the primary entry point of the MyRadar Android SDK. Add it to your view
 * hierarchy like any other view, in code or in XML; the radar animation is enabled and playing
 * by default.
 *
 * ```kotlin
 * val mapView = MyRadarMapView(context)
 * mapView.center = LatLng(35.2, -97.4)
 * mapView.zoomLevel = 6f
 * container.addView(mapView)
 * ```
 *
 * [MyRadarSdk.configure] must be called first. Without an API key the map makes no network
 * requests, and shows a notice saying the SDK is not configured.
 *
 * Rendering starts automatically when the view is attached to a window whose lifecycle owner
 * is started, and stops when the view is detached or the owner stops (for example when the app
 * moves to the background).
 *
 * All methods must be called on the main thread.
 */
@MainThread
public class MyRadarMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    // MARK: Public API

    /** Receives map movement, radar animation and tap events. */
    public var listener: MyRadarMapListener? = null

    /** The base map appearance. Defaults to [MapStyle.Gray]. */
    public var mapStyle: MapStyle
        get() = MapStyle.fromEngineValue(preferences.int(EngineKeys.MAP_TILE_TYPE, MapStyle.Gray.engineValue))
            ?: MapStyle.Gray
        set(value) = preferences.set(EngineKeys.MAP_TILE_TYPE, value.engineValue)

    /** The coordinate at the center of the viewport. Setting it cancels a camera animation. */
    public var center: LatLng
        get() = engineView.centerCoordinate
        set(value) {
            engineView.centerCoordinate = value
        }

    /** The map zoom level. Valid values are typically between 2.5 (continental) and 15 (street). */
    public var zoomLevel: Float
        get() = engineView.zoom.toFloat()
        set(value) {
            engineView.zoom = value.toDouble()
        }

    /** Map rotation in degrees clockwise from north. */
    public var heading: Float
        get() = engineView.heading.toFloat()
        set(value) {
            engineView.heading = value.toDouble()
        }

    /** Perspective tilt in degrees from straight down. */
    public var tilt: Float
        get() = engineView.tilt.toFloat()
        set(value) {
            engineView.tilt = value.toDouble()
        }

    /** Moves the viewport to a coordinate and zoom level, optionally animated. */
    public fun setCenter(center: LatLng, zoomLevel: Float, animated: Boolean) {
        engineView.setCenter(center, zoomLevel.toDouble(), animated && isAttachedToWindow)
    }

    /** Moves the viewport to a camera, optionally animated. */
    public fun setCamera(camera: MapCamera, animated: Boolean) {
        setCenter(camera.center, camera.zoom, animated)
    }

    /**
     * Moves the viewport so that a coordinate region is visible, optionally animated.
     *
     * The zoom that fits the region depends on the view's size, so a call made before the map
     * has been laid out is applied (without animation) once its size is known.
     */
    public fun setVisibleRegion(region: CoordinateRegion, animated: Boolean) {
        if (!hasSize) {
            pendingRegion = region
            engineView.centerCoordinate = region.center
            return
        }
        pendingRegion = null
        setCenter(region.center, fittingZoom(region), animated)
    }

    /** The zoom that fits [region], raised to the engine's minimum, which ignores anything smaller. */
    private fun fittingZoom(region: CoordinateRegion): Float = zoomLevelFor(region).let {
        if (it.isFinite()) max(it, MIN_ZOOM_LEVEL) else zoomLevel
    }

    /**
     * Moves the viewport so that all given coordinates are visible, with padding.
     *
     * @param coordinates The coordinates that must be on screen. Invalid coordinates are ignored.
     * @param paddingFraction Extra span added around the bounding box, as a fraction of its size.
     * @param animated Whether to animate the camera change.
     */
    @JvmOverloads
    public fun setVisibleCoordinates(coordinates: List<LatLng>, paddingFraction: Double = 0.3, animated: Boolean) {
        CoordinateRegion.fitting(coordinates, paddingFraction)?.let { setVisibleRegion(it, animated) }
    }

    /**
     * The map coordinate under a point in the view, in pixels from its top left (as touch events
     * report them), or `null` when the point is above the horizon of a tilted map.
     */
    public fun coordinateAt(x: Float, y: Float): LatLng? {
        val density = resources.displayMetrics.density
        return engineView.coordinate(x / density, y / density)
    }

    /**
     * Computes the zoom level that fits a coordinate region in the current viewport. The view
     * must have been laid out for the result to be meaningful.
     */
    public fun zoomLevelFor(region: CoordinateRegion): Float {
        return engineView.zoomFitting(region.latitudeDelta, region.longitudeDelta, region.center.latitude).toFloat()
    }

    // MARK: Text size

    /**
     * How large the map draws its text, as a multiple of the default size: base map labels
     * (places, roads), hurricane labels, flight labels and text markers.
     *
     * `null`, the default, follows the system font size and updates when it changes, up to 1.6× at
     * the largest sizes, where the map stops growing so it stays readable. Set a number to choose
     * the size yourself, from 0.5 to 3; `1` keeps the default size whatever the system setting.
     */
    public var textScale: Float? = null
        set(value) {
            field = value
            updateTextScale()
        }

    /** The text scale in effect: [textScale] when set, otherwise the one the system font size gives. */
    public var effectiveTextScale: Float = 1f
        private set

    private fun updateTextScale() {
        val scale = textScale?.coerceIn(0.5f, 3f) ?: systemTextScale(resources.displayMetrics)
        if (scale == effectiveTextScale) return
        effectiveTextScale = scale
        engineView.textScale = scale
        flightController?.textScale = scale
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration?) {
        super.onConfigurationChanged(newConfig)
        updateTextScale()
    }

    // MARK: Flights

    /**
     * The flight shown with [showFlight], updated as new data arrives; `null` when no flight is
     * shown or it is still loading.
     */
    public val flight: FlightInfo?
        get() = flightController?.info

    /**
     * Shows a flight by its flight number (`UA1`, `UA 1`) or callsign (`UAL1`): the route it
     * filed, the track it has flown, the route still ahead, its airports and the aircraft.
     *
     * When a flight number has several departures, the one in the air is shown, otherwise the
     * one that landed most recently (within a day), otherwise the next one scheduled. The flight
     * updates every minute until it lands; each update is reported to
     * [MyRadarMapListener.onFlightUpdate]. Showing another flight replaces this one. The flight
     * is drawn alongside [polylines] and [markers], which stay yours.
     *
     * ```kotlin
     * lifecycleScope.launch {
     *     val flight = mapView.showFlight("UA1")
     *     println("${flight.status} ${flight.destination?.code}")
     * }
     * ```
     *
     * @return The flight as first loaded.
     * @throws FlightException when the flight can't be shown.
     * @throws kotlinx.coroutines.CancellationException when another [showFlight] or
     *   [removeFlight] replaced it while it loaded.
     */
    @JvmOverloads
    public suspend fun showFlight(ident: String, options: FlightOptions = FlightOptions()): FlightInfo {
        val controller = flightController ?: FlightController(flightHost, resources.displayMetrics, engineView.network).also {
            it.textScale = effectiveTextScale
            flightController = it
            if (!isAttachedToWindow) it.pause()
        }
        return controller.show(ident, options)
    }

    /** Removes the flight shown with [showFlight] and stops updating it. */
    public fun removeFlight() {
        flightController?.clear()
    }

    /** Moves the map to show the whole flight again. */
    @JvmOverloads
    public fun fitToFlight(animated: Boolean = true) {
        flightController?.fit(animated)
    }

    // MARK: Polygons, polylines and markers

    /** Lines drawn on top of the weather layers. Replacing the list redraws them. */
    public var polylines: List<MapPolyline> = emptyList()
        set(value) {
            if (field == value) return
            field = value
            pushShapes()
        }

    /** Filled areas drawn on top of the weather layers, beneath polylines and markers. */
    public var polygons: List<MapPolygon> = emptyList()
        set(value) {
            if (field == value) return
            field = value
            pushShapes()
        }

    /** Icons and labels pinned to coordinates. Replacing the list redraws them. */
    public var markers: List<MapMarker> = emptyList()
        set(value) {
            if (field == value) return
            field = value
            pushMarkers()
        }

    // MARK: Overlays

    /** Shows or hides an additional data overlay. */
    public fun setOverlay(overlay: Overlay, enabled: Boolean) {
        preferences.set(overlay.statusPreferenceKey, enabled)
    }

    /** Whether an overlay is currently shown. */
    public fun isOverlayEnabled(overlay: Overlay): Boolean = preferences.bool(overlay.statusPreferenceKey)

    /**
     * Sets an overlay's opacity in `0..1`. Ignored for overlays where [Overlay.supportsOpacity]
     * is `false`. For [Overlay.Warnings] the value applies to warnings, and watches are drawn
     * at half of it.
     */
    public fun setOpacity(opacity: Float, overlay: Overlay) {
        val clamped = opacity.coerceIn(0f, 1f)
        for ((key, scale) in overlay.opacityPreferenceKeys) {
            preferences.set(key, clamped * scale)
        }
    }

    /** The overlay's current opacity, or `null` if the overlay has no opacity control. */
    public fun opacity(overlay: Overlay): Float? {
        val primary = overlay.opacityPreferenceKeys.firstOrNull() ?: return null
        val fallback = overlay.defaultOpacity ?: return null
        return preferences.float(primary.first, fallback)
    }

    /**
     * Sets a raw rendering engine preference.
     *
     * Deprecated: use the typed API instead ([radar], [setOverlay], [setOpacity], [mapStyle]). Only
     * keys the typed API also controls still have an effect; others are ignored. Pass `null` to
     * restore the default for the key.
     *
     * Endpoint URLs are fixed by the SDK: keys that hold a URL, and values that look like one, are
     * ignored.
     */
    @Deprecated(
        "Use the typed API (radar, setOverlay, setOpacity, mapStyle). Raw engine preferences will be " +
            "removed in a future release.",
    )
    public fun setAdvancedPreference(key: String, value: Any?) {
        if (EngineKeys.isEndpoint(key, value)) {
            Log.w(LOG_TAG, "setAdvancedPreference ignored for $key: endpoint URLs cannot be changed")
            return
        }
        preferences.set(key, value)
    }

    // MARK: Rendering and snapshots

    /**
     * Whether the map is actively rendering.
     *
     * Managed automatically from attachment and lifecycle; use [setRenderingEnabled] only if you
     * need manual control.
     */
    public var isRenderingEnabled: Boolean = false
        private set

    /**
     * Manually starts or stops rendering. Rendering must be stopped while the app is in the
     * background.
     */
    public fun setRenderingEnabled(enabled: Boolean) {
        if (enabled == isRenderingEnabled) return
        isRenderingEnabled = enabled
        engineView.setRendering(enabled)
    }

    /**
     * Captures the currently displayed map as a bitmap and delivers it on the main thread, or
     * delivers `null` if the map is not rendering.
     */
    public fun snapshot(callback: (Bitmap?) -> Unit) {
        if (!isRenderingEnabled) {
            callback(null)
            return
        }
        callback(engineView.snapshot())
    }

    public companion object {
        /**
         * Open source licenses and attributions that must be presented within your app, for
         * example on an about or legal screen.
         */
        @JvmStatic
        public fun licensesAndAttributions(context: Context): List<Attribution> = ATTRIBUTIONS

        /**
         * What apps must credit: the map and weather data the SDK shows, and the open source code
         * and algorithms it contains.
         */
        private val ATTRIBUTIONS = listOf(
            // Map data (the base map styles' TileJSON attributions).
            Attribution("© OpenStreetMap contributors", "https://www.openstreetmap.org/copyright"),
            Attribution("© OpenMapTiles", "https://openmaptiles.org"),
            Attribution("© MapTiler (satellite imagery, contours)", "https://www.maptiler.com/copyright/"),
            // Weather data.
            Attribution("Australian radar: Bureau of Meteorology",
                "https://www.bom.gov.au/data-access/3rd-party-attribution.shtml"),
            Attribution("Météo-France", "https://meteofrance.com"),
            Attribution("Deutscher Wetterdienst Copyright",
                "https://www.dwd.de/EN/service/legal_notice/legal_notice_node.html"),
            Attribution("Deutscher Wetterdienst",
                "https://www.dwd.de/EN/service/legal_notice/templates_dwd_as_source.html?nn=450678"),
            // Open source code and algorithms in the SDK.
            Attribution("earcut (ISC License, © Mapbox)", "https://github.com/mapbox/earcut/blob/main/LICENSE"),
            Attribution("TinySDF (BSD 2-Clause License, © Mapbox)",
                "https://github.com/mapbox/tiny-sdf/blob/main/LICENSE.txt"),
            Attribution("Mapbox GL JS (BSD 3-Clause License, © Mapbox)",
                "https://github.com/mapbox/mapbox-gl-js/blob/v1.13.0/LICENSE.txt"),
            Attribution("Inter (SIL Open Font License 1.1, © The Inter Project Authors)",
                "https://github.com/rsms/inter/blob/master/LICENSE.txt"),
            Attribution("OkHttp and Okio (Apache License 2.0, © Square)", "https://square.github.io/okhttp/#license"),
            Attribution("kotlinx.coroutines (Apache License 2.0, © JetBrains)",
                "https://github.com/Kotlin/kotlinx.coroutines/blob/master/LICENSE.txt"),
        )

        /** The engine's smallest zoom level (continental scale). */
        private const val MIN_ZOOM_LEVEL = 2.5f
        private const val LOG_TAG = "MyRadarSDK"
    }

    /** Controls the animated radar layer. */
    public val radar: RadarAnimation

    // MARK: Private

    private val preferences: PreferenceStore
    private val engineView: MapEngineView
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingRegion: CoordinateRegion? = null
    private val hasSize: Boolean get() = width > 0 && height > 0
    private var lifecycleOwner: LifecycleOwner? = null
    private var configurationNotice: TextView? = null
    private var flightController: FlightController? = null

    private val flightHost = object : FlightController.Host {
        override fun flightShapesDidChange() {
            pushShapes()
            pushMarkers()
        }

        override fun flightDidUpdate(info: FlightInfo) {
            listener?.onFlightUpdate(this@MyRadarMapView, info)
        }

        override fun flightDidFail(error: FlightException) {
            listener?.onFlightError(this@MyRadarMapView, error)
        }

        override fun fitRegion(region: CoordinateRegion, animated: Boolean) {
            setVisibleRegion(region, animated)
        }
    }

    private val engineListener = object : MapEngineListener {
        override fun engineDidMove(engine: MapEngineView) {
            listener?.onMapMoved(this@MyRadarMapView)
        }

        override fun engineDidStopMoving(engine: MapEngineView) {
            listener?.onMapStoppedMoving(this@MyRadarMapView)
        }

        override fun engineDidTap(engine: MapEngineView, x: Float, y: Float) {
            handleTap(x, y)
        }
    }

    private val lifecycleObserver = LifecycleEventObserver { _, event ->
        when (event) {
            Lifecycle.Event.ON_START -> setRenderingEnabled(isAttachedToWindow)
            Lifecycle.Event.ON_STOP -> setRenderingEnabled(false)
            else -> Unit
        }
    }

    init {
        preferences = PreferenceStore(EngineKeys.initialValues())
        radar = RadarAnimation(preferences)
        engineView = MapEngineView(context, EngineNetwork.shared(context))
        engineView.listener = engineListener

        preferences.onChange = { key ->
            // Settings reach the engine on the main thread.
            if (Looper.myLooper() == Looper.getMainLooper()) preferenceChanged(key)
            else mainHandler.post { preferenceChanged(key) }
        }
        addView(engineView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // A sensible default viewport: continental United States.
        engineView.centerCoordinate = LatLng(39.5, -98.35)
        engineView.zoom = 4.0
        engineView.radar.onFrameDate = { handleRadarFrame(it) }
        engineView.radar.onScrubber = { handleScrubberPosition(it) }
        engineView.radar.onPalette = { handleRadarPalette(it) }
        applyMapStyle()
        applyRadarSettings()
        applyWindSettings()
        applyWarningsSettings()
        applyLightningSettings()
        applyHurricanesSettings()
        updateTextScale()

        updateConfigurationNotice()
    }

    private fun preferenceChanged(key: String) {
        if (key == EngineKeys.MAP_TILE_TYPE) applyMapStyle()
        applyRadarSettings()
        applyWindSettings()
        applyWarningsSettings()
        applyLightningSettings()
        applyHurricanesSettings()
        engineView.setNeedsRender()
    }

    /** The radar's settings from the preferences the public API writes. */
    private fun applyRadarSettings() {
        engineView.radar.settings = RadarSettings(
            enabled = radar.isEnabled,
            product = radar.product,
            opacity = radar.opacity,
            loopLengthMinutes = radar.loopLengthMinutes,
            futureRadar = radar.showsFutureRadar,
            speed = radar.speed,
            stepFrames = radar.transition == RadarTransition.Step,
            scrubbing = !radar.isPlaying,
            scrubberValue = preferences.float(EngineKeys.WEATHER_ANIMATION_SCRUBBER, 0f),
            // `FWWeatherModule::_isLightBasemap`: the light palette and alpha blending over these maps.
            lightBasemap = mapStyle == MapStyle.Roads || mapStyle == MapStyle.Topographic,
        )
    }

    private fun applyWindSettings() {
        engineView.wind.settings = WindSettings(
            enabled = preferences.bool(EngineKeys.WIND_STATUS),
            opacity = preferences.float(EngineKeys.WIND_OPACITY, 0.65f),
        )
    }

    /** The warnings overlay's settings. Watches stay off, as they always have in the SDK. */
    private fun applyWarningsSettings() {
        val tags = preferences.string(EngineKeys.WARNINGS_ENABLED_TAGS)
        engineView.warnings.settings = WarningsSettings(
            showWarnings = preferences.bool(EngineKeys.WARNINGS_STATUS),
            warningsAlpha = preferences.float(EngineKeys.WARNINGS_ALPHA, 0.4f),
            watchesAlpha = preferences.float(EngineKeys.WATCHES_ALPHA, 0.2f),
            enabledTags = (tags ?: EngineKeys.defaultWarningsTags).lowercase().split(","),
        )
    }

    /** Lightning markers and flashes, which follow the radar loop. */
    private fun applyLightningSettings() {
        engineView.lightning.settings = LightningSettings(
            markers = preferences.bool(EngineKeys.LIGHTNING_MARKERS_STATUS),
            flashes = preferences.bool(EngineKeys.LIGHTNING_EFFECT_STATUS),
            radarEnabled = radar.isEnabled,
        )
    }

    /** Hurricanes: the storm center, tracks and cone, all on as the SDK has always set them. */
    private fun applyHurricanesSettings() {
        engineView.hurricanes.settings = HurricanesSettings(
            enabled = preferences.bool(EngineKeys.HURRICANES_STATUS),
            futureTrack = preferences.bool(EngineKeys.HURRICANES_TRACK_ENABLED, true),
            pastTrack = preferences.bool(EngineKeys.HURRICANES_PAST_TRACK_ENABLED, true),
            cone = preferences.bool(EngineKeys.HURRICANES_CONE_ENABLED, true),
            stormCenter = preferences.bool(EngineKeys.HURRICANES_STORM_CENTER_ENABLED, true),
            opacity = preferences.float(EngineKeys.HURRICANES_OPACITY, 0.65f),
        )
    }

    private fun applyMapStyle() {
        engineView.setStyleUrl(mapStyle.styleUrl)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) {
            pendingRegion?.let { region ->
                pendingRegion = null
                // The engine view learns its size in the same layout pass.
                post { setCenter(region.center, fittingZoom(region), animated = false) }
            }
        }
    }

    /**
     * Without an API key the SDK refuses every request, so the map would stay empty with no
     * explanation. Say why, on the map itself and in the log.
     */
    private fun updateConfigurationNotice() {
        val configured = MyRadarSdk.isConfigured
        if (configured) {
            configurationNotice?.let(::removeView)
            configurationNotice = null
            return
        }
        if (configurationNotice != null) return
        Log.e(LOG_TAG, NOT_CONFIGURED_MESSAGE)
        val density = resources.displayMetrics.density
        configurationNotice = TextView(context).apply {
            text = NOT_CONFIGURED_MESSAGE
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(217, 160, 20, 20))
            val padding = (16 * density).toInt()
            setPadding(padding, padding, padding, padding)
        }
        addView(configurationNotice, LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    // MARK: Lifecycle

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // The app may have configured the SDK after creating this view.
        updateConfigurationNotice()
        flightController?.resume()
        val owner = findViewTreeLifecycleOwner()
        lifecycleOwner = owner
        if (owner != null) {
            // Delivers ON_START immediately when the owner is already started.
            owner.lifecycle.addObserver(lifecycleObserver)
        } else {
            setRenderingEnabled(windowVisibility == View.VISIBLE)
        }
    }

    override fun onDetachedFromWindow() {
        lifecycleOwner?.lifecycle?.removeObserver(lifecycleObserver)
        lifecycleOwner = null
        // A detached map stops polling its flight; reattaching resumes it.
        flightController?.pause()
        setRenderingEnabled(false)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        // Without a lifecycle owner, follow window visibility instead.
        if (lifecycleOwner == null && isAttachedToWindow) {
            setRenderingEnabled(visibility == View.VISIBLE)
        }
    }

    // MARK: Annotations

    private fun pushShapes() {
        engineView.annotations.setShapes(polygons, flightController?.polylines.orEmpty() + polylines)
    }

    private fun pushMarkers() {
        engineView.annotations.setMarkers(flightController?.markers.orEmpty() + markers)
    }

    // MARK: Taps

    /** Routes a tap (in dp) to the typed marker, polyline and polygon callbacks. */
    private fun handleTap(x: Float, y: Float) {
        for (hit in engineView.annotations.hits(ScreenPoint(x.toDouble(), y.toDouble()), engineView.transform)) {
            when (hit) {
                // Flight markers and lines aren't the app's; only report its own.
                is AnnotationsRenderer.Hit.Marker ->
                    if (markers.any { it.id == hit.marker.id }) listener?.onMarkerTap(this, hit.marker)
                is AnnotationsRenderer.Hit.Polyline ->
                    if (polylines.any { it.id == hit.polyline.id }) listener?.onPolylineTap(this, hit.polyline)
                is AnnotationsRenderer.Hit.Polygon -> listener?.onPolygonTap(this, hit.polygon)
            }
        }
        val graphics = engineView.graphics(x, y)
        if (graphics.isNotEmpty()) {
            listener?.onGraphicsTap(this, graphics.map { JSONObject(it).toString() }, PointF(x, y))
        }
    }

    internal fun handleRadarFrame(date: Date?) {
        radar.currentFrameDate = date
        listener?.onRadarFrame(this, date)
    }

    internal fun handleScrubberPosition(position: Float) {
        radar.reportedScrubberPosition = position
        listener?.onRadarScrubberPosition(this, position)
    }

    internal fun handleRadarPalette(json: String?) {
        listener?.onRadarPalette(this, json)
    }
}

/**
 * The system font size relative to the default, measured the way text is (`sp`, including
 * Android 14's nonlinear scaling of large text), kept to `0.8..1.6`.
 */
internal fun systemTextScale(metrics: android.util.DisplayMetrics): Float {
    val base = 14f
    val scaled = android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_SP, base, metrics)
    val ratio = scaled / (base * metrics.density)
    return if (ratio.isFinite() && ratio > 0) ratio.coerceIn(0.8f, 1.6f) else 1f
}

/** The base map style drawn for this map style. */
internal val MapStyle.styleUrl: String
    get() {
        val name = when (this) {
            MapStyle.Gray -> "dark-v2"
            MapStyle.Roads -> "light-v2"
            MapStyle.Aerial -> "hybrid"
            MapStyle.Topographic -> "topo"
            MapStyle.Dark -> "pro-dark"
            MapStyle.Light -> "pro-light"
        }
        return "https://map2.acmeaom.com/styles/$name/style.json"
    }
