package com.acmeaom.myradar.sdk.engine.overlays

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.acmeaom.myradar.sdk.engine.EngineAssets
import com.acmeaom.myradar.sdk.engine.basemap.RGBA
import java.nio.ByteBuffer
import kotlin.math.ceil

/**
 * The hurricane layer's images, as the engine's `FWHurricaneGraphicsFactory` makes them: storm
 * glyphs and track point markers from the engine's SVG resources (their path data is copied
 * here and drawn with an Android canvas, sized as nanosvg rasterizes them: 1pt = 1 point) and
 * tinted with the storm's color, plus date labels in white on a 60% black box.
 *
 * Canvases here run in points with y down, like SVG, so nothing is flipped.
 */
internal object HurricaneGraphics {
    // MARK: SVG resources

    /** One SVG document: its size in points, view box, and filled or stroked paths. */
    private class SVGIcon(
        val size: Float,
        /** x, y, width, height */
        val viewBox: RectF,
        /** Applied inside the view box (an SVG group transform). */
        val groupTransform: Matrix? = null,
        val path: String,
        /** Stroke width and round cap, for stroked icons. */
        val stroke: Pair<Float, Boolean>? = null,
    )

    private fun viewBox(x: Float, y: Float, w: Float, h: Float) = RectF(x, y, x + w, y + h)

    /** `hurricanes_hurricane.svg` */
    private val hurricane = SVGIcon(
        size = 36f, viewBox = viewBox(-2f, -2f, 40f, 40f),
        path = "M17.645,8.599C11.993,4.724 19.668,0.345 19.889,0.234 11.929,-1.331 0.335,5.13 0.005,14.269 " +
            "-0.237,20.953 8.332,26.434 17.645,26.379 22.59,29.909 15.847,34.205 15.292,34.632 " +
            "23.168,36.34 34.793,31.646 35.286,20.71 35.585,14.027 27.964,8.625 17.645,8.599",
    )

    /** `hurricanes_tropical_depression.svg` */
    private val tropicalDepression = SVGIcon(
        size = 36f, viewBox = viewBox(-5f, -5f, 40f, 40f),
        path = "M29.9145,14.9588 C29.9145,23.2197 23.2197,29.9145 14.9588,29.9145 C6.69942,29.9145 0,23.2197 " +
            "0,14.9588 C0,6.69942 6.69942,0 14.9588,0 C23.2197,0 29.9145,6.69942 29.9145,14.9588",
    )

    /** `hurricanes_tropical_storm.svg` */
    private val tropicalStorm = SVGIcon(
        size = 36f, viewBox = viewBox(-2f, -2f, 40f, 40f),
        path = "M21.33,19.53C19.536,23.035 14.055,21.756 14.051,17.786 10.136,16.496 6.861,13.985 9.82,9.199 " +
            "8.031,13.461 11.185,15.016 14.561,15.899 16.483,12.489 21.711,13.926 21.762,17.732 " +
            "25.818,19.101 28.515,21.986 25.877,26.252 26.737,24.203 27.158,21.283 21.33,19.53 " +
            "M17.909,8.665C13.636,6.162 17.2,1.858 20.184,0.232 12.437,-1.144 2.917,3.728 0.494,11.459 " +
            "-2.666,21.539 10.053,26.591 17.909,26.591 21.978,28.814 18.108,33.293 15.525,34.911 " +
            "23.547,36.508 33.135,32.06 35.389,23.795 38.192,13.507 26.095,8.665 17.909,8.665",
    )

    /** `hurricanes_extra_tropical_depression.svg` */
    private val extraTropicalDepression = SVGIcon(
        size = 36f, viewBox = viewBox(-2f, -2f, 40f, 40f),
        groupTransform = Matrix().apply { setTranslate(3f, 3f) },
        path = "M22.2915,21.9255 L21.81,22.407 C21.357,22.86 20.622,22.86 20.169,22.407 L14.6265,16.8645 " +
            "L9.0825,22.407 C8.631,22.86 7.8945,22.86 7.443,22.407 L6.96,21.9255 C6.5085,21.4725 6.5085,20.7375 " +
            "6.96,20.2845 L12.504,14.742 L6.96,9.1995 C6.5085,8.745 6.5085,8.0115 6.96,7.5585 L7.443,7.0755 " +
            "C7.8945,6.624 8.631,6.624 9.0825,7.0785 L14.6265,12.621 L20.169,7.0785 C20.622,6.624 21.357,6.624 " +
            "21.81,7.0755 L22.2915,7.5585 C22.7445,8.0115 22.7445,8.745 22.29,9.1995 L16.749,14.742 " +
            "L22.2915,20.2845 C22.7445,20.7375 22.7445,21.4725 22.2915,21.9255 M14.7435,0 C6.603,0 0,6.603 " +
            "0,14.7435 C0,22.8855 6.603,29.484 14.7435,29.484 C22.8855,29.484 29.484,22.8855 29.484,14.7435 " +
            "C29.484,6.603 22.8855,0 14.7435,0",
    )

    /** `hurricanes_remnants_of.svg` */
    private val remnants = SVGIcon(
        size = 18f, viewBox = viewBox(-4f, -4f, 44f, 44f),
        groupTransform = Matrix().apply { setScale(2f, 2f) },
        path = "M1,1 L17,17 M17,1 L1,17", stroke = 4f to true,
    )

    /** The glyph for a storm (`createHurricaneIconBitmap`). */
    fun stormIcon(glyph: String, color: RGBA, scale: Float): SpriteImage? {
        val icon = when (glyph) {
            "Hurricane" -> hurricane
            "TropicalDepression" -> tropicalDepression
            "TropicalStorm" -> tropicalStorm
            "PostTropicalCyclone" -> extraTropicalDepression
            "Remnants" -> remnants
            else -> tropicalDepression
        }
        return render(icon, scale)?.multiplied(color)
    }

    private fun render(icon: SVGIcon, scale: Float): SpriteImage? =
        SpriteImage.draw(icon.size, icon.size, scale) { canvas ->
            // The view box fills the document, as SVG's default preserveAspectRatio does for squares.
            val s = icon.size / icon.viewBox.width()
            canvas.scale(s, s)
            canvas.translate(-icon.viewBox.left, -icon.viewBox.top)
            icon.groupTransform?.let { canvas.concat(it) }
            val path = SVGPath.path(icon.path)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
            val stroke = icon.stroke
            if (stroke != null) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = stroke.first
                paint.strokeCap = if (stroke.second) Paint.Cap.ROUND else Paint.Cap.BUTT
            } else {
                // nanosvg fills with the nonzero rule.
                path.fillType = Path.FillType.WINDING
                paint.style = Paint.Style.FILL
            }
            canvas.drawPath(path, paint)
        }

    /**
     * A past or forecast track point (`createHurricanePointBitmap`): `hurricanes_prior_point.svg`
     * (a black circle of radius 8pt under a #eee one of 7.5pt at 85% opacity; nanosvg reads the
     * first circle's "#0000" as black) tinted with the storm color, with the first letter of its
     * category drawn white in the middle at 13.5pt.
     */
    fun pointIcon(letter: String, color: RGBA, scale: Float, textScale: Float = 1f): SpriteImage? {
        if (letter.isEmpty()) return null
        val first = String(Character.toChars(letter.codePointAt(0)))
        val t = textScale
        // Drawn in an 18-point box, scaled by `t` with the map's text.
        val side = 18 * t
        val base = SpriteImage.draw(side, side, scale) { canvas ->
            canvas.scale(t, t)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.BLACK }
            canvas.drawOval(RectF(1f, 1f, 17f, 17f), paint)
            paint.color = Color.argb((0.85f * 255).toInt(), 0xee, 0xee, 0xee)
            canvas.drawOval(RectF(1.5f, 1.5f, 16.5f, 16.5f), paint)
        }?.multiplied(color) ?: return null
        val baseBitmap = bitmap(base) ?: return base
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = EngineAssets.interSemiBold
            textSize = 13.5f
            this.color = Color.WHITE
        }
        // The letter is centered by its ink, as the engine trims the text bitmap before centering.
        val ink = RectF()
        Path().also { paint.getTextPath(first, 0, first.length, 0f, 0f, it) }.computeBounds(ink, true)
        return SpriteImage.draw(base.width, base.height, scale) { canvas ->
            canvas.scale(t, t)
            canvas.drawBitmap(baseBitmap, null, RectF(0f, 0f, 18f, 18f), Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.drawText(first, 9 - ink.centerX(), 9 - ink.centerY(), paint)
        } ?: base
    }

    /**
     * A date label (`createLabelBitmap`): white Inter SemiBold at 14pt with 3pt of padding, on
     * black at 60%.
     */
    fun label(text: String, scale: Float, textScale: Float = 1f): SpriteImage? {
        val t = textScale
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = EngineAssets.interSemiBold
            textSize = 14 * t
            color = Color.WHITE
        }
        val metrics = paint.fontMetrics
        val ascent = -metrics.ascent; val descent = metrics.descent
        val width = paint.measureText(text)
        val padding = 3 * t
        val w = ceil(width + 2 * padding); val h = ceil(ascent + descent + 2 * padding)
        return SpriteImage.draw(w, h, scale) { canvas ->
            canvas.drawRect(0f, 0f, w, h, Paint().apply { color = Color.argb((0.6f * 255).toInt(), 0, 0, 0) })
            canvas.drawText(text, padding, padding + ascent, paint)
        }
    }

    /** A sprite image's premultiplied pixels as a bitmap, to draw into another image. */
    private fun bitmap(image: SpriteImage): Bitmap? = runCatching {
        Bitmap.createBitmap(image.pixelWidth, image.pixelHeight, Bitmap.Config.ARGB_8888).apply {
            copyPixelsFromBuffer(ByteBuffer.wrap(image.bytes))
        }
    }.getOrNull()
}
