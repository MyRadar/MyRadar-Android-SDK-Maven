package com.acmeaom.myradar.sdk.engine.tiles

import kotlinx.coroutines.Job

/** Loaded tiles kept by recency, plus the tiles being loaded. Used on the main thread only. */
internal class TileCache<V : Any>(private val capacity: Int) {
    // Access order: iteration runs least recently used first.
    private val values = LinkedHashMap<TileID, V>(16, 0.75f, true)
    private val tasks = HashMap<TileID, Job>()
    private val failures = HashMap<TileID, Long>()

    /** The tile, marking it recently used. */
    operator fun get(id: TileID): V? = values[id]

    /** The tile without touching its recency. */
    fun peek(id: TileID): V? = if (values.containsKey(id)) values.entries.first { it.key == id }.value else null

    /** Whether the tile is loading, or failed recently enough that it shouldn't be retried yet. */
    fun isLoading(id: TileID): Boolean {
        if (tasks.containsKey(id)) return true
        val failed = failures[id] ?: return false
        return System.currentTimeMillis() - failed < RETRY_INTERVAL_MS
    }

    fun loading(id: TileID, job: Job) {
        tasks[id] = job
    }

    fun store(id: TileID, value: V) {
        tasks.remove(id)
        failures.remove(id)
        values[id] = value
        while (values.size > capacity) {
            val oldest = values.keys.iterator()
            oldest.next()
            oldest.remove()
        }
    }

    fun failed(id: TileID) {
        tasks.remove(id)
        failures[id] = System.currentTimeMillis()
    }

    /** Cancels loads for tiles that are no longer wanted. */
    fun retainOnly(wanted: Set<TileID>) {
        val it = tasks.entries.iterator()
        while (it.hasNext()) {
            val (id, job) = it.next()
            if (id !in wanted) {
                job.cancel()
                it.remove()
            }
        }
    }

    fun removeAll() {
        tasks.values.forEach { it.cancel() }
        tasks.clear()
        values.clear()
        failures.clear()
    }

    private companion object {
        /** How long to wait before retrying a tile that failed to load. */
        const val RETRY_INTERVAL_MS = 30_000L
    }
}
