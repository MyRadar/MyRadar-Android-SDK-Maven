package com.acmeaom.myradar.sdk.engine.radar

import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.sqrt

/**
 * The radar loop's clock. Port of the engine's `FWMapAnimation` (frame stepping and the pause at
 * the end of the loop), the scrubber handling of `FWWeatherAnimation::onTimerTrigger`, and
 * `FWWeatherModule::currentAnimationLoopTime` / `sendScrubberUpdate`.
 *
 * Frames are ordered newest first, as in the engine. Playback steps from the oldest frame to the
 * newest, skipping frames that aren't loaded yet (except the newest), then holds the newest for
 * the pause interval. Clock times are seconds; dates are seconds since 1970.
 */
internal class RadarPlayback(speed: Float = 0f) {
    /** `FWMapAnimation::setSpeed`, with the speed preference's default of 0. */
    var frameInterval: Double = 0.0
        private set
    var pauseInterval: Double = 0.0
        private set

    /** Index of the visible frame (0 = newest), or null before the first frame shows. */
    var currentFrame: Int? = null
        private set
    /** When the visible frame appeared, for the morph factor. */
    var lastFrameStart: Double = 0.0
        private set
    /** Engine index of the next frame to try; wraps like the engine's uint16. */
    private var nextFrameIndex = 0
    private var nextTriggerAt = 0.0
    var isInAnimationPause: Boolean = false
        private set

    init {
        setSpeed(speed)
    }

    /** The engine's speed preference: `exp(-2 × speed)` times the default frame time. */
    fun setSpeed(speed: Float) {
        setFrameTime(exp(speed * -2f) * DEFAULT_FRAME_TIME)
    }

    /** The SDK's speed: a multiple of the default, so `0.5` shows each frame twice as long. */
    fun setSpeedMultiplier(multiplier: Float) {
        setFrameTime(DEFAULT_FRAME_TIME / maxOf(multiplier, 0.01f))
    }

    private fun setFrameTime(seconds: Float) {
        frameInterval = seconds.toDouble()
        pauseInterval = (sqrt(seconds) * 4f).toDouble()
    }

    /** New frames replace the old; the engine's `replaceLayers` keeps the frame index running. */
    fun framesReplaced(now: Double) {
        nextTriggerAt = now + frameInterval
    }

    fun reset() {
        currentFrame = null
        nextFrameIndex = 0
        nextTriggerAt = 0.0
    }

    /** `FWMapAnimation::onTimerTrigger` when it's due. Returns true when the visible frame changed. */
    fun tick(now: Double, frameCount: Int, isAnimatable: (Int) -> Boolean): Boolean {
        if (frameCount <= 0 || now < nextTriggerAt) return false
        var next: Int?
        if (nextFrameIndex >= frameCount) {
            // Start over from the oldest frame that can play.
            nextFrameIndex = frameCount
            do {
                nextFrameIndex -= 1
                next = nextFrameIndex
            } while (nextFrameIndex != 0 && !isAnimatable(nextFrameIndex))
        } else {
            next = nextFrameIndex
            if (nextFrameIndex != 0 && !isAnimatable(nextFrameIndex)) next = null
        }
        isInAnimationPause = nextFrameIndex == 0
        // The engine's index is unsigned: stepping past the newest frame wraps to "start over".
        nextFrameIndex = if (nextFrameIndex == 0) UINT16_MAX else nextFrameIndex - 1
        nextTriggerAt = now + if (isInAnimationPause) pauseInterval else frameInterval
        if (next == null) return false
        val changed = next != currentFrame
        currentFrame = next
        lastFrameStart = now
        return changed
    }

    /**
     * Shows the frame a scrubber position selects (`FWWeatherAnimation::onTimerTrigger` with the
     * scrubber enabled). Returns true when the visible frame changed.
     */
    fun scrub(value: Float, frameCount: Int): Boolean {
        if (frameCount <= 0) return false
        val interval = 1f / frameCount
        val visible = minOf(floor(value / interval).toInt(), frameCount - 1)
        val index = frameCount - visible - 1
        val changed = index != currentFrame
        currentFrame = index
        nextFrameIndex = if (index - 1 < 0) UINT16_MAX else index - 1
        return changed
    }

    /** `FWWeatherModule::currentAnimationLoopTime`. */
    fun loopTime(now: Double, frameDate: Double?, timing: RadarTiming, scrubbing: Boolean, scrubber: Float): Double? {
        if (scrubbing) {
            val start = timing.oldestFrame - timing.nominalFrameTimeInterval
            val span = timing.animationLoopEndTime - start
            return start + span * scrubber
        }
        if (frameDate == null) return null
        val animInterval = maxOf(timing.nominalFrameTimeInterval, 1.0)
        val displayed = now - lastFrameStart
        return frameDate + animInterval * (-1 + displayed / frameInterval)
    }

    companion object {
        const val DEFAULT_FRAME_TIME: Float = 0.1666666f
        private const val UINT16_MAX = 65535

        /** `MorphingLayerMetaGraphic::lerpFactor`: how far a frame has morphed from the one before it. */
        fun lerpFactor(loopTime: Double, frameDate: Double, previousFrameOffset: Double): Float {
            val previous = frameDate - previousFrameOffset
            return ((loopTime - previous) / previousFrameOffset).coerceIn(0.0, 1.0).toFloat()
        }

        /** `FWWeatherModule::sendScrubberUpdate`: where the visible frame sits on the scrubber. */
        fun scrubberValue(frameDate: Double, timing: RadarTiming): Float {
            val span = timing.animationLoopEndTime - timing.oldestFrame
            if (span <= 0) return 1f
            return ((frameDate - timing.oldestFrame) / span).toFloat()
        }
    }
}
