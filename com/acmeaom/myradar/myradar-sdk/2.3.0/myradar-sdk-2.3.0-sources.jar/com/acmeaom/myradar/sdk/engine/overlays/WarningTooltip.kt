package com.acmeaom.myradar.sdk.engine.overlays

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.format.DateFormat
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.View
import com.acmeaom.myradar.sdk.WeatherAlert
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * The bubble a tap on watches and warnings shows: what each alert is and when it expires, most
 * important first.
 */
internal object WarningTooltip {
    /** One alert in the tooltip; `expires` is null when the feed doesn't say. */
    data class Entry(val title: String, val expires: Instant?)

    /** At most this many alerts are listed; the rest are counted. */
    const val MAX_ENTRIES = 4

    /**
     * The tooltip's alerts, in the order given (most important first), without repeats: an alert
     * issued for several adjacent areas appears once.
     */
    fun entries(alerts: List<WeatherAlert>): List<Entry> = alerts.map { Entry(it.title, it.expires) }.distinct()

    /** How times are written: one formatter for today, one with the weekday for other days. */
    class TimeFormats(val today: DateTimeFormatter, val otherDay: DateTimeFormatter, val zone: ZoneId)

    /** The device's formats, following its 12/24-hour setting and locale. */
    fun timeFormats(context: Context, locale: Locale = Locale.getDefault()): TimeFormats {
        val skeleton = if (DateFormat.is24HourFormat(context)) "Hmm" else "hmma"
        return TimeFormats(
            DateTimeFormatter.ofPattern(DateFormat.getBestDateTimePattern(locale, skeleton), locale),
            DateTimeFormatter.ofPattern(DateFormat.getBestDateTimePattern(locale, "EEE$skeleton"), locale),
            ZoneId.systemDefault(),
        )
    }

    /** `Expires 3:15 PM`, with the weekday when it isn't today (`Expires Tue 3:15 PM`). */
    fun expiresText(expires: Instant, now: Instant, formats: TimeFormats): String {
        val at = expires.atZone(formats.zone)
        val sameDay = at.toLocalDate() == now.atZone(formats.zone).toLocalDate()
        return "Expires " + (if (sameDay) formats.today else formats.otherDay).format(at)
    }

    /** The lines the tooltip shows: for each alert its title and expiry, then `+N more`. */
    fun lines(entries: List<Entry>, now: Instant, formats: TimeFormats): List<Pair<String, String?>> {
        val lines = entries.take(MAX_ENTRIES).map { it.title to it.expires?.let { e -> expiresText(e, now, formats) } }
        return if (entries.size > MAX_ENTRIES) lines + ("+${entries.size - MAX_ENTRIES} more" to null) else lines
    }
}

/**
 * The tooltip bubble: a dark rounded label with a pointer at the bottom, which sits on the tapped
 * point. Positions and sizes are set by the map view ([place]).
 */
@SuppressLint("ViewConstructor")
internal class WarningTooltipView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private val padH = 10 * density
    private val padV = 7 * density
    private val pointerW = 14 * density
    private val pointerH = 7 * density
    private val radius = 8 * density
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(235, 26, 26, 26)
        setShadowLayer(4 * density, 0f, density, Color.argb(77, 0, 0, 0))
    }
    private val path = Path()
    private var text: CharSequence = ""
    private var layout: StaticLayout? = null
    private var pointerX = 0f

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null) // for the shadow
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    /** Sets the alerts shown; `scale` is the map's text scale. */
    fun show(entries: List<WarningTooltip.Entry>, scale: Float) {
        val formats = WarningTooltip.timeFormats(context)
        val builder = SpannableStringBuilder()
        val titleSize = 13 * scale * density
        textPaint.textSize = titleSize
        for ((i, line) in WarningTooltip.lines(entries, Instant.now(), formats).withIndex()) {
            if (i > 0) builder.append("\n")
            val start = builder.length
            builder.append(line.first)
            builder.setSpan(StyleSpan(Typeface.BOLD), start, builder.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            line.second?.let { detail ->
                builder.append("\n")
                val s = builder.length
                builder.append(detail)
                builder.setSpan(ForegroundColorSpan(Color.argb(204, 255, 255, 255)), s, builder.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                builder.setSpan(android.text.style.RelativeSizeSpan(12f / 13f), s, builder.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        text = builder
        contentDescription = builder.toString()
        layout = null
    }

    /**
     * Places the bubble with its pointer on (`x`, `y`) in the parent's pixels, kept inside a
     * parent `parentWidth` wide; the pointer follows the point.
     */
    fun place(x: Float, y: Float, parentWidth: Int) {
        val maxText = (min(280 * density, parentWidth - 16 * density) - 2 * padH).toInt().coerceAtLeast(1)
        val natural = ceil(Layout.getDesiredWidth(text, textPaint)).toInt()
        val l = StaticLayout.Builder.obtain(text, 0, text.length, textPaint, min(natural, maxText).coerceAtLeast(1))
            .setLineSpacing(2 * density, 1f).build()
        layout = l
        val textWidth = (0 until l.lineCount).maxOfOrNull { l.getLineWidth(it) } ?: 0f
        val w = ceil(textWidth + 2 * padH).toInt()
        val h = ceil(l.height + 2 * padV + pointerH).toInt()
        val left = min(max(x - w / 2f, 8 * density), parentWidth - w - 8 * density)
        pointerX = x - left
        val params = layoutParams
        if (params == null || params.width != w || params.height != h) {
            layoutParams = android.widget.FrameLayout.LayoutParams(w, h)
        }
        translationX = left
        translationY = y - h
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val l = layout ?: return
        val bodyBottom = height - pointerH
        path.reset()
        path.addRoundRect(RectF(0f, 0f, width.toFloat(), bodyBottom), radius, radius, Path.Direction.CW)
        val px = pointerX.coerceIn(radius + pointerW / 2, width - radius - pointerW / 2)
        path.moveTo(px - pointerW / 2, bodyBottom)
        path.lineTo(px, height.toFloat())
        path.lineTo(px + pointerW / 2, bodyBottom)
        path.close()
        canvas.drawPath(path, fill)
        canvas.save()
        canvas.translate(padH, padV)
        l.draw(canvas)
        canvas.restore()
    }
}
