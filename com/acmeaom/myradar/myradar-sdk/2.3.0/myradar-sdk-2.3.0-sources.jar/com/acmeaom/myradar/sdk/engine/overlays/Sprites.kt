package com.acmeaom.myradar.sdk.engine.overlays

import android.graphics.Bitmap
import android.graphics.Canvas
import com.acmeaom.myradar.sdk.engine.basemap.FloatList
import com.acmeaom.myradar.sdk.engine.basemap.RGBA
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import com.acmeaom.myradar.sdk.engine.gl.GPUTexture
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.gl.VertexLayout
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * A screen-aligned image pinned to a map position (the engine's map stamps): icons and text
 * labels that keep their size in points as the map zooms, with an anchor offset, an optional
 * rotation and an opacity.
 */
internal data class Sprite(
    val texture: GPUTexture,
    /** Web Mercator, 0..1. */
    val position: Vec2,
    /** Size in points (dp). */
    val width: Float,
    val height: Float,
    /** Where the image's center sits relative to the position, in points (x right, y down). */
    val anchorX: Float = 0f,
    val anchorY: Float = 0f,
    /** Counterclockwise on screen, in radians. */
    val rotation: Float = 0f,
    val alpha: Float = 1f,
)

internal object SpriteDrawer {
    private val LAYOUT = VertexLayout(2, 2, 1)

    /** Draws sprites in order (first is furthest back), once per world copy in view. */
    fun draw(context: RenderContext, sprites: List<Sprite>) {
        if (sprites.isEmpty()) return
        val program = context.use("icon_vs", "icon_fs") ?: return
        val transform = context.transform
        val projection = transform.projectionMatrix
        program.setVec2("u_screen", transform.width.toFloat(), transform.height.toFloat())
        for (sprite in sprites) {
            if (sprite.alpha <= 0) continue
            val out = FloatList(64)
            val x = sprite.position.x
            for (wrap in MercatorShapes.visibleWraps(transform, x - 0.01, x + 0.01)) {
                val p = transform.screenPoint(sprite.position + Vec2(wrap.toDouble(), 0.0), projection) ?: continue
                val w = sprite.width / 2; val h = sprite.height / 2
                // Skip copies well off screen.
                val reach = max(w, h) * 2 + abs(sprite.anchorX) + abs(sprite.anchorY)
                if (p.x < -reach || p.y < -reach || p.x > transform.width + reach || p.y > transform.height + reach) continue
                val c = cos(sprite.rotation); val s = sin(sprite.rotation)
                val px = p.x.toFloat(); val py = p.y.toFloat()
                val tw = sprite.texture.width.toFloat(); val th = sprite.texture.height.toFloat()
                // Rotate about the position, anchor included, as the engine's stamp shader does.
                fun corner(cx: Float, cy: Float, u: Float, v: Float) {
                    val lx = cx + sprite.anchorX; val ly = cy + sprite.anchorY
                    out.add(px + lx * c + ly * s); out.add(py - lx * s + ly * c)
                    out.add(u); out.add(v); out.add(sprite.alpha)
                }
                corner(-w, -h, 0f, 0f); corner(w, -h, tw, 0f); corner(-w, h, 0f, th)
                corner(w, -h, tw, 0f); corner(w, h, tw, th); corner(-w, h, 0f, th)
            }
            if (out.size == 0) continue
            program.setVec2("u_atlasSize", sprite.texture.width.toFloat(), sprite.texture.height.toFloat())
            sprite.texture.bind(program, 0, "u_tex")
            context.drawVertices(out.data, LAYOUT, out.size)
        }
    }
}

/** Premultiplied RGBA pixels drawn with an Android canvas at the screen's density. */
internal class SpriteImage(
    val bytes: ByteArray,
    val pixelWidth: Int,
    val pixelHeight: Int,
    /** Size in points (dp). */
    val width: Float,
    val height: Float,
) {
    /** `FWBitmap::applyFilter(…, FWBitmapFilterModeMultiply)`: every pixel times the color. */
    fun multiplied(color: RGBA): SpriteImage {
        val out = bytes.copyOf()
        val factors = floatArrayOf(color.r, color.g, color.b, color.a)
        for (i in out.indices step 4) for (c in 0 until 4) {
            out[i + c] = ((out[i + c].toInt() and 0xFF) * factors[c]).roundToInt().coerceIn(0, 255).toByte()
        }
        return SpriteImage(out, pixelWidth, pixelHeight, width, height)
    }

    fun texture(): GPUTexture? = GPUTexture.rgba(bytes, pixelWidth, pixelHeight)

    companion object {
        /** Draws into a `width` × `height`-point image; the canvas is scaled so it draws in points. */
        fun draw(width: Float, height: Float, scale: Float, body: (Canvas) -> Unit): SpriteImage? {
            val pw = max(ceil(width * scale).toInt(), 1)
            val ph = max(ceil(height * scale).toInt(), 1)
            val bitmap = Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.scale(scale, scale)
            body(canvas)
            return fromBitmap(bitmap, width, height)
        }

        /** A bitmap's premultiplied pixels (ARGB_8888 is R, G, B, A in memory). */
        fun fromBitmap(bitmap: Bitmap, width: Float, height: Float): SpriteImage {
            val source = if (bitmap.config == Bitmap.Config.ARGB_8888) bitmap
            else bitmap.copy(Bitmap.Config.ARGB_8888, false)
            val buffer = ByteBuffer.allocate(source.byteCount)
            source.copyPixelsToBuffer(buffer)
            return SpriteImage(buffer.array(), source.width, source.height, width, height)
        }
    }
}
