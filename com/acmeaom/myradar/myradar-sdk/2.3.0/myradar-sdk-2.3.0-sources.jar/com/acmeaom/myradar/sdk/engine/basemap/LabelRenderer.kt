// Places and draws a style's symbol layers: text drawn as signed distance fields (fill and halo),
// sprite icons, point labels, labels that follow lines, and screen-space collision so labels
// don't overlap. Layers higher in the style are placed first.

package com.acmeaom.myradar.sdk.engine.basemap

import android.opengl.GLES30
import com.acmeaom.myradar.sdk.engine.camera.Mat4
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.gl.VertexLayout
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.engine.tiles.TileID
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Places and draws labels. Main thread only: glyphs are rasterized into the atlas texture while
 * placing, so [draw] must run with the GL context current.
 */
internal class LabelRenderer(network: EngineNetwork, style: MapStyleSheet) {
    var onNeedsDisplay: (() -> Unit)? = null

    private val glyphs = GlyphAtlas()
    private val sprite: SpriteAtlas? = style.spriteUrl?.let { SpriteAtlas(network, it) }
    private val properties = HashMap<String, SymbolLayerProperties>()
    private val shapes = HashMap<String, Shape>()
    /** Bumped when glyphs or sprites arrive, which changes what can be placed. */
    private var contentGeneration = 0
    private var lastPlacement: Placement? = null

    /** The last placement's vertices, reused (and overwritten) by the next one. */
    private val textVertices = GrowableFloats()
    private val iconVertices = GrowableFloats()

    /** Multiplies every label's text and icon size (accessibility text size). */
    var textScale: Float = 1f
        set(value) {
            if (value == field) return
            field = value
            valuesCache.clear()
            contentGeneration += 1
            onNeedsDisplay?.invoke()
        }

    /** Everything placement depends on: the camera, the tiles drawn and what's loaded. */
    private data class PlacementKey(
        val center: Vec2,
        val zoom: Double,
        val heading: Double,
        val tilt: Double,
        val width: Double,
        val height: Double,
        /** Compared by identity: `VectorTileData` doesn't override `equals`. */
        val tiles: List<VectorTileData>,
        val generation: Int,
    )

    private class Placement(val key: PlacementKey, val textCount: Int, val iconCount: Int, val fading: Boolean)

    init {
        glyphs.onLoaded = {
            shapes.clear()
            // New style value objects, so candidates lay their text out again.
            valuesCache.clear()
            contentGeneration += 1
            onNeedsDisplay?.invoke()
        }
        sprite?.onLoaded = {
            contentGeneration += 1
            onNeedsDisplay?.invoke()
        }
        for (layer in style.layers) {
            if (layer.kind == StyleLayerKind.SYMBOL) properties[layer.id] = SymbolLayerProperties(layer)
        }
    }

    // MARK: Placement and drawing

    /**
     * A label the engine would make for a tile (`VectorTile` creating `VectorMapLabel`s), with
     * its position fixed on the map. Built once per tile and layer.
     */
    class LabelCandidate(
        val kind: Kind,
        val position: Vec2,
        val text: String,
        val icon: String,
        /** The style layer the candidate belongs to; part of its identity. */
        val layerId: String,
    ) {
        sealed class Kind {
            /** Upright at a point. */
            object Point : Kind()

            /** Following its line (Mercator x, y pairs), centered on vertex [vertex]. */
            class Curved(val line: DoubleArray, val vertex: Int) : Kind()
        }

        val isCurved: Boolean get() = kind is Kind.Curved

        // The candidate's laid-out text for the style values it was last placed with.
        private var shapeValues: SymbolValues? = null
        private var shapeCache: Shape? = null

        fun shapeFor(v: SymbolValues): Shape? = if (shapeValues === v) shapeCache else null

        fun cacheShape(v: SymbolValues, shape: Shape) {
            shapeValues = v
            shapeCache = shape
        }

        // Keys built on first use and kept, as candidates are: placement runs every frame the
        // camera moves.
        private var identityCache: String? = null
        private var baseKeyCache: String? = null
        private var labelKeyCache: String? = null

        /** Identical labels of a layer, grouped together for declutter order and spacing. */
        val identity: String get() = identityCache ?: "$layerId|$text|$icon".also { identityCache = it }

        /** One label at one place. */
        val baseKey: String
            get() = baseKeyCache
                ?: "$identity|${(position.x * 4e6).toLong()}|${(position.y * 4e6).toLong()}".also { baseKeyCache = it }

        /** The key its fade is kept under: a label following its line fades apart from its upright fallback. */
        val labelKey: String
            get() = labelKeyCache ?: (if (isCurved) "$baseKey|curved" else baseKey).also { labelKeyCache = it }
    }

    /** Placement state carried between frames: each label's fade. */
    /**
     * Each symbol layer's style values per tile zoom. Kept between frames so candidates can cache
     * what depends on them (their laid-out text).
     */
    private val valuesCache = HashMap<String, HashMap<Int, SymbolValues>>()
    /** The projection as an array, and a reused result, so placement projects without allocating. */
    private var projection = DoubleArray(16)
    private val projected = DoubleArray(2)

    /** Projects a Mercator point into [projected] (screen points); false when it's behind the camera. */
    private fun project(x: Double, y: Double, worldSize: Double, width: Double, height: Double): Boolean {
        val m = projection
        val wx = x * worldSize; val wy = y * worldSize
        val px = m[0] * wx + m[4] * wy + m[12]
        val py = m[1] * wx + m[5] * wy + m[13]
        val pw = m[3] * wx + m[7] * wy + m[15]
        if (pw <= 0) return false
        projected[0] = (px / pw + 1) / 2 * width
        projected[1] = (1 - py / pw) / 2 * height
        return true
    }

    private val labelAlpha = HashMap<String, Float>()
    private var lastFadeUpdate = 0.0

    private class Entry(
        val rank: Double,
        val group: Int,
        val layerId: String,
        val v: SymbolValues,
        val candidate: LabelCandidate,
    )

    /**
     * Places and draws the labels of the tiles each source is drawing this frame. Returns true
     * while labels are fading in or out.
     */
    fun draw(
        context: RenderContext,
        style: MapStyleSheet,
        tiles: Map<String, List<Pair<TileID, VectorTileData>>>,
    ): Boolean {
        val transform = context.transform
        // Placement only changes with the camera, the tiles or what's loaded; frames that only
        // advance the weather reuse the last one, once fades have settled.
        val key = PlacementKey(
            transform.center, transform.zoom, transform.heading, transform.tilt, transform.width, transform.height,
            tiles.keys.sorted().flatMap { source -> tiles.getValue(source).map { it.second } },
            contentGeneration,
        )
        val last = lastPlacement
        if (last != null && last.key == key && !last.fading) {
            drawIcons(context, iconVertices, last.iconCount)
            drawText(context, textVertices, last.textCount)
            lastFadeUpdate = context.now
            return false
        }
        val elapsed = (if (lastFadeUpdate > 0) min(context.now - lastFadeUpdate, 0.25) else 0.0).toFloat()
        lastFadeUpdate = context.now
        val projection = transform.projectionMatrix
        this.projection = projection.m
        val worldSize = transform.worldSize
        val scale = context.pixelRatio.toFloat()

        // 1. Candidates, most important first (`BasemapMetaLayer::declutterLabels`): later style
        //    layers first, labels that follow their line ahead of upright ones from the same layer,
        //    and within that, identical labels together.
        val entries = ArrayList<Entry>()
        val groups = HashMap<String, Int>()
        for ((rank, layer) in style.layers.withIndex()) {
            if (layer.kind != StyleLayerKind.SYMBOL || !layer.visible) continue
            val p = properties[layer.id] ?: continue
            val source = layer.source ?: continue
            val sourceTiles = tiles[source] ?: continue
            // Labels hide past their layer's maxzoom at the camera zoom.
            if (layer.maxZoom < transform.zoom) continue
            val valuesByZoom = valuesCache.getOrPut(layer.id) { HashMap() }
            for ((tile, data) in sourceTiles) {
                // The engine evaluates labels at the tile's zoom + 1.1 (`VectorTile::ZOOM_OFFSET`).
                val tileZoom = BasemapRenderer.styleZoom(tile)
                if (!layer.isVisible(tileZoom)) continue
                val features = data.symbols[layer.id] ?: continue
                val v = valuesByZoom.getOrPut(tile.z) { p.evaluate(tileZoom).scaled(textScale) }
                // `StyledLayer`: rotated icons (one-way arrows) aren't drawn.
                if (v.iconRotate != 0f) continue
                for (candidate in candidates(layer.id, tile, data, features, v)) {
                    val curved = candidate.isCurved
                    val group = groups.getOrPut(candidate.identity) { groups.size }
                    // Upright labels from line layers rank half a step lower (`_declutterRank -= 0.5`).
                    val lineLayer = v.placement == "line" || v.placement == "line-center"
                    entries.add(Entry(rank.toDouble() - (if (lineLayer && !curved) 0.5 else 0.0), group,
                        layer.id, v, candidate))
                }
            }
        }
        // A stable sort, so equal entries keep their order.
        entries.sortWith { a, b ->
            when {
                a.rank != b.rank -> if (a.rank > b.rank) -1 else 1
                a.group != b.group -> a.group.compareTo(b.group)
                else -> 0
            }
        }

        // 2. Declutter (`HybridDeclutteringTrees::declutter`): labels up to half a screen off screen
        //    take part, so the selection holds steady as the map pans.
        val width = transform.width
        val height = transform.height
        val area = ScreenRect(-width / 2, -height / 2, width * 2, height * 2)
        val grid = CollisionGrid(area)
        var spacingRank = 0.0
        var spacingGroup = -1
        var hasSpacingRun = false
        val spacingCircles = DoubleList()
        val curvedVertices = HashSet<String>()
        val text = textVertices.also { it.clear() }
        val icons = iconVertices.also { it.clear() }
        var fading = false
        val shownKeys = HashSet<String>()
        val paths = HashMap<DoubleArray, ScreenPath?>()

        for (entry in entries) {
            val v = entry.v
            val c = entry.candidate
            if (!project(c.position.x, c.position.y, worldSize, transform.width, transform.height)) continue
            val ax = projected[0]
            val ay = projected[1]
            // The declutter area grown by half a screen again: x in [-w, 2w), y in [-h, 2h).
            if (!(ax >= -width && ax < 2 * width && ay >= -height && ay < 2 * height)) continue
            val baseKey = c.baseKey
            val isCurved = c.isCurved
            // A vertex whose label follows the line doesn't also get the upright fallback.
            if (!isCurved && curvedVertices.contains(baseKey)) continue
            val labelKey = c.labelKey
            val shape = if (c.text.isEmpty()) null else c.shapeFor(v) ?: shape(c.text, v).also { c.cacheShape(v, it) }
            if (c.text.isNotEmpty() && !glyphs.isReady(c.text, v.fontStack)) continue
            val icon = if (c.icon.isEmpty()) null else sprite?.icons?.get(c.icon)
            if (shape == null && icon == null) continue

            // The label's footprint: its glyphs along the line, or its upright box.
            val boxes: List<ScreenRect>
            var curvedGlyphs: CurvedLayout? = null
            var uprightText: ScreenRect? = null
            var uprightIcon: ScreenRect? = null
            val bitmapWidth: Double
            val bitmapHeight: Double
            when (val kind = c.kind) {
                is LabelCandidate.Kind.Curved -> {
                    if (shape == null) continue
                    val path = paths.getOrPut(kind.line) { projectPath(kind.line, transform, projection) }
                    val laid = path?.let { layoutAlongLine(it, kind.vertex, shape, v) } ?: continue
                    curvedGlyphs = laid
                    boxes = laid.boxes
                    val textScale = v.textSize / GlyphAtlas.BASE_SIZE
                    bitmapWidth = (shape.width * textScale).toDouble()
                    bitmapHeight = (shape.height * textScale).toDouble()
                }
                LabelCandidate.Kind.Point -> {
                    uprightText = shape?.let { uprightTextBox(ax, ay, it, v) }
                    uprightIcon = icon?.let { uprightIconBox(ax, ay, it, v) }
                    val box = when {
                        uprightText != null && uprightIcon != null -> uprightText.union(uprightIcon)
                        else -> uprightText ?: uprightIcon ?: continue
                    }
                    bitmapWidth = box.width
                    bitmapHeight = box.height
                    // Point features carry `text-padding` (default 2); line features don't.
                    val isLineFeature = v.placement != "point"
                    val padding = if (isLineFeature) 0.0 else v.textPadding.toDouble()
                    boxes = listOf(box.outset(padding))
                }
            }
            val onScreen = boxes.any { it.intersects(area) }
            val lineLayer = v.placement == "line"

            var shown = false
            if (onScreen || lineLayer) {
                val occluded = boxes.any { grid.collides(it) }
                var tooClose = false
                if (lineLayer) {
                    // Same-label runs (per layer and label) are spaced `symbol-spacing` plus the
                    // label's size apart (`kludged_symbol_spacing`, the root of its pixel area).
                    if (!hasSpacingRun || spacingRank != entry.rank || spacingGroup != entry.group) {
                        hasSpacingRun = true
                        spacingRank = entry.rank
                        spacingGroup = entry.group
                        spacingCircles.clear()
                    }
                    val spacing = v.symbolSpacing.toDouble() + sqrt(bitmapWidth * bitmapHeight) * scale.toDouble()
                    val radius = spacing / 2
                    if (!occluded) {
                        var i = 0
                        while (i < spacingCircles.size) {
                            val d = spacingCircles.data
                            if (hypot(d[i] - ax, d[i + 1] - ay) < d[i + 2] + radius) {
                                tooClose = true
                                break
                            }
                            i += 3
                        }
                        if (!tooClose) {
                            spacingCircles.add(ax); spacingCircles.add(ay); spacingCircles.add(radius)
                        }
                    }
                }
                if (!occluded && !tooClose) {
                    shown = true
                    for (box in boxes) grid.insert(box)
                    if (isCurved) curvedVertices.add(baseKey)
                }
            }

            // Fade toward shown or hidden (`computeAndUpdateHideShowFadeAlpha`): in over 0.45 s,
            // out over 0.7 s; new labels start hidden.
            var alpha = labelAlpha[labelKey] ?: 0f
            alpha = if (shown) min(1f, alpha + elapsed / 0.45f) else max(0f, alpha - elapsed / 0.7f)
            if (shown && alpha < 1 || !shown && alpha > 0) fading = true
            if (shown) shownKeys.add(labelKey)
            labelAlpha[labelKey] = alpha
            if (!(alpha > 0)) continue

            if (curvedGlyphs != null) {
                val textScale = v.textSize / GlyphAtlas.BASE_SIZE
                for (i in curvedGlyphs.glyphs.indices) {
                    appendGlyph(curvedGlyphs.glyphs[i], curvedGlyphs.xs[i], curvedGlyphs.ys[i],
                        curvedGlyphs.angles[i], textScale, v, alpha, text)
                }
            } else {
                if (uprightIcon != null && icon != null) appendIcon(icon, uprightIcon, v.iconOpacity * alpha, icons)
                if (uprightText != null && shape != null) appendText(shape, uprightText, v, alpha, text)
            }
        }
        // Forget labels that faded out.
        labelAlpha.entries.removeAll { !(it.value > 0) && !shownKeys.contains(it.key) }

        // Icons under text, so shield numbers sit on their shields.
        drawIcons(context, icons, icons.size)
        drawText(context, text, text.size)
        lastPlacement = Placement(key, text.size, icons.size, fading)
        return fading
    }

    /**
     * The tile's label candidates for a layer, built once (`VectorTile`): point features inside
     * the tile; for `point` placement on lines the first vertex, `line-center` the centroid, and
     * `line` every vertex.
     */
    private fun candidates(layer: String, tile: TileID, data: VectorTileData, features: List<VectorTileFeature>,
                           v: SymbolValues): List<LabelCandidate> {
        data.labelCandidates[layer]?.let { return it }
        val n = (1 shl tile.z).toDouble()
        val extent = data.extent.toDouble()
        val originX = tile.x.toDouble() + tile.wrap.toDouble() * n
        val originY = tile.y.toDouble()
        fun mercatorX(x: Float) = (originX + x.toDouble() / extent) / n
        fun mercatorY(y: Float) = (originY + y.toDouble() / extent) / n
        val result = ArrayList<LabelCandidate>()
        for (feature in features) {
            val text = v.textField?.let { labelText(it, feature.properties, v.textTransform) } ?: ""
            val icon = v.iconImage?.let { resolve(it, feature.properties, "none") } ?: ""
            if (text.isEmpty() && icon.isEmpty()) continue
            if (feature.type == GeometryType.POINT) {
                for (part in feature.geometry) for (k in 0 until part.pointCount) {
                    val x = part[2 * k]; val y = part[2 * k + 1]
                    // Only points inside the tile, so neighbouring tiles' buffers don't repeat them.
                    if (!(x >= 0 && y >= 0 && x.toDouble() < extent && y.toDouble() < extent)) continue
                    result.add(LabelCandidate(LabelCandidate.Kind.Point, Vec2(mercatorX(x), mercatorY(y)), text, icon,
                        layer))
                }
                continue
            }
            for (line in feature.geometry) {
                if (line.isEmpty()) continue
                val count = line.pointCount
                val points = DoubleArray(count * 2)
                for (i in 0 until count) {
                    points[2 * i] = mercatorX(line[2 * i])
                    points[2 * i + 1] = mercatorY(line[2 * i + 1])
                }
                when (v.placement) {
                    "line" -> {
                        val follows = v.textRotationAlignment == "map" && text.isNotEmpty() && !text.contains("\n")
                        for (i in 0 until count) {
                            val p = Vec2(points[2 * i], points[2 * i + 1])
                            val kind = if (follows) LabelCandidate.Kind.Curved(points, i) else LabelCandidate.Kind.Point
                            result.add(LabelCandidate(kind, p, text, icon, layer))
                            // A label that can't follow the line here falls back to upright.
                            if (follows) result.add(LabelCandidate(LabelCandidate.Kind.Point, p, text, icon, layer))
                        }
                    }
                    "line-center" -> {
                        // `FWTileCoordinate::centroidOfPath`.
                        var sx = 0.0
                        var sy = 0.0
                        for (i in 0 until count) {
                            sx += points[2 * i]; sy += points[2 * i + 1]
                        }
                        val centroid = Vec2(sx / count, sy / count)
                        result.add(LabelCandidate(LabelCandidate.Kind.Point, centroid, text, icon, layer))
                    }
                    else -> result.add(LabelCandidate(LabelCandidate.Kind.Point, Vec2(points[0], points[1]), text,
                        icon, layer))
                }
            }
        }
        data.labelCandidates[layer] = result
        return result
    }

    /** An upright label's icon box around a screen point. */
    private fun uprightIconBox(ax: Double, ay: Double, icon: SpriteAtlas.Icon, v: SymbolValues): ScreenRect {
        // The engine draws icons 30% larger ("to match the web map").
        val w = (icon.width.toFloat() / icon.pixelRatio * v.iconSize * 1.3f).toDouble()
        val h = (icon.height.toFloat() / icon.pixelRatio * v.iconSize * 1.3f).toDouble()
        val offsetX = (v.iconOffsetX * v.iconSize).toDouble()
        val offsetY = (v.iconOffsetY * v.iconSize).toDouble()
        val origin = anchorOrigin(v.iconAnchor, w, h)
        return ScreenRect(ax + origin.x + offsetX, ay + origin.y + offsetY, w, h)
    }

    /** An upright label's text box around a screen point. */
    private fun uprightTextBox(ax: Double, ay: Double, shape: Shape, v: SymbolValues): ScreenRect {
        val scale = v.textSize / GlyphAtlas.BASE_SIZE
        val w = (shape.width * scale).toDouble()
        val h = (shape.height * scale).toDouble()
        val origin = anchorOrigin(v.textAnchor, w, h)
        return ScreenRect(ax + origin.x + (v.textOffsetX * v.textSize).toDouble(),
            ay + origin.y + (v.textOffsetY * v.textSize).toDouble(), w, h)
    }

    /** Glyphs placed along a line: each glyph's center and angle, and the boxes it covers. */
    private class CurvedLayout(
        val glyphs: List<PositionedGlyph>,
        val xs: DoubleArray,
        val ys: DoubleArray,
        val angles: DoubleArray,
        val boxes: List<ScreenRect>,
    )

    /**
     * Glyphs following a line, centered on one of its vertices: each glyph turned to the line
     * under it and kept upright. Null where the label would run off the line or bend more than
     * `text-max-angle` between glyphs (the engine gives up past a 90° bend).
     */
    private fun layoutAlongLine(path: ScreenPath, vertex: Int, shape: Shape, v: SymbolValues): CurvedLayout? {
        val scale = v.textSize / GlyphAtlas.BASE_SIZE
        val width = (shape.width * scale).toDouble()
        val distance = path.cumulative[vertex]
        val at = DoubleArray(3)
        if (!(distance - width / 2 >= 0 && distance + width / 2 <= path.length)) return null
        if (!path.point(distance, at)) return null
        val centerAngle = at[2]
        // Keep text upright: read the line the other way when it points left.
        val flip = cos(centerAngle) < 0
        val count = shape.glyphs.size
        val xs = DoubleArray(count)
        val ys = DoubleArray(count)
        val angles = DoubleArray(count)
        val boxes = ArrayList<ScreenRect>(count)
        var previousAngle = 0.0
        var hasPrevious = false
        for ((i, glyph) in shape.glyphs.withIndex()) {
            val along = (glyph.x + glyph.metrics.advance.toFloat() / 2).toDouble() * scale.toDouble() - width / 2
            if (!path.point(distance + (if (flip) -along else along), at)) return null
            val a = if (flip) at[2] + PI else at[2]
            if (hasPrevious) {
                var d = abs(a - previousAngle) % (2 * PI)
                if (d > PI) d = 2 * PI - d
                if (d * 180 / PI > v.textMaxAngle.toDouble()) return null
            }
            previousAngle = a
            hasPrevious = true
            xs[i] = at[0]; ys[i] = at[1]; angles[i] = a
            val r = (v.textSize / 2).toDouble()
            boxes.add(ScreenRect(at[0] - r, at[1] - r, 2 * r, 2 * r))
        }
        return if (count == 0) null else CurvedLayout(shape.glyphs, xs, ys, angles, boxes)
    }

    // MARK: Shaping

    class PositionedGlyph(
        val metrics: GlyphMetrics,
        /** Left edge of the glyph's advance and its baseline, in 24-pixel units from the block's top-left. */
        val x: Float,
        val baseline: Float,
    )

    class Shape(
        val glyphs: List<PositionedGlyph>,
        val lines: List<String>,
        /** In 24-pixel units. */
        val width: Float,
        val height: Float,
    )

    /**
     * Lays text out in lines no wider than `text-max-width` ems, centered (or left or right
     * aligned for left and right anchors).
     */
    private fun shape(text: String, v: SymbolValues): Shape {
        val key = "${v.fontStack}|${v.maxWidth}|${v.letterSpacing}|${v.lineHeight}|${v.textAnchor}|$text"
        shapes[key]?.let { return it }
        val em = GlyphAtlas.BASE_SIZE
        val spacing = v.letterSpacing * em
        fun advance(s: String): Float {
            var total = 0f
            forEachCodePoint(s) { total += (glyphs.glyph(it, v.fontStack)?.advance ?: 0).toFloat() + spacing }
            return total
        }
        // The engine draws each label on one line; only explicit line breaks start a new one.
        val lines = text.split('\n').filter { it.isNotEmpty() }
        val lineHeight = v.lineHeight * em
        val widths = lines.map { advance(it) - spacing }
        val width = widths.maxOrNull() ?: 0f
        val positioned = ArrayList<PositionedGlyph>()
        val justify = when {
            v.textAnchor.endsWith("left") -> 0f
            v.textAnchor.endsWith("right") -> 1f
            else -> 0.5f
        }
        for ((i, line) in lines.withIndex()) {
            var x = (width - widths[i]) * justify
            // Baselines sit so that capitals (17 px tall at 24 px) center in each line.
            val baseline = i.toFloat() * lineHeight + (lineHeight + 17) / 2
            forEachCodePoint(line) { codepoint ->
                val g = glyphs.glyph(codepoint, v.fontStack) ?: return@forEachCodePoint
                positioned.add(PositionedGlyph(g, x, baseline))
                x += g.advance.toFloat() + spacing
            }
        }
        val result = Shape(positioned, lines, width, lines.size.toFloat() * lineHeight)
        shapes[key] = result
        return result
    }

    // MARK: Vertices

    private fun appendText(shape: Shape, box: ScreenRect, v: SymbolValues, alpha: Float, out: GrowableFloats) {
        val scale = v.textSize / GlyphAtlas.BASE_SIZE
        for (glyph in shape.glyphs) {
            if (glyph.metrics.width <= 0) continue
            val cx = box.minX.toFloat() + (glyph.x + glyph.metrics.advance.toFloat() / 2) * scale
            val cy = box.minY.toFloat() + glyph.baseline * scale
            appendGlyphQuad(glyph, cx, cy, 0f, scale, v, alpha, out, 0f)
        }
    }

    /** A glyph centered on a point of a line, turned to the line's direction. */
    private fun appendGlyph(glyph: PositionedGlyph, x: Double, y: Double, angle: Double, scale: Float, v: SymbolValues,
                            alpha: Float, out: GrowableFloats) {
        if (glyph.metrics.width <= 0) return
        // Put the middle of capitals (17 px tall at 24 px) on the line.
        appendGlyphQuad(glyph, x.toFloat(), y.toFloat(), angle.toFloat(), scale, v, alpha, out, 8.5f)
    }

    /**
     * One glyph quad around an origin: the glyph's horizontal center, `baselineOffset` (24-pixel
     * units) above its baseline, rotated by `angle`.
     */
    private fun appendGlyphQuad(g: PositionedGlyph, originX: Float, originY: Float, angle: Float, scale: Float,
                                v: SymbolValues, alpha: Float, out: GrowableFloats, baselineOffset: Float) {
        val m = g.metrics
        val b = GlyphAtlas.BORDER.toFloat()
        val x0 = (m.left.toFloat() - b - m.advance.toFloat() / 2) * scale
        val y0 = (-m.top.toFloat() - b + baselineOffset) * scale
        val x1 = x0 + (m.width + 2 * GlyphAtlas.BORDER).toFloat() * scale
        val y1 = y0 + (m.height + 2 * GlyphAtlas.BORDER).toFloat() * scale
        val u0 = m.atlasX.toFloat()
        val v0 = m.atlasY.toFloat()
        val u1 = u0 + (m.width + 2 * GlyphAtlas.BORDER).toFloat()
        val v1 = v0 + (m.height + 2 * GlyphAtlas.BORDER).toFloat()
        val c = cos(angle)
        val s = sin(angle)
        val fill = v.textColor.premultiplied(v.textOpacity * alpha)
        val halo = v.haloColor.premultiplied(v.textOpacity * alpha)
        fun vertex(x: Float, y: Float, u: Float, tv: Float) {
            out.ensure(15)
            val d = out.data
            var i = out.size
            d[i++] = originX + x * c - y * s; d[i++] = originY + x * s + y * c
            d[i++] = u; d[i++] = tv
            d[i++] = fill.r; d[i++] = fill.g; d[i++] = fill.b; d[i++] = fill.a
            d[i++] = halo.r; d[i++] = halo.g; d[i++] = halo.b; d[i++] = halo.a
            d[i++] = v.haloWidth; d[i++] = v.haloBlur; d[i++] = scale
            out.size = i
        }
        vertex(x0, y0, u0, v0); vertex(x1, y0, u1, v0); vertex(x0, y1, u0, v1)
        vertex(x1, y0, u1, v0); vertex(x1, y1, u1, v1); vertex(x0, y1, u0, v1)
    }

    private fun appendIcon(icon: SpriteAtlas.Icon, box: ScreenRect, opacity: Float, out: GrowableFloats) {
        val x0 = box.minX.toFloat()
        val y0 = box.minY.toFloat()
        val x1 = box.maxX.toFloat()
        val y1 = box.maxY.toFloat()
        val u0 = icon.x.toFloat()
        val v0 = icon.y.toFloat()
        val u1 = u0 + icon.width.toFloat()
        val v1 = v0 + icon.height.toFloat()
        fun vertex(x: Float, y: Float, u: Float, tv: Float) {
            out.ensure(5)
            val d = out.data
            var i = out.size
            d[i++] = x; d[i++] = y; d[i++] = u; d[i++] = tv; d[i++] = opacity
            out.size = i
        }
        vertex(x0, y0, u0, v0); vertex(x1, y0, u1, v0); vertex(x0, y1, u0, v1)
        vertex(x1, y0, u1, v0); vertex(x1, y1, u1, v1); vertex(x0, y1, u0, v1)
    }

    private fun drawText(context: RenderContext, vertices: GrowableFloats, count: Int) {
        if (count == 0) return
        val texture = glyphs.texture ?: return
        val program = context.use("text_vs", "text_fs") ?: return
        val transform = context.transform
        program.setVec2("u_screen", transform.width.toFloat(), transform.height.toFloat())
        program.setVec2("u_atlasSize", GlyphAtlas.SIZE.toFloat(), GlyphAtlas.SIZE.toFloat())
        texture.bind(program, 0, "u_tex")
        program.setFloat("u_gamma", 0.105f / context.pixelRatio.toFloat())
        // Halos first, then the text over them.
        program.setFloat("u_isHalo", 1f)
        context.drawVertices(vertices.data, TEXT_LAYOUT, count)
        program.setFloat("u_isHalo", 0f)
        // The same vertices are still bound.
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, count / TEXT_LAYOUT.stride)
    }

    private fun drawIcons(context: RenderContext, vertices: GrowableFloats, count: Int) {
        if (count == 0) return
        val texture = sprite?.texture ?: return
        val program = context.use("icon_vs", "icon_fs") ?: return
        val transform = context.transform
        program.setVec2("u_screen", transform.width.toFloat(), transform.height.toFloat())
        program.setVec2("u_atlasSize", texture.width.toFloat(), texture.height.toFloat())
        texture.bind(program, 0, "u_tex")
        context.drawVertices(vertices.data, ICON_LAYOUT, count)
    }

    companion object {
        /** Position, atlas pixel, fill, halo, (halo width, halo blur, font scale). */
        private val TEXT_LAYOUT = VertexLayout(2, 2, 4, 4, 3)
        /** Position, atlas pixel, opacity. */
        private val ICON_LAYOUT = VertexLayout(2, 2, 1)

        /** A line in screen points; null when any of it is behind the camera or it has under two points. */
        private fun projectPath(mercator: DoubleArray, transform: MapTransform, projection: Mat4): ScreenPath? {
            val n = mercator.size / 2
            if (n < 2) return null
            val xs = DoubleArray(n)
            val ys = DoubleArray(n)
            for (i in 0 until n) {
                val p = transform.screenPoint(Vec2(mercator[2 * i], mercator[2 * i + 1]), projection) ?: return null
                xs[i] = p.x; ys[i] = p.y
            }
            return ScreenPath(xs, ys)
        }

        /** Points every `spacing` along a line on screen, starting half a spacing in. */
        fun lineAnchors(mercator: List<Vec2>, spacing: Float, transform: MapTransform, projection: Mat4): List<Vec2> {
            val points = mercator.mapNotNull { transform.screenPoint(it, projection) }
            if (points.size < 2) return emptyList()
            val path = ScreenPath(DoubleArray(points.size) { points[it].x }, DoubleArray(points.size) { points[it].y })
            val result = ArrayList<Vec2>()
            val at = DoubleArray(3)
            var d = spacing.toDouble() / 2
            while (d < path.length) {
                if (path.point(d, at)) result.add(Vec2(at[0], at[1]))
                d += spacing.toDouble()
            }
            return result
        }

        /** The screen point halfway along a line. */
        fun lineCenter(mercator: List<Vec2>, transform: MapTransform, projection: Mat4): Vec2? {
            val points = mercator.mapNotNull { transform.screenPoint(it, projection) }
            if (points.size < 2) return points.firstOrNull()?.let { Vec2(it.x, it.y) }
            val path = ScreenPath(DoubleArray(points.size) { points[it].x }, DoubleArray(points.size) { points[it].y })
            val at = DoubleArray(3)
            return if (path.point(path.length / 2, at)) Vec2(at[0], at[1]) else null
        }

        /** Where a box's top-left corner sits relative to its anchor (x, y in [Vec2]). */
        fun anchorOrigin(anchor: String, w: Double, h: Double): Vec2 = when (anchor) {
            "top" -> Vec2(-w / 2, 0.0)
            "bottom" -> Vec2(-w / 2, -h)
            "left" -> Vec2(0.0, -h / 2)
            "right" -> Vec2(-w, -h / 2)
            "top-left" -> Vec2(0.0, 0.0)
            "top-right" -> Vec2(-w, 0.0)
            "bottom-left" -> Vec2(0.0, -h)
            "bottom-right" -> Vec2(-w, -h)
            else -> Vec2(-w / 2, -h / 2)
        }

        /**
         * The engine's label text (`StyledLayer`): a field that mentions a name shows the name in the
         * device language (falling back to English, then the local name) on one line, and common
         * street words are abbreviated.
         */
        fun labelText(field: String, properties: Map<String, FeatureValue>, transform: String,
                      language: String = languageCode): String {
            var text = if (field.contains("name")) {
                properties["name:$language"]?.stringValue ?: ""
            } else {
                resolve(field, properties, "none")
            }
            if (text.isEmpty()) text = properties["name:en"]?.stringValue ?: ""
            if (text.isEmpty()) text = properties["name"]?.stringValue ?: ""
            for ((from, to) in abbreviations) text = text.replaceFirst(from, to)
            return when (transform) {
                "uppercase" -> text.uppercase()
                "lowercase" -> text.lowercase()
                else -> text
            }
        }

        /** The device's language, its first two letters (`en`, `fr`…), as iOS takes them. */
        val languageCode: String by lazy {
            Locale.getDefault().toLanguageTag().take(2).ifEmpty { "en" }
        }

        val abbreviations: List<Pair<String, String>> = listOf(
            "Northeast " to "NE ", "Southeast " to "SE ", "Southwest " to "SW ", "Northwest " to "NW ",
            "North " to "N ", "East " to "E ", "South " to "S ", "West " to "W ",
            " Road" to " Rd", " Street" to " St", " Lane" to " Ln", " Boulevard" to " Blvd", " Court" to " Ct",
            " Drive" to " Dr", " Avenue" to " Ave", " Parkway" to " Pkwy",
        )

        /** Fills `{property}` tokens from a feature; missing properties become empty. */
        fun resolve(template: String, properties: Map<String, FeatureValue>, transform: String): String {
            val result = StringBuilder()
            var i = 0
            while (true) {
                val open = template.indexOf('{', i)
                if (open < 0) break
                result.append(template, i, open)
                val close = template.indexOf('}', open)
                if (close < 0) {
                    result.append(template, open, template.length)
                    i = template.length
                    break
                }
                val key = template.substring(open + 1, close)
                result.append(properties[key]?.stringValue ?: "")
                i = close + 1
            }
            result.append(template, i, template.length)
            val lines = result.split('\n').filter { it.isNotEmpty() }.map { it.trimSpaces() }.filter { it.isNotEmpty() }
            val joined = lines.joinToString("\n")
            return when (transform) {
                "uppercase" -> joined.uppercase()
                "lowercase" -> joined.lowercase()
                else -> joined
            }
        }

        /** Trims spaces and tabs (not newlines), like trimming `.whitespaces` in Swift. */
        private fun String.trimSpaces(): String =
            trim { it == '\t' || Character.getType(it) == Character.SPACE_SEPARATOR.toInt() }

        private inline fun forEachCodePoint(s: String, action: (Int) -> Unit) {
            var i = 0
            while (i < s.length) {
                val cp = s.codePointAt(i)
                action(cp)
                i += Character.charCount(cp)
            }
        }
    }
}

// MARK: - Style values

/** A symbol layer's layout and paint properties, parsed once. */
internal class SymbolLayerProperties(layer: StyleLayer) {
    private val textField: StyleProperty<String>?
    private val textFont: List<String>
    private val textSize: StyleProperty<Double>
    private val textMaxWidth: StyleProperty<Double>
    private val textLineHeight: StyleProperty<Double>
    private val textLetterSpacing: StyleProperty<Double>
    private val textAnchor: StyleProperty<String>
    private val textVariableAnchor: List<String>?
    private val textOffset: StyleProperty<List<Double>>
    private val textTransform: StyleProperty<String>
    private val textPadding: StyleProperty<Double>
    private val textMaxAngle: StyleProperty<Double>
    private val textRotationAlignment: StyleProperty<String>
    private val symbolPlacement: StyleProperty<String>
    private val symbolSpacing: StyleProperty<Double>
    private val iconImage: StyleProperty<String>?
    private val iconSize: StyleProperty<Double>
    private val iconAnchor: StyleProperty<String>
    private val iconOffset: StyleProperty<List<Double>>
    private val iconPadding: StyleProperty<Double>
    private val iconRotate: StyleProperty<Double>
    private val textAllowOverlap: Boolean
    private val textIgnorePlacement: Boolean
    private val textOptional: Boolean
    private val iconAllowOverlap: Boolean
    private val iconIgnorePlacement: Boolean
    private val iconOptional: Boolean
    private val textColor: StyleProperty<RGBA>
    private val haloColor: StyleProperty<RGBA>
    private val haloWidth: StyleProperty<Double>
    private val haloBlur: StyleProperty<Double>
    private val textOpacity: StyleProperty<Double>
    private val iconOpacity: StyleProperty<Double>

    init {
        val l = layer.layout
        val p = layer.paint
        fun number(key: String, fallback: Double, dict: Map<String, Any?>): StyleProperty<Double> =
            StyleProperty.number(dict[key]) ?: StyleProperty(fallback)
        fun string(key: String, fallback: String): StyleProperty<String> =
            StyleProperty.fromJson(l[key], StyleConvert::string) ?: StyleProperty(fallback)
        fun bool(key: String): Boolean = l[key]?.let(StyleConvert::bool) ?: false
        fun offset(key: String): StyleProperty<List<Double>> =
            StyleProperty.fromJson(l[key], StyleConvert::numbers, StyleConvert::lerpNumbers)
                ?: StyleProperty(listOf(0.0, 0.0))
        textField = StyleProperty.fromJson(l["text-field"], StyleConvert::string)
        textFont = jsonStrings(l["text-font"]) ?: listOf("Noto Sans Regular")
        textSize = number("text-size", 16.0, l)
        textMaxWidth = number("text-max-width", 10.0, l)
        textLineHeight = number("text-line-height", 1.2, l)
        textLetterSpacing = number("text-letter-spacing", 0.0, l)
        textAnchor = string("text-anchor", "center")
        textVariableAnchor = jsonStrings(l["text-variable-anchor"])
        textOffset = offset("text-offset")
        textTransform = string("text-transform", "none")
        textPadding = number("text-padding", 2.0, l)
        textMaxAngle = number("text-max-angle", 45.0, l)
        textRotationAlignment = string("text-rotation-alignment", "auto")
        symbolPlacement = string("symbol-placement", "point")
        symbolSpacing = number("symbol-spacing", 250.0, l)
        iconImage = StyleProperty.fromJson(l["icon-image"], StyleConvert::string)
        iconSize = number("icon-size", 1.0, l)
        iconAnchor = string("icon-anchor", "center")
        iconOffset = offset("icon-offset")
        iconPadding = number("icon-padding", 2.0, l)
        iconRotate = number("icon-rotate", 0.0, l)
        textAllowOverlap = bool("text-allow-overlap")
        textIgnorePlacement = bool("text-ignore-placement")
        textOptional = bool("text-optional")
        iconAllowOverlap = bool("icon-allow-overlap")
        iconIgnorePlacement = bool("icon-ignore-placement")
        iconOptional = bool("icon-optional")
        textColor = StyleProperty.color(p["text-color"]) ?: StyleProperty(RGBA.black)
        haloColor = StyleProperty.color(p["text-halo-color"]) ?: StyleProperty(RGBA.clear)
        haloWidth = number("text-halo-width", 0.0, p)
        haloBlur = number("text-halo-blur", 0.0, p)
        textOpacity = number("text-opacity", 1.0, p)
        iconOpacity = number("icon-opacity", 1.0, p)
    }

    fun evaluate(zoom: Double): SymbolValues {
        val placement = symbolPlacement.evaluate(zoom)
        val rotation = textRotationAlignment.evaluate(zoom)
        val offset = textOffset.evaluate(zoom)
        val iconOffset = iconOffset.evaluate(zoom)
        return SymbolValues(
            textField = textField?.evaluate(zoom),
            fontStack = textFont.joinToString(","),
            // `_fontSizeBugFixContinuityFactor`: the engine draws labels 10% larger than styled.
            textSize = textSize.evaluate(zoom).toFloat() * 1.10f,
            maxWidth = textMaxWidth.evaluate(zoom).toFloat(),
            lineHeight = textLineHeight.evaluate(zoom).toFloat(),
            // The engine's label bitmaps have no letter spacing.
            letterSpacing = 0f,
            // The engine uses the first variable anchor in place of `text-anchor`.
            textAnchor = textVariableAnchor?.firstOrNull() ?: textAnchor.evaluate(zoom),
            textVariableAnchor = textVariableAnchor,
            textOffsetX = (offset.firstOrNull() ?: 0.0).toFloat(),
            textOffsetY = (if (offset.size > 1) offset[1] else 0.0).toFloat(),
            textTransform = textTransform.evaluate(zoom),
            textPadding = textPadding.evaluate(zoom).toFloat(),
            textMaxAngle = textMaxAngle.evaluate(zoom).toFloat(),
            textRotationAlignment =
                if (rotation == "auto") (if (placement == "point") "viewport" else "map") else rotation,
            placement = placement,
            symbolSpacing = symbolSpacing.evaluate(zoom).toFloat(),
            iconImage = iconImage?.evaluate(zoom),
            iconSize = iconSize.evaluate(zoom).toFloat(),
            iconAnchor = iconAnchor.evaluate(zoom),
            iconOffsetX = (iconOffset.firstOrNull() ?: 0.0).toFloat(),
            iconOffsetY = (if (iconOffset.size > 1) iconOffset[1] else 0.0).toFloat(),
            iconPadding = iconPadding.evaluate(zoom).toFloat(),
            iconRotate = iconRotate.evaluate(zoom).toFloat(),
            textAllowOverlap = textAllowOverlap,
            textIgnorePlacement = textIgnorePlacement,
            textOptional = textOptional,
            iconAllowOverlap = iconAllowOverlap,
            iconIgnorePlacement = iconIgnorePlacement,
            iconOptional = iconOptional,
            textColor = textColor.evaluate(zoom),
            haloColor = haloColor.evaluate(zoom),
            // The engine reads halo width and blur at zoom 0.
            haloWidth = haloWidth.evaluate(0.0).toFloat(),
            haloBlur = haloBlur.evaluate(0.0).toFloat(),
            textOpacity = textOpacity.evaluate(zoom).toFloat(),
            iconOpacity = iconOpacity.evaluate(zoom).toFloat(),
        )
    }
}

/** A symbol layer's values at one zoom. */
internal data class SymbolValues(
    val textField: String?,
    val fontStack: String,
    val textSize: Float,
    val maxWidth: Float,
    val lineHeight: Float,
    val letterSpacing: Float,
    val textAnchor: String,
    val textVariableAnchor: List<String>?,
    val textOffsetX: Float,
    val textOffsetY: Float,
    val textTransform: String,
    val textPadding: Float,
    val textMaxAngle: Float,
    val textRotationAlignment: String,
    val placement: String,
    val symbolSpacing: Float,
    val iconImage: String?,
    val iconSize: Float,
    val iconAnchor: String,
    val iconOffsetX: Float,
    val iconOffsetY: Float,
    val iconPadding: Float,
    val iconRotate: Float,
    val textAllowOverlap: Boolean,
    val textIgnorePlacement: Boolean,
    val textOptional: Boolean,
    val iconAllowOverlap: Boolean,
    val iconIgnorePlacement: Boolean,
    val iconOptional: Boolean,
    val textColor: RGBA,
    val haloColor: RGBA,
    val haloWidth: Float,
    val haloBlur: Float,
    val textOpacity: Float,
    val iconOpacity: Float,
) {
    /**
     * Text and icons drawn larger or smaller; placement and collision boxes follow, as both are
     * measured from these sizes.
     */
    fun scaled(scale: Float): SymbolValues =
        if (scale == 1f) this else copy(textSize = textSize * scale, iconSize = iconSize * scale)
}

// MARK: - Geometry

/** An axis-aligned screen rectangle in points, y down. Widths and heights are never negative. */
internal class ScreenRect(val minX: Double, val minY: Double, val width: Double, val height: Double) {
    val maxX: Double get() = minX + width
    val maxY: Double get() = minY + height

    /** Whether the two overlap with some area (touching edges don't count). */
    fun intersects(o: ScreenRect): Boolean =
        minX < o.maxX && o.minX < maxX && minY < o.maxY && o.minY < maxY

    fun union(o: ScreenRect): ScreenRect {
        val x0 = min(minX, o.minX)
        val y0 = min(minY, o.minY)
        return ScreenRect(x0, y0, max(maxX, o.maxX) - x0, max(maxY, o.maxY) - y0)
    }

    /** Grown by `d` on every side. */
    fun outset(d: Double): ScreenRect =
        if (d == 0.0) this else ScreenRect(minX - d, minY - d, width + 2 * d, height + 2 * d)
}

/** Screen-space boxes of placed labels, bucketed in a grid for quick overlap tests. */
internal class CollisionGrid(private val bounds: ScreenRect) {
    private val columns = max(1, ceil(bounds.width / CELL).toInt())
    private val rows = max(1, ceil(bounds.height / CELL).toInt())
    /** Each cell's boxes, as indices into [boxes]. */
    private val cells = arrayOfNulls<IntList>(columns * rows)
    /** minX, minY, maxX, maxY of every inserted box. */
    private val boxes = DoubleList()
    private val range = IntArray(4)

    fun contains(x: Double, y: Double): Boolean =
        x >= bounds.minX && x < bounds.maxX && y >= bounds.minY && y < bounds.maxY

    /** Fills [range] with the first and last column and row the box touches; false when it's outside the grid. */
    private fun cellRange(r: ScreenRect): Boolean {
        val x0 = max(r.minX, bounds.minX)
        val x1 = min(r.maxX, bounds.maxX)
        val y0 = max(r.minY, bounds.minY)
        val y1 = min(r.maxY, bounds.maxY)
        if (!(x0 < x1 && y0 < y1)) return false
        range[0] = max(0, ((x0 - bounds.minX) / CELL).toInt())
        range[1] = min(columns - 1, ((x1 - bounds.minX) / CELL).toInt())
        range[2] = max(0, ((y0 - bounds.minY) / CELL).toInt())
        range[3] = min(rows - 1, ((y1 - bounds.minY) / CELL).toInt())
        return true
    }

    fun collides(r: ScreenRect): Boolean {
        if (!cellRange(r)) return false
        val b = boxes.data
        for (row in range[2]..range[3]) for (column in range[0]..range[1]) {
            val cell = cells[row * columns + column] ?: continue
            for (k in 0 until cell.size) {
                val i = cell.data[k] * 4
                if (r.minX < b[i + 2] && b[i] < r.maxX && r.minY < b[i + 3] && b[i + 1] < r.maxY) return true
            }
        }
        return false
    }

    fun insert(r: ScreenRect) {
        if (!cellRange(r)) return
        val index = boxes.size / 4
        boxes.add(r.minX); boxes.add(r.minY); boxes.add(r.maxX); boxes.add(r.maxY)
        for (row in range[2]..range[3]) for (column in range[0]..range[1]) {
            val cell = cells[row * columns + column] ?: IntList(8).also { cells[row * columns + column] = it }
            cell.add(index)
        }
    }

    private companion object {
        const val CELL = 64.0
    }
}

/** A polyline in screen points, measured along its length. */
internal class ScreenPath(val xs: DoubleArray, val ys: DoubleArray) {
    val cumulative = DoubleArray(max(xs.size, 1))
    val length: Double get() = cumulative.last()

    init {
        for (i in 1 until xs.size) cumulative[i] = cumulative[i - 1] + hypot(xs[i] - xs[i - 1], ys[i] - ys[i - 1])
    }

    /**
     * The point at a distance along the path and the direction of travel there (radians, screen
     * space), into `out` as x, y, angle. False when the distance is off the path.
     */
    fun point(d: Double, out: DoubleArray): Boolean {
        if (xs.size < 2 || !(d >= 0) || !(d <= length)) return false
        var i = 1
        while (i < xs.size - 1 && cumulative[i] < d) i += 1
        val segment = cumulative[i] - cumulative[i - 1]
        val t = if (segment > 0) (d - cumulative[i - 1]) / segment else 0.0
        out[0] = xs[i - 1] + (xs[i] - xs[i - 1]) * t
        out[1] = ys[i - 1] + (ys[i] - ys[i - 1]) * t
        out[2] = atan2(ys[i] - ys[i - 1], xs[i] - xs[i - 1])
        return true
    }
}

/** A growable float array that can be cleared and refilled without reallocating. */
internal class GrowableFloats(capacity: Int = 4096) {
    var data = FloatArray(capacity); private set
    var size = 0

    fun clear() {
        size = 0
    }

    /** Makes room for `n` more values. */
    fun ensure(n: Int) {
        if (size + n > data.size) data = data.copyOf(max(data.size * 2, size + n))
    }
}

/** A growable double array. */
internal class DoubleList(capacity: Int = 64) {
    var data = DoubleArray(capacity); private set
    var size = 0; private set

    fun add(v: Double) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = v
    }

    fun clear() {
        size = 0
    }
}
