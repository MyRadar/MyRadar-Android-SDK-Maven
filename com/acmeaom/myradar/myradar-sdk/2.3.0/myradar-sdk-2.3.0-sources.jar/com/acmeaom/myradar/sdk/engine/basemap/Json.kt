package com.acmeaom.myradar.sdk.engine.basemap

import org.json.JSONException
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Parses JSON into plain Kotlin values: `Map<String, Any?>` (a [LinkedHashMap], in document
 * order), `List<Any?>`, `String`, `Boolean`, `Double` (every number) and `null` for JSON null.
 * Returns null when the text isn't valid JSON.
 */
internal fun parseJson(text: String): Any? = try {
    val tokener = JSONTokener(text)
    val value = readJsonValue(tokener)
    // Like a strict parser, reject anything after the document.
    if (tokener.nextClean() != 0.toChar()) null else value
} catch (e: JSONException) {
    null
} catch (e: RuntimeException) {
    null
}

/** Parses UTF-8 JSON bytes; see [parseJson]. */
internal fun parseJson(bytes: ByteArray): Any? = parseJson(String(bytes, Charsets.UTF_8))

/**
 * Objects and arrays are read here rather than by `JSONObject`, whose JVM implementation is
 * backed by a `HashMap` and would lose the key order.
 */
private fun readJsonValue(tokener: JSONTokener): Any? {
    when (tokener.nextClean()) {
        '{' -> {
            val map = LinkedHashMap<String, Any?>()
            if (tokener.nextClean() == '}') return map
            tokener.back()
            while (true) {
                val key = when (val c = tokener.nextClean()) {
                    '"', '\'' -> tokener.nextString(c)
                    else -> throw tokener.syntaxError("Expected a string key")
                }
                if (tokener.nextClean() != ':') throw tokener.syntaxError("Expected ':'")
                map[key] = readJsonValue(tokener)
                when (tokener.nextClean()) {
                    ',' -> continue
                    '}' -> return map
                    else -> throw tokener.syntaxError("Expected ',' or '}'")
                }
            }
        }
        '[' -> {
            val list = ArrayList<Any?>()
            if (tokener.nextClean() == ']') return list
            tokener.back()
            while (true) {
                list.add(readJsonValue(tokener))
                when (tokener.nextClean()) {
                    ',' -> continue
                    ']' -> return list
                    else -> throw tokener.syntaxError("Expected ',' or ']'")
                }
            }
        }
        0.toChar() -> throw tokener.syntaxError("Unexpected end of input")
        else -> {
            tokener.back()
            return when (val v = tokener.nextValue()) {
                JSONObject.NULL -> null
                is Number -> v.toDouble()
                is String, is Boolean -> v
                else -> throw tokener.syntaxError("Unexpected value")
            }
        }
    }
}

/** The value as a JSON object, or null. */
@Suppress("UNCHECKED_CAST")
internal fun jsonObject(value: Any?): Map<String, Any?>? = value as? Map<String, Any?>

/** The value as a list of JSON objects, or null when it isn't an array or any element isn't an object. */
internal fun jsonObjects(value: Any?): List<Map<String, Any?>>? {
    val list = value as? List<*> ?: return null
    return list.map { jsonObject(it) ?: return null }
}

/** The value as a list of strings, or null when it isn't an array or any element isn't a string. */
internal fun jsonStrings(value: Any?): List<String>? {
    val list = value as? List<*> ?: return null
    return list.map { it as? String ?: return null }
}
