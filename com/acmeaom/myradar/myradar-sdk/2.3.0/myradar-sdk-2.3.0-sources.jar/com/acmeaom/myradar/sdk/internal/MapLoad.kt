package com.acmeaom.myradar.sdk.internal

import com.acmeaom.myradar.sdk.MyRadarSdk
import java.net.URLEncoder

/**
 * A map load: each map view reports once, the first time it is attached while the SDK is
 * configured, so MyRadar can count map loads per API key (for billing). The gateway answers it
 * itself; nothing is fetched.
 */
internal object MapLoad {
    /** The gateway route that records a map load. */
    const val PATH = "/sdk/v1/map-load"

    /** The request URL: the platform and SDK version go with it; the key and install ID are added like on every gateway request. */
    val url: String
        get() = GatewayConfiguration.endpoint(PATH) + "?platform=android&sdk=" +
            URLEncoder.encode(MyRadarSdk.VERSION, "UTF-8")
}
