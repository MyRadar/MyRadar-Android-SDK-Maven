package com.acmeaom.myradar.sdk.engine.camera

import com.acmeaom.myradar.sdk.LatLng
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tan

/** A point in normalized Web Mercator (x east, y south, both 0..1 across the world). */
internal data class Vec2(val x: Double, val y: Double) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(s: Double) = Vec2(x * s, y * s)
    operator fun div(s: Double) = Vec2(x / s, y / s)
    fun dot(o: Vec2) = x * o.x + y * o.y
    val length: Double get() = kotlin.math.sqrt(x * x + y * y)
}

/** A screen position in points (dp). */
internal data class ScreenPoint(val x: Double, val y: Double)

/**
 * The camera: Web Mercator position, zoom, heading and tilt, the matrices that project map
 * coordinates to the screen, and the conversions between screen points and coordinates.
 *
 * Zoom uses 256-point world tiles, so the world is 256 × 2^zoom points (dp) wide. Mapbox-style
 * zooms, which assume 512-point tiles, are one lower; see [styleZoom].
 */
internal class MapTransform {
    /** The viewport size in points (dp). */
    var width: Double = 1.0
    var height: Double = 1.0

    /** Map center in normalized Web Mercator. */
    var center = Vec2(0.5, 0.5); private set
    var zoom = 4.0; private set
    /** Compass direction at the top of the screen, degrees clockwise from north. */
    var heading = 0.0; private set
    /** Degrees from looking straight down. */
    var tilt = 0.0; private set

    fun copy(): MapTransform = MapTransform().also {
        it.width = width; it.height = height
        it.center = center; it.zoom = zoom; it.heading = heading; it.tilt = tilt
    }

    val worldSize: Double get() = TILE_SIZE * 2.0.pow(zoom)

    /** The zoom a Mapbox GL style (512-point tiles) expects for this view. */
    val styleZoom: Double get() = zoom - 1

    var coordinate: LatLng
        get() = coordinate(center)
        set(value) = setCenter(mercator(value))

    fun setCenter(mercator: Vec2) {
        // Wrap longitude so the camera can pan around the world; clamp latitude.
        var x = mercator.x % 1.0
        if (x < 0) x += 1.0
        center = Vec2(x, mercator.y.coerceIn(0.0, 1.0))
    }

    fun setZoom(value: Double) {
        if (!value.isFinite()) return
        zoom = value.coerceIn(MIN_ZOOM, MAX_ZOOM)
    }

    fun setHeading(value: Double) {
        if (!value.isFinite()) return
        var h = value % 360.0
        if (h < 0) h += 360.0
        heading = h
    }

    fun setTilt(value: Double) {
        if (!value.isFinite()) return
        tilt = value.coerceIn(0.0, MAX_TILT)
    }

    // MARK: Matrices

    val cameraToCenterDistance: Double get() = 0.5 / tan(FIELD_OF_VIEW / 2) * height

    /** Projects world points (Mercator × worldSize, y down) to clip space. */
    val projectionMatrix: Mat4
        get() {
            val w = max(width, 1.0)
            val h = max(height, 1.0)
            val pitch = tilt * PI / 180
            val halfFov = FIELD_OF_VIEW / 2
            val distance = cameraToCenterDistance
            val groundAngle = PI / 2 + pitch
            val topHalfSurfaceDistance = sin(halfFov) * distance / sin(PI - groundAngle - halfFov)
            val furthest = cos(PI / 2 - pitch) * topHalfSurfaceDistance + distance
            val far = furthest * 1.01
            val near = h / 50
            val world = center * worldSize
            return Mat4.perspective(FIELD_OF_VIEW, w / h, near, far) *
                Mat4.scale(1.0, -1.0, 1.0) *
                Mat4.translate(0.0, 0.0, -distance) *
                Mat4.rotateX(pitch) *
                Mat4.rotateZ(-heading * PI / 180) *
                Mat4.translate(-world.x, -world.y, 0.0)
        }

    /** Clip space for a tile whose geometry runs 0..extent across, at a whole-world offset `wrap`. */
    fun tileMatrix(z: Int, x: Int, y: Int, wrap: Int, extent: Double, projection: Mat4): FloatArray {
        val tiles = 2.0.pow(z)
        val tileWorld = worldSize / tiles
        val originX = (x + wrap * tiles) * tileWorld
        val originY = y * tileWorld
        return (projection * Mat4.translate(originX, originY, 0.0) *
            Mat4.scale(tileWorld / extent, tileWorld / extent, 1.0)).toFloatArray()
    }

    /** Projects a Mercator point to screen points; null when it's behind the camera. */
    fun screenPoint(mercator: Vec2, projection: Mat4 = projectionMatrix): ScreenPoint? {
        val p = projection.transform(mercator.x * worldSize, mercator.y * worldSize, 0.0, 1.0)
        if (p[3] <= 0) return null
        return ScreenPoint((p[0] / p[3] + 1) / 2 * width, (1 - p[1] / p[3]) / 2 * height)
    }

    /** The Mercator point under a screen point, or null when the point is above the horizon. */
    fun mercatorAt(point: ScreenPoint, projection: Mat4 = projectionMatrix): Vec2? {
        val inverse = projection.inverse() ?: return null
        val nx = 2 * point.x / width - 1
        val ny = 1 - 2 * point.y / height
        // OpenGL clip space: depth -1 at the near plane, 1 at the far plane.
        val n = inverse.transform(nx, ny, -1.0, 1.0)
        val f = inverse.transform(nx, ny, 1.0, 1.0)
        val ax = n[0] / n[3]; val ay = n[1] / n[3]; val az = n[2] / n[3]
        val bx = f[0] / f[3]; val by = f[1] / f[3]; val bz = f[2] / f[3]
        val dz = bz - az
        if (abs(dz) < 1e-12) return null
        val t = -az / dz
        if (t < 0 || t > 1) return null
        return Vec2(ax + (bx - ax) * t, ay + (by - ay) * t) / worldSize
    }

    /** The zoom at which a coordinate region fills the viewport. */
    fun zoomFitting(latitudeDelta: Double, longitudeDelta: Double, centerLatitude: Double): Double {
        val north = mercator(LatLng(min(centerLatitude + latitudeDelta / 2, MAX_LATITUDE), 0.0))
        val south = mercator(LatLng(max(centerLatitude - latitudeDelta / 2, -MAX_LATITUDE), 0.0))
        val spanX = longitudeDelta / 360
        val spanY = abs(south.y - north.y)
        if (spanX <= 0 && spanY <= 0) return Double.NaN
        val zx = if (spanX > 0) log2(width / (spanX * TILE_SIZE)) else Double.POSITIVE_INFINITY
        val zy = if (spanY > 0) log2(height / (spanY * TILE_SIZE)) else Double.POSITIVE_INFINITY
        return min(zx, zy)
    }

    companion object {
        const val MIN_ZOOM = 2.5
        const val MAX_ZOOM = 19.0
        const val MAX_TILT = 60.0
        const val TILE_SIZE = 256.0
        /** Vertical field of view, as in Mapbox GL, so tilted views look the same. */
        const val FIELD_OF_VIEW = 0.6435011087932844
        const val MAX_LATITUDE = 85.051128779806604

        fun mercator(coordinate: LatLng): Vec2 {
            val lat = coordinate.latitude.coerceIn(-MAX_LATITUDE, MAX_LATITUDE)
            val x = (coordinate.longitude + 180) / 360
            val sinLat = sin(lat * PI / 180)
            val y = 0.5 - ln((1 + sinLat) / (1 - sinLat)) / (4 * PI)
            return Vec2(x, y)
        }

        fun coordinate(m: Vec2): LatLng {
            val lon = m.x * 360 - 180
            val n = PI - 2 * PI * m.y
            val lat = 180 / PI * atan(0.5 * (exp(n) - exp(-n)))
            return LatLng(lat, lon)
        }
    }
}

/** A 4×4 matrix of doubles, column-major as OpenGL expects. */
internal class Mat4(val m: DoubleArray = identity()) {
    operator fun times(o: Mat4): Mat4 {
        val r = DoubleArray(16)
        for (c in 0 until 4) for (row in 0 until 4) {
            var s = 0.0
            for (k in 0 until 4) s += m[k * 4 + row] * o.m[c * 4 + k]
            r[c * 4 + row] = s
        }
        return Mat4(r)
    }

    fun transform(x: Double, y: Double, z: Double, w: Double): DoubleArray = DoubleArray(4) { row ->
        m[row] * x + m[4 + row] * y + m[8 + row] * z + m[12 + row] * w
    }

    fun toFloatArray(): FloatArray = FloatArray(16) { m[it].toFloat() }

    fun inverse(): Mat4? {
        val a = m
        val inv = DoubleArray(16)
        inv[0] = a[5] * a[10] * a[15] - a[5] * a[11] * a[14] - a[9] * a[6] * a[15] + a[9] * a[7] * a[14] + a[13] * a[6] * a[11] - a[13] * a[7] * a[10]
        inv[4] = -a[4] * a[10] * a[15] + a[4] * a[11] * a[14] + a[8] * a[6] * a[15] - a[8] * a[7] * a[14] - a[12] * a[6] * a[11] + a[12] * a[7] * a[10]
        inv[8] = a[4] * a[9] * a[15] - a[4] * a[11] * a[13] - a[8] * a[5] * a[15] + a[8] * a[7] * a[13] + a[12] * a[5] * a[11] - a[12] * a[7] * a[9]
        inv[12] = -a[4] * a[9] * a[14] + a[4] * a[10] * a[13] + a[8] * a[5] * a[14] - a[8] * a[6] * a[13] - a[12] * a[5] * a[10] + a[12] * a[6] * a[9]
        inv[1] = -a[1] * a[10] * a[15] + a[1] * a[11] * a[14] + a[9] * a[2] * a[15] - a[9] * a[3] * a[14] - a[13] * a[2] * a[11] + a[13] * a[3] * a[10]
        inv[5] = a[0] * a[10] * a[15] - a[0] * a[11] * a[14] - a[8] * a[2] * a[15] + a[8] * a[3] * a[14] + a[12] * a[2] * a[11] - a[12] * a[3] * a[10]
        inv[9] = -a[0] * a[9] * a[15] + a[0] * a[11] * a[13] + a[8] * a[1] * a[15] - a[8] * a[3] * a[13] - a[12] * a[1] * a[11] + a[12] * a[3] * a[9]
        inv[13] = a[0] * a[9] * a[14] - a[0] * a[10] * a[13] - a[8] * a[1] * a[14] + a[8] * a[2] * a[13] + a[12] * a[1] * a[10] - a[12] * a[2] * a[9]
        inv[2] = a[1] * a[6] * a[15] - a[1] * a[7] * a[14] - a[5] * a[2] * a[15] + a[5] * a[3] * a[14] + a[13] * a[2] * a[7] - a[13] * a[3] * a[6]
        inv[6] = -a[0] * a[6] * a[15] + a[0] * a[7] * a[14] + a[4] * a[2] * a[15] - a[4] * a[3] * a[14] - a[12] * a[2] * a[7] + a[12] * a[3] * a[6]
        inv[10] = a[0] * a[5] * a[15] - a[0] * a[7] * a[13] - a[4] * a[1] * a[15] + a[4] * a[3] * a[13] + a[12] * a[1] * a[7] - a[12] * a[3] * a[5]
        inv[14] = -a[0] * a[5] * a[14] + a[0] * a[6] * a[13] + a[4] * a[1] * a[14] - a[4] * a[2] * a[13] - a[12] * a[1] * a[6] + a[12] * a[2] * a[5]
        inv[3] = -a[1] * a[6] * a[11] + a[1] * a[7] * a[10] + a[5] * a[2] * a[11] - a[5] * a[3] * a[10] - a[9] * a[2] * a[7] + a[9] * a[3] * a[6]
        inv[7] = a[0] * a[6] * a[11] - a[0] * a[7] * a[10] - a[4] * a[2] * a[11] + a[4] * a[3] * a[10] + a[8] * a[2] * a[7] - a[8] * a[3] * a[6]
        inv[11] = -a[0] * a[5] * a[11] + a[0] * a[7] * a[9] + a[4] * a[1] * a[11] - a[4] * a[3] * a[9] - a[8] * a[1] * a[7] + a[8] * a[3] * a[5]
        inv[15] = a[0] * a[5] * a[10] - a[0] * a[6] * a[9] - a[4] * a[1] * a[10] + a[4] * a[2] * a[9] + a[8] * a[1] * a[6] - a[8] * a[2] * a[5]
        val det = a[0] * inv[0] + a[1] * inv[4] + a[2] * inv[8] + a[3] * inv[12]
        if (det == 0.0 || !det.isFinite()) return null
        for (i in 0 until 16) inv[i] /= det
        return Mat4(inv)
    }

    companion object {
        fun identity() = DoubleArray(16).also { it[0] = 1.0; it[5] = 1.0; it[10] = 1.0; it[15] = 1.0 }

        /** OpenGL's clip space: depth -1 at the near plane, 1 at the far plane. */
        fun perspective(fovy: Double, aspect: Double, near: Double, far: Double): Mat4 {
            val f = 1 / tan(fovy / 2)
            val nf = 1 / (near - far)
            val r = DoubleArray(16)
            r[0] = f / aspect
            r[5] = f
            r[10] = (far + near) * nf
            r[11] = -1.0
            r[14] = 2 * far * near * nf
            return Mat4(r)
        }

        fun translate(x: Double, y: Double, z: Double) = Mat4(identity().also { it[12] = x; it[13] = y; it[14] = z })

        fun scale(x: Double, y: Double, z: Double) = Mat4(identity().also { it[0] = x; it[5] = y; it[10] = z })

        fun rotateX(a: Double): Mat4 {
            val c = cos(a); val s = sin(a)
            return Mat4(identity().also { it[5] = c; it[6] = s; it[9] = -s; it[10] = c })
        }

        fun rotateZ(a: Double): Mat4 {
            val c = cos(a); val s = sin(a)
            return Mat4(identity().also { it[0] = c; it[1] = s; it[4] = -s; it[5] = c })
        }
    }
}
