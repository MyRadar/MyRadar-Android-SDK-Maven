package com.acmeaom.myradar.sdk.engine.overlays

import android.util.Log
import com.acmeaom.myradar.sdk.LatLng
import com.acmeaom.myradar.sdk.engine.EngineAssets
import com.acmeaom.myradar.sdk.engine.basemap.jsonObject
import com.acmeaom.myradar.sdk.engine.basemap.jsonObjects
import com.acmeaom.myradar.sdk.engine.basemap.parseJson
import com.acmeaom.myradar.sdk.engine.camera.Mat4
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import com.acmeaom.myradar.sdk.engine.gl.BlendMode
import com.acmeaom.myradar.sdk.engine.gl.GPUMesh
import com.acmeaom.myradar.sdk.engine.gl.GPUTexture
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.gl.VertexLayout
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.internal.GatewayConfiguration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Date
import kotlin.math.min
import kotlin.random.Random

/*
 * Lightning that follows the radar loop. Port of the engine's `LightningData`,
 * `LightningMarkers` and `LightningDataDummyProgram`:
 *
 * - Data: two hours of 5-minute strike frames, refetched whenever the radar's frame times
 *   change. Each frame is a set of MultiPoint features with a `rate` (strikes per 5 minutes).
 * - Markers: one stamp set per 5-minute frame, shown while the radar frame on screen falls in
 *   that window, fading in and out at 3 per second.
 * - Flashes: while the loop plays, each drawn frame picks a strike at random, weighted by rate,
 *   with a probability matching the strike rate at loop speed, and brightens the base map
 *   around it for that one frame (the engine's shape and tile shaders,
 *   `frag_color *= 1 + 1.5 * radius / |d|²` with d measured in Mercator meters from a point
 *   10 km above the strike).
 */

/**
 * What lightning needs from the radar loop. The radar renderer implements it (or MapEngineView
 * adapts it).
 */
internal interface RadarClock {
    /** The radar frame on screen, or null when there is none. */
    val currentFrameDate: Date?
    val isLoopPaused: Boolean
    /** Seconds each radar frame shows while the loop plays; 0 when unknown. */
    val frameInterval: Double
}

/** What the lightning layer shows, from the map's preferences. */
internal data class LightningSettings(
    val markers: Boolean = false,
    val flashes: Boolean = false,
    /** The radar loop is on; lightning follows it and is off without it. */
    val radarEnabled: Boolean = false,
) {
    val enabled: Boolean get() = (markers || flashes) && radarEnabled
}

/** Draws lightning markers and flashes. Main thread only. */
internal class LightningRenderer(private val network: EngineNetwork) {
    var onNeedsDisplay: (() -> Unit)? = null

    var settings: LightningSettings = LightningSettings()
        set(value) {
            val old = field
            if (value == old) return
            field = value
            if (value.enabled != old.enabled) {
                if (value.enabled) refresh() else clear()
            }
            onNeedsDisplay?.invoke()
        }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    /** Frames by the end of their 5-minute window, in epoch seconds. */
    private val frames = HashMap<Long, LightningFrame>()
    private val stamps = HashMap<Long, Stamp>()
    private var generation = 0
    private var fetchJob: Job? = null
    private var lastFlashUpdate = 0.0
    private var flash: Vec2? = null

    /** This frame's strike, in Web Mercator, once [drawFlash] has run. */
    val currentFlash: Vec2? get() = flash

    private var markerTexture: GPUTexture? = null
    private var markerTextureLoaded = false
    private var flashQuad: GPUMesh? = null

    class LightningFrame(
        /** Strike locations in Web Mercator (0...1), with strikes per 5 minutes at each. */
        val features: List<Pair<List<Vec2>, Double>>,
    ) {
        val totalStrikes: Double get() = features.sumOf { (points, rate) -> points.size * rate }
    }

    private class Stamp(val origin: Vec2, val mesh: GPUMesh) {
        var alpha = 0f
        var lastDraw = 0.0
    }

    /** Stops fetching. The renderer can't be used afterwards. */
    fun dispose() {
        scope.cancel()
        fetchJob = null
    }

    // MARK: Data

    /**
     * `LightningData::requestOrUpdateState`: the last two hours of 5-minute frames. Called when
     * enabled and whenever the radar's frame times change.
     */
    fun refresh() {
        if (!settings.enabled) return
        fetchJob?.cancel()
        generation += 1
        val generation = this.generation
        val now = System.currentTimeMillis() / 1000L
        val newest = now - now % FRAME_SECONDS
        val dates = (0 until FRAME_COUNT).map { newest - it * FRAME_SECONDS }
        // Frames that fell out of the two hours go; the rest stay until their refetch lands.
        val keep = dates.toSet()
        frames.keys.retainAll(keep)
        stamps.keys.retainAll(keep)
        fetchJob = scope.launch {
            for (date in dates) {
                launch {
                    val hex = date.toString(16).uppercase()
                    val data = try {
                        network.data(GatewayConfiguration.endpoint("/v2/lightning/flashes/$hex"))
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        null
                    } ?: return@launch
                    val frame = withContext(Dispatchers.Default) { parse(data) } ?: return@launch
                    if (this@LightningRenderer.generation != generation) return@launch
                    frames[date] = frame
                    stamps.remove(date)
                    onNeedsDisplay?.invoke()
                }
            }
        }
    }

    private fun clear() {
        fetchJob?.cancel()
        fetchJob = null
        generation += 1
        frames.clear()
        stamps.clear()
        flash = null
    }

    // MARK: Flashes

    /** `LightningDataDummyProgram::setupLightningFrame`, once per drawn frame. */
    private fun updateFlash(now: Double, radar: RadarClock) {
        val displayDuration = if (lastFlashUpdate > 0) now - lastFlashUpdate else 0.0
        lastFlashUpdate = now
        flash = null
        if (!settings.flashes || !settings.enabled || radar.isLoopPaused) return
        val current = radar.currentFrameDate?.let { it.time / 1000.0 } ?: return
        val frame = frames.entries.firstOrNull { current > it.key - FRAME_SECONDS && current <= it.key }?.value
            ?: return
        val total = frame.totalStrikes
        val interval = if (radar.frameInterval > 0) radar.frameInterval else 0.5
        // How many seconds of data play during a second of animation.
        val secondsPerSecond = FRAME_SECONDS / interval
        val simulatedSeconds = displayDuration * secondsPerSecond
        val strikesThisFrame = simulatedSeconds / FRAME_SECONDS * total * FREQUENCY_FACTOR
        if (Random.nextDouble() >= strikesThisFrame) return
        var index = total * Random.nextDouble()
        for ((points, rate) in frame.features) {
            val weight = points.size * rate
            if (index < weight) {
                val i = min((index / rate).toInt(), points.size - 1)
                flash = points[i]
                return
            }
            index -= weight
        }
    }

    /**
     * Brightens what's been drawn so far around this frame's strike, if any. Draw right after the
     * base map's fills and lines.
     */
    fun drawFlash(context: RenderContext, radar: RadarClock) {
        updateFlash(context.now, radar)
        val flash = flash ?: return
        val quad = flashQuad ?: run {
            val e = FLASH_EXTENT_METERS
            GPUMesh.create(floatArrayOf(-e, -e, e, -e, e, e, -e, e), intArrayOf(0, 1, 2, 0, 2, 3), VertexLayout(2))
        }?.also { flashQuad = it } ?: return
        val program = context.use("flash_vs", "flash_fs", BlendMode.BRIGHTEN) ?: return
        val transform = context.transform
        // The result is dst * (1 + src); the factor is split over passes because src tops out at 1.
        val passes = 3
        program.setFloat("u_radius", FLASH_RADIUS)
        program.setFloat("u_height", FLASH_HEIGHT)
        program.setFloat("u_passes", passes.toFloat())
        val projection = transform.projectionMatrix
        val unitsPerMeter = 1 / METERS_PER_WORLD
        for (wrap in MercatorShapes.visibleWraps(transform)) {
            val m = projection * Mat4.scale(transform.worldSize, transform.worldSize, 1.0) *
                Mat4.translate(flash.x + wrap, flash.y, 0.0) * Mat4.scale(unitsPerMeter, unitsPerMeter, 1.0)
            program.setMat4("u_matrix", m.toFloatArray())
            repeat(passes) { quad.draw() }
        }
    }

    // MARK: Markers

    /** Draws the strike markers for the radar frame on screen. Returns true while they're fading. */
    fun drawMarkers(context: RenderContext, radar: RadarClock): Boolean {
        if (!settings.markers || !settings.enabled) return false
        val texture = markerTexture() ?: return false
        val program = context.use("marker_vs", "marker_fs") ?: return false
        val transform = context.transform
        val now = context.now
        val current = radar.currentFrameDate?.let { it.time / 1000.0 }
        var fading = false
        texture.bind(program, 0, "u_tex")
        program.setVec2("u_sizeNdc", (2 * MARKER_SIZE / transform.width).toFloat(),
            (2 * MARKER_SIZE / transform.height).toFloat())
        val projection = transform.projectionMatrix
        val wraps = MercatorShapes.visibleWraps(transform)
        for ((date, frame) in frames.entries.sortedBy { it.key }) {
            // `LightningStamp::draw`: shown while the radar frame is within this 5-minute window.
            val visible = current != null && current >= date - FRAME_SECONDS && current <= date
            val stamp = stamp(date, frame) ?: continue
            // `computeAndUpdateHideShowFadeAlpha`, at 3 per second both ways.
            val elapsed = if (stamp.lastDraw > 0) (now - stamp.lastDraw).toFloat() else 0f
            stamp.lastDraw = now
            stamp.alpha = (stamp.alpha + (if (visible) 3 else -3) * elapsed).coerceIn(0f, 1f)
            if (stamp.alpha != (if (visible) 1f else 0f)) fading = true
            if (stamp.alpha <= 0) continue
            program.setFloat("u_alpha", stamp.alpha)
            for (wrap in wraps) {
                val m = projection * Mat4.scale(transform.worldSize, transform.worldSize, 1.0) *
                    Mat4.translate(stamp.origin.x + wrap, stamp.origin.y, 0.0)
                program.setMat4("u_matrix", m.toFloatArray())
                stamp.mesh.draw()
            }
        }
        return fading
    }

    private fun stamp(date: Long, frame: LightningFrame): Stamp? {
        stamps[date]?.let { return it }
        val points = frame.features.flatMap { it.first }
        val origin = points.firstOrNull() ?: return null
        val vertices = FloatArray(points.size * 16)
        val indices = IntArray(points.size * 6)
        var v = 0
        for ((i, p) in points.withIndex()) {
            val x = (p.x - origin.x).toFloat(); val y = (p.y - origin.y).toFloat()
            for (k in 0 until 4) {
                vertices[v++] = x; vertices[v++] = y
                vertices[v++] = CORNERS[2 * k]; vertices[v++] = CORNERS[2 * k + 1]
            }
            val base = i * 4
            val o = i * 6
            indices[o] = base; indices[o + 1] = base + 1; indices[o + 2] = base + 2
            indices[o + 3] = base; indices[o + 4] = base + 2; indices[o + 5] = base + 3
        }
        val mesh = GPUMesh.create(vertices, indices, VertexLayout(2, 2)) ?: return null
        return Stamp(origin, mesh).also { stamps[date] = it }
    }

    private fun markerTexture(): GPUTexture? {
        if (markerTextureLoaded) return markerTexture
        markerTextureLoaded = true
        val bitmap = EngineAssets.bitmap("lightningmarker@2x.png")
        if (bitmap == null) {
            Log.e(LOG_TAG, "The lightning marker image is missing")
            return null
        }
        val image = SpriteImage.fromBitmap(bitmap, bitmap.width / 2f, bitmap.height / 2f)
        markerTexture = image.texture()
        return markerTexture
    }

    companion object {
        private const val LOG_TAG = "MyRadarSDK"
        /** Points per marker side: the 72-pixel @2x icon. */
        private const val MARKER_SIZE = 36.0
        private const val FRAME_SECONDS = 300L
        private const val FRAME_COUNT = 24
        /** `kLightningFrequencyFactor`, `kLightningRadiusFactor`, `kLightningHeightFactor`. */
        private const val FREQUENCY_FACTOR = 0.5
        private const val FLASH_RADIUS = 2e9f
        private const val FLASH_HEIGHT = 10_000f
        /** Beyond this the brightening is under 1/255. */
        private const val FLASH_EXTENT_METERS = 900_000f
        /** Web Mercator meters across the world (`2 * FWWebMercatorBound`). */
        private const val METERS_PER_WORLD = 2 * 20_037_508.342789244
        private val CORNERS = floatArrayOf(-0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f)

        fun parse(data: ByteArray): LightningFrame? {
            val json = jsonObject(parseJson(data)) ?: return null
            val features = jsonObjects(json["features"]) ?: return null
            val result = ArrayList<Pair<List<Vec2>, Double>>()
            for (feature in features) {
                val geometry = jsonObject(feature["geometry"]) ?: continue
                if (geometry["type"] != "MultiPoint") continue
                val coordinates = geometry["coordinates"] as? List<*> ?: continue
                val rate = jsonObject(feature["properties"])?.get("rate") as? Double ?: continue
                // Like a Swift `[[Double]]` cast: every position must be a list of numbers.
                val positions = coordinates.map { c -> (c as? List<*>)?.takeIf { l -> l.all { it is Double } } }
                if (positions.any { it == null }) continue
                val points = positions.mapNotNull { c ->
                    if (c!!.size >= 2) MapTransform.mercator(LatLng(c[1] as Double, c[0] as Double)) else null
                }
                if (points.isNotEmpty()) result.add(points to rate)
            }
            return LightningFrame(result)
        }
    }
}
