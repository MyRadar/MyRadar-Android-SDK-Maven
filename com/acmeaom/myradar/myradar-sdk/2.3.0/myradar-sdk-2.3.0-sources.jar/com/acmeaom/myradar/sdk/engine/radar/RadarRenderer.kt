package com.acmeaom.myradar.sdk.engine.radar

import com.acmeaom.myradar.sdk.engine.overlays.RadarClock
import android.util.Log
import com.acmeaom.myradar.sdk.BuildConfig
import com.acmeaom.myradar.sdk.RadarProduct
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.ScreenPoint
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import com.acmeaom.myradar.sdk.engine.gl.GPUMesh
import com.acmeaom.myradar.sdk.engine.gl.GPUTexture
import com.acmeaom.myradar.sdk.engine.gl.Program
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.gl.VertexLayout
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.engine.tiles.TileCover
import com.acmeaom.myradar.sdk.engine.tiles.TileID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import java.util.Date
import kotlin.math.roundToInt

// The animated radar layer. Follows the engine's `FWWeatherModule`: timing from `RadarTiming`,
// one animation frame per observation time (newest first), frames that play once all their
// visible tiles are loaded, and per-frame drawing with the engine's own fragment shaders
// (`WeatherShaders`):
//
// - Morphing frames (`MorphingLayer`): per-tile textures for the frame and the one before it.
// - Morphing advection frames (`MorphingAdvectionLayer`, US and Australia): tiles live in 2×2
//   mosaics keyed by their parent tile; a tile draws with the four mosaics around it for both
//   frames, so samples moved along the storm motion read the neighbouring tiles, plus the
//   motion vectors of its parent's mosaic.
// - Bitmap frames (SD radar): pre-colored tiles.

/** What the radar shows, from the map view's preferences. */
internal data class RadarSettings(
    val enabled: Boolean = true,
    val product: RadarProduct = RadarProduct.Radar,
    /** The opacity preference for the product (before the engine's HD multiplier). */
    val opacity: Float = 0.65f,
    val loopLengthMinutes: Int? = null,
    val scrubbing: Boolean = false,
    val scrubberValue: Float = 0f,
    val lightBasemap: Boolean = false,
    /** Predicted frames after the latest scan, where available. */
    val futureRadar: Boolean = false,
    /** Playback speed as a multiple of the default. */
    val speed: Float = 1f,
    /** Frames switch outright instead of blending (`RadarTransition.step`). */
    val stepFrames: Boolean = false,
)

/**
 * The radar layer. Main thread only; [dispose] when the map goes away. Times on the frame clock
 * ([RenderContext.now]) are seconds of `System.nanoTime`; dates are seconds since 1970.
 */
internal class RadarRenderer(private val network: EngineNetwork) : RadarClock {
    var onNeedsDisplay: (() -> Unit)? = null
    /** The visible frame's time, as `onWeatherAnimationTimestampUpdate` reports it. */
    var onFrameDate: ((Date?) -> Unit)? = null
    var onScrubber: ((Float) -> Unit)? = null
    var onPalette: ((String?) -> Unit)? = null
    /** Called when the frame times change (`onRadarTimingUpdated`), for layers that follow the loop. */
    var onTimingChanged: (() -> Unit)? = null

    /** The frame on screen, as the engine hands it to `WeatherFrameChangeListener`s. */
    override val currentFrameDate: Date?
        get() {
            if (!settings.enabled) return null
            val index = playback.currentFrame ?: return null
            if (index >= frames.size) return null
            return date(frames[index].date)
        }

    /** Whether the loop is holding still: paused on the newest frame, or under the scrubber. */
    override val isLoopPaused: Boolean get() = playback.isInAnimationPause || settings.scrubbing

    /** Seconds each frame is shown (`FWMapAnimation::_frameInterval`). */
    override val frameInterval: Double get() = playback.frameInterval

    var settings = RadarSettings()
        set(value) {
            val oldValue = field
            if (value == oldValue) return
            field = value
            if (value.scrubbing && value.scrubberValue != oldValue.scrubberValue ||
                value.scrubbing != oldValue.scrubbing) {
                scrubberDirty = true
            }
            if (value.speed != oldValue.speed) playback.setSpeedMultiplier(value.speed)
            onNeedsDisplay?.invoke()
        }

    /** This frame's lightning flash in Web Mercator (0...1), which also lights bitmap radar tiles. */
    var lightningFlash: Vec2? = null

    /** `future`: a predicted frame (`AdvectionLayer`), the newest scan moved along the storm motion. */
    enum class FrameKind { BITMAP, MORPH, ADVECTION, FUTURE }

    data class Frame(val date: Double, val kind: FrameKind)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val playback = RadarPlayback()
    private var timing: RadarTiming? = null
    private var frames: List<Frame> = emptyList()
    private var tileZoom = 3
    private var visibleTiles: List<TileID> = emptyList()
    /**
     * Tiles that left the visible set (a zoom level change, or a pan), still drawn beneath the new
     * ones until those are all ready for the frame on screen, then faded out (the engine fades
     * tiles it no longer wants instead of dropping them).
     */
    private var fallbackTiles: List<TileID> = emptyList()
    private var fallbackAlpha = 1f
    private var fallbackFading = false
    /** Each visible tile's fade-in, from when it was first ready (`FWTile::startFadeIn`). */
    private val tileAlpha = HashMap<TileID, Float>()
    /** When each tile was last drawn: tiles back in view within a moment don't fade in again. */
    private var tileLastDrawn = HashMap<TileID, Double>()
    private var lastFadeUpdate = 0.0
    /**
     * The last frame drawn with every visible tile, drawn beneath a frame that isn't fully loaded
     * (the loop always shows the newest frame, loaded or not) so the radar never drops out.
     */
    private var lastCompleteFrameDate: Double? = null

    /** The tiles predicted frames draw: the visible ones, or their zoom 7 cover when zoomed in further. */
    private var futureTiles: List<TileID> = emptyList()
    private var lastSeenAdvectionFailure = Double.NEGATIVE_INFINITY
    private var reportedPaletteName: String? = null
    private var lastReportedDate: Double? = null
    private var lastReportedScrubber = -1f
    private var scrubberDirty = false
    private var lastRequestAt = 0.0
    private var lastRequestKey = ""
    /** Whether the last request pass found nothing left to load. */
    private var everythingRequested = false
    /** URL strings are built for every tile of every frame; keep them. */
    private val formatCache = HashMap<Double, String>()
    private val urlCache = HashMap<URLKey, String>()

    private data class URLKey(val format: String, val tile: TileID)

    private val tileTextures = HashMap<String, RadarTexture>()
    private var mosaics = HashMap<MosaicKey, RadarMosaic>()
    private val palettes = HashMap<RadarPaletteMode, GPUTexture>()
    private val loader = RadarLoader(network, scope)

    // Made on first draw, with the GL context current.
    private var unitQuad: GPUMesh? = null
    private var emptyTexture: GPUTexture? = null

    init {
        loader.onLoaded = {
            // Uploaded at the start of a frame, a few at a time (see `applyLoaded`).
            loaded.addLast(it)
            onNeedsDisplay?.invoke()
        }
    }

    /** Stops loading. The renderer draws nothing useful afterwards. */
    fun dispose() {
        scope.cancel()
    }

    // MARK: Per frame

    /** Advances the loop and draws the visible frame. Returns true while the radar is animating. */
    /** When the earliest failed tile can be retried (wall clock seconds), if any failed. */
    private var nextRetryAt: Double? = null

    private fun noteFailure() {
        val at = wallClock() + RETRY_AFTER_SECONDS
        nextRetryAt = nextRetryAt?.let { minOf(it, at) } ?: at
    }

    /** Loaded tiles waiting to be uploaded to the GPU. */
    private val loaded = ArrayDeque<RadarLoader.Result>()

    /**
     * Uploads loaded tiles until the frame's upload budget is spent. Tiles finish loading in
     * bursts; uploading a burst at once (and the driver's work the first time each texture draws)
     * would hold up a frame, so it's spread over the next frames instead.
     */
    private fun applyLoaded() {
        if (loaded.isEmpty()) return
        val deadline = System.nanoTime() + UPLOAD_BUDGET_NANOS
        var count = 0
        while (loaded.isNotEmpty() && (count == 0 || System.nanoTime() < deadline)) {
            apply(loaded.removeFirst())
            count++
        }
        if (loaded.isNotEmpty()) onNeedsDisplay?.invoke()
    }

    fun draw(context: RenderContext): Boolean {
        if (!settings.enabled) return false
        applyLoaded()
        val transform = context.transform
        val now = context.now
        updateTiming(transform)
        val timing = timing ?: return false
        if (frames.isEmpty()) return false

        // Tiles at a consistent zoom, from the one under the center (`_tilesPreserveConsistentZoom`):
        // each 256-point tile is drawn between ~181 and ~362 points wide.
        tileZoom = transform.zoom.roundToInt().coerceIn(timing.minZoom, timing.maxZoom)
        val newVisible = TileCover.tiles(transform, tileZoom, 96)
        if (newVisible != visibleTiles) {
            // What leaves the set stays up as a fallback, along with any fallback still showing.
            val keep = newVisible.toHashSet()
            val leaving = visibleTiles.filter { it !in keep && (tileAlpha[it] ?: 0f) > 0 }
            if (leaving.isNotEmpty()) {
                fallbackTiles = (if (fallbackFading) emptyList() else fallbackTiles.filter { it !in keep }) + leaving
                fallbackAlpha = 1f
                fallbackFading = false
            }
            visibleTiles = newVisible
        }
        futureTiles = if (tileZoom > RadarTimingBuilder.FUTURE_RADAR_MAX_ZOOM) {
            TileCover.tiles(transform, RadarTimingBuilder.FUTURE_RADAR_MAX_ZOOM, 96)
        } else {
            visibleTiles
        }

        // The loop: the scrubber picks the frame when it's on, otherwise the animation steps.
        val frameCount = frames.size
        var changed = false
        if (settings.scrubbing) {
            if (scrubberDirty || playback.currentFrame == null) {
                changed = playback.scrub(settings.scrubberValue, frameCount)
                scrubberDirty = false
            }
        } else {
            changed = playback.tick(now, frameCount) { isAnimatable(it) }
            playback.currentFrame?.takeIf { it < frameCount }?.let { current ->
                val value = RadarPlayback.scrubberValue(frames[current].date, timing)
                if (value != lastReportedScrubber) {
                    lastReportedScrubber = value
                    onScrubber?.invoke(value.coerceIn(0f, 1f))
                }
            }
        }

        // Re-request when the view or the frames change, and while loads are outstanding; once
        // everything is in, a slow check catches retries.
        val first = visibleTiles.firstOrNull()
        val requestKey = "$tileZoom|${first?.let { "${it.x}/${it.y}" } ?: ""}|${visibleTiles.size}|" +
            "${frames.firstOrNull()?.date ?: 0}|${frames.firstOrNull()?.kind ?: ""}"
        // Once everything is requested, the only reason to look again is a failed tile coming due
        // for its retry; the full pass is costly (every frame's tiles), so don't run it otherwise.
        val retryDue = nextRetryAt?.let { wallClock() >= it } ?: false
        if (requestKey != lastRequestKey || (!everythingRequested && now - lastRequestAt > 0.3) || retryDue) {
            nextRetryAt = null
            lastRequestKey = requestKey
            lastRequestAt = now
            requestTiles()
        }

        val current = playback.currentFrame ?: return true
        if (current >= frameCount) return true
        val frame = frames[current]
        val loopTime = playback.loopTime(now, frame.date, timing, settings.scrubbing, settings.scrubberValue)
        reportFrameDate(frame, loopTime, changed, timing)
        // Stepping shows each frame as it is: fully morphed into, or advected exactly to its time.
        val lerp = if (settings.stepFrames) {
            1f
        } else {
            loopTime?.let { RadarPlayback.lerpFactor(it, frame.date, timing.nominalFrameTimeInterval) } ?: 1f
        }
        val (fading, complete) = updateFades(now, frame, timing)
        // Fallback tiles beneath, then the last complete frame where this one isn't loaded, then
        // the current tiles over them.
        if (fallbackTiles.isNotEmpty() &&
            (frame.kind != FrameKind.FUTURE || tileZoom <= RadarTimingBuilder.FUTURE_RADAR_MAX_ZOOM)) {
            val alpha = fallbackAlpha
            drawFrame(context, frame, timing, lerp, fallbackTiles) { alpha }
        }
        val completeDate = lastCompleteFrameDate
        if (complete) {
            lastCompleteFrameDate = frame.date
        } else if (completeDate != null && completeDate != frame.date) {
            val previous = frames.firstOrNull { it.date == completeDate }
            if (previous != null) {
                val missing = tiles(frame).filter { !tileReady(it, frame, timing) }
                drawFrame(context, previous, timing, 1f, missing) { tile ->
                    if (previous.kind == FrameKind.FUTURE && tile.z != tileZoom) 1f else tileAlpha[tile] ?: 1f
                }
            }
        }
        drawFrame(context, frame, timing, lerp, tiles(frame)) { tile ->
            if (frame.kind == FrameKind.FUTURE && tile.z != tileZoom) 1f else tileAlpha[tile] ?: 0f
        }
        return !settings.scrubbing || fading
    }

    /**
     * Advances tile fades. Returns whether anything is fading, and whether every tile of the
     * frame is ready.
     */
    private fun updateFades(now: Double, frame: Frame, timing: RadarTiming): Pair<Boolean, Boolean> {
        val step = (if (lastFadeUpdate > 0) minOf(now - lastFadeUpdate, 0.25) else 0.0).toFloat() / TILE_FADE_DURATION
        lastFadeUpdate = now
        var fading = false
        var allReady = true
        for (tile in visibleTiles) {
            if (!tileReady(tile, frame, timing)) {
                allReady = false
                continue
            }
            val alpha = tileAlpha[tile]
            val last = tileLastDrawn[tile]
            if (alpha != null) {
                if (alpha < 1) {
                    tileAlpha[tile] = minOf(1f, alpha + step)
                    fading = true
                }
            } else if (last != null && now - last < 2) {
                tileAlpha[tile] = 1f // back in view straight away, like a tile from the engine's cache
            } else {
                tileAlpha[tile] = step // newly ready: fade in
                fading = true
            }
            tileLastDrawn[tile] = now
        }
        // Forget fades of tiles out of view; remember when they were last up.
        val visible = visibleTiles.toHashSet()
        tileAlpha.keys.retainAll(visible)
        if (tileLastDrawn.size > 512) tileLastDrawn = HashMap(tileLastDrawn.filterValues { now - it < 2 })
        // The fallback fades once everything it stands in for is ready.
        if (fallbackTiles.isNotEmpty()) {
            if (allReady) fallbackFading = true
            if (fallbackFading) {
                fallbackAlpha = maxOf(0f, fallbackAlpha - step)
                if (fallbackAlpha == 0f) {
                    fallbackTiles = emptyList()
                    fallbackFading = false
                }
            }
            fading = true
        }
        val complete = allReady && tiles(frame).all { tileReady(it, frame, timing) }
        return fading to complete
    }

    // MARK: Timing and frames

    private fun updateTiming(transform: MapTransform) {
        val region = viewRegion(transform)
        val paletteMode =
            if (settings.lightBasemap) RadarPaletteMode.CLASSIFIED_LIGHT else RadarPaletteMode.CLASSIFIED_DARK
        val candidate = RadarTimingBuilder.timing(settings.product, region, paletteMode, settings.loopLengthMinutes,
            settings.futureRadar)
        val now = wallClock()
        val advectionAllowed = now - lastSeenAdvectionFailure > ADVECTION_FAILURE_BACKOFF
        val frameKinds = kinds(candidate, advectionAllowed)
        // Predicted frames need the motion vectors; without them the loop ends at the latest scan
        // (the engine's server-rendered fallback isn't used).
        if (frameKinds != FrameKind.ADVECTION) {
            candidate.predictionFrameCount = 0
            candidate.animationLoopEndTime = candidate.newestObservationFrame
        }
        // The last frame is an observed one, so its kind is the observed frames' kind.
        if (candidate == timing && frames.lastOrNull()?.kind == frameKinds) return
        val keepPlayhead = timing?.product == candidate.product && timing?.region == candidate.region
        timing = candidate
        formatCache.clear()
        urlCache.clear()
        everythingRequested = false
        frames = candidate.predictionDates.map { Frame(it, FrameKind.FUTURE) } +
            candidate.frameDates.map { Frame(it, frameKinds) }
        if (BuildConfig.DEBUG) {
            Log.d(LOG_TAG, "radar timing: ${candidate.product} region ${candidate.region}, " +
                "${candidate.observationFrameCount} frames ($frameKinds) + ${candidate.predictionFrameCount} " +
                "predicted, newest ${RadarTimingBuilder.iowaString(candidate.newestObservationFrame)}")
        }
        if (!keepPlayhead) playback.reset()
        playback.framesReplaced(System.nanoTime() / 1e9)
        onTimingChanged?.invoke()
        if (reportedPaletteName != candidate.paletteName) {
            reportedPaletteName = candidate.paletteName
            onPalette?.invoke(paletteJSON(candidate.paletteName))
        }
    }

    /**
     * The layer class for frames: morphing advection where the motion vectors are available
     * (the future radar region, with no recent failure), plain morphing otherwise.
     */
    private fun kinds(timing: RadarTiming, advectionAllowed: Boolean): FrameKind = when (timing.layerClass) {
        RadarLayerClass.BITMAP -> FrameKind.BITMAP
        RadarLayerClass.MORPH -> FrameKind.MORPH
        RadarLayerClass.MORPH_ADVECTION_WHERE_AVAILABLE ->
            if (timing.region == RadarRegion.FUTURE_RADAR && advectionAllowed) FrameKind.ADVECTION else FrameKind.MORPH
    }

    private fun viewRegion(transform: MapTransform): RadarRegion {
        val w = transform.width
        val h = transform.height
        val projection = transform.projectionMatrix
        val points = listOf(ScreenPoint(0.0, 0.0), ScreenPoint(w, 0.0), ScreenPoint(0.0, h), ScreenPoint(w, h),
            ScreenPoint(w / 2, h / 2))
        val coords = points.mapNotNull { transform.mercatorAt(it, projection) }.map { MapTransform.coordinate(it) }
        if (coords.isEmpty()) return RadarRegion.NOT_JAPAN
        var west = coords[0].longitude
        var east = west
        val center = transform.coordinate.longitude
        for (c in coords) {
            var lon = c.longitude
            while (lon - center > 180) lon -= 360
            while (center - lon > 180) lon += 360
            west = minOf(west, lon)
            east = maxOf(east, lon)
        }
        return RadarTimingBuilder.region(coords.maxOf { it.latitude }, west, coords.minOf { it.latitude }, east)
    }

    private fun reportFrameDate(frame: Frame, loopTime: Double?, changed: Boolean, timing: RadarTiming) {
        // While scrubbing morphing radar the engine reports the scrubbed time itself.
        val date = if (settings.scrubbing && timing.product == RadarProduct.Radar) loopTime else frame.date
        if (date == lastReportedDate) return
        lastReportedDate = date
        onFrameDate?.invoke(date?.let { date(it) })
    }

    // MARK: URLs

    /** A frame's tile URL template: `_baseUrl = formatTemplateUrl(baseUrl, date) + "/^p." + extension`. */
    private fun frameURLFormat(date: Double, timing: RadarTiming): String = formatCache.getOrPut(date) {
        val ext = if (timing.layerClass == RadarLayerClass.BITMAP) "png" else "webp"
        RadarTimingBuilder.format(timing.animationURLFormat, date) + "/^p." + ext
    }

    private fun flowURLFormat(timing: RadarTiming): String =
        RadarTimingBuilder.format(RadarTimingBuilder.advectionURLFormat, timing.advectionFrameTimestamp) + "/^p.png"

    private fun url(format: String, tile: TileID): String {
        val key = URLKey(format, tile.canonical)
        urlCache[key]?.let { return it }
        val url = RadarTimingBuilder.format(format, tile.canonical)
        if (urlCache.size > 20_000) urlCache.clear()
        urlCache[key] = url
        return url
    }

    // MARK: Readiness

    /** A frame plays once every visible tile it draws is loaded (`TileLayerMetaGraphic` `_isAnimatable`). */
    private fun isAnimatable(index: Int): Boolean {
        val timing = timing ?: return false
        if (index >= frames.size || visibleTiles.isEmpty()) return false
        val frame = frames[index]
        return tiles(frame).all { tileReady(it, frame, timing) }
    }

    private fun tiles(frame: Frame): List<TileID> = if (frame.kind == FrameKind.FUTURE) futureTiles else visibleTiles

    private fun tileReady(tile: TileID, frame: Frame, timing: RadarTiming): Boolean {
        val current = frameURLFormat(frame.date, timing)
        return when (frame.kind) {
            FrameKind.BITMAP -> tileTextures[url(current, tile)]?.isReady == true
            FrameKind.MORPH -> {
                val previous = frameURLFormat(frame.date - timing.nominalFrameTimeInterval, timing)
                tileTextures[url(current, tile)]?.isReady == true && tileTextures[url(previous, tile)]?.isReady == true
            }
            FrameKind.ADVECTION -> {
                val previous = frameURLFormat(frame.date - timing.nominalFrameTimeInterval, timing)
                for (neighbor in neighborhood(tile)) {
                    for (format in arrayOf(current, previous)) {
                        if (mosaicChildReady(format, neighbor) != true) return false
                    }
                }
                mosaicChildReady(flowURLFormat(timing), tile) == true
            }
            FrameKind.FUTURE -> {
                val base = frameURLFormat(timing.newestObservationFrame, timing)
                for (neighbor in neighborhood(tile)) if (mosaicChildReady(base, neighbor) != true) return false
                mosaicChildReady(flowURLFormat(timing), tile) == true
            }
        }
    }

    private fun mosaicChildReady(format: String, tile: TileID): Boolean? =
        mosaics[MosaicKey(format, tile.canonical.parent!!)]?.childReady(tile.canonical)

    // MARK: Loading

    /** Asks for the tiles of every frame, the visible frame and the next ones first. */
    private fun requestTiles() {
        val timing = timing ?: return
        val wanted = ArrayList<RadarLoader.Request>()
        val count = frames.size
        val start = playback.currentFrame ?: 0
        // The 3×3 neighbourhoods of a frame's tiles overlap; work out the distinct neighbours once
        // per tile list (each with the first tile that needs it, which sets its priority).
        val neighbours = HashMap<List<TileID>, List<Pair<TileID, Int>>>()
        fun neighboursOf(tiles: List<TileID>) = neighbours.getOrPut(tiles) {
            val seenTiles = HashSet<TileID>()
            val result = ArrayList<Pair<TileID, Int>>()
            for ((k, tile) in tiles.withIndex()) for (n in neighborhood(tile)) if (seenTiles.add(n)) result.add(n to k)
            result
        }
        for (order in 0 until count) {
            // Frames play from oldest (high index) to newest (index 0), so the next to play is index - 1.
            val index = ((start - order) % count + count) % count
            val frame = frames[index]
            val current = frameURLFormat(frame.date, timing)
            val previous = frameURLFormat(frame.date - timing.nominalFrameTimeInterval, timing)
            val frameTiles = tiles(frame)
            if (frame.kind == FrameKind.ADVECTION || frame.kind == FrameKind.FUTURE) {
                val formats = if (frame.kind == FrameKind.ADVECTION) listOf(current to 0, previous to 5_000)
                else listOf(frameURLFormat(timing.newestObservationFrame, timing) to 0)
                for ((neighbor, k) in neighboursOf(frameTiles)) {
                    for ((format, offset) in formats) {
                        val target = RadarLoader.Target.Mosaic(MosaicKey(format, neighbor.parent!!), neighbor)
                        wanted.add(RadarLoader.Request(url(format, neighbor), target, order * 10_000 + k + offset))
                    }
                }
            }
            for ((k, tile) in frameTiles.withIndex()) {
                val priority = order * 10_000 + k
                when (frame.kind) {
                    FrameKind.BITMAP ->
                        wanted.add(RadarLoader.Request(url(current, tile), RadarLoader.Target.Tile, priority,
                            colors = true))
                    FrameKind.MORPH -> {
                        wanted.add(RadarLoader.Request(url(current, tile), RadarLoader.Target.Tile, priority))
                        wanted.add(RadarLoader.Request(url(previous, tile), RadarLoader.Target.Tile, priority + 5_000))
                    }
                    FrameKind.ADVECTION -> {
                        val flow = flowURLFormat(timing)
                        val target = RadarLoader.Target.Flow(MosaicKey(flow, tile.parent!!), tile)
                        wanted.add(RadarLoader.Request(url(flow, tile), target, priority + 2_500))
                    }
                    FrameKind.FUTURE -> {
                        // The newest scan (above) and the motion vectors, at the predicted frames' zoom.
                        val flow = flowURLFormat(timing)
                        val target = RadarLoader.Target.Flow(MosaicKey(flow, tile.parent!!), tile)
                        wanted.add(RadarLoader.Request(url(flow, tile), target, priority + 2_500))
                    }
                }
            }
        }
        // Drop queued loads that are no longer wanted, then skip what's loaded, loading or failed
        // recently (retried after 30 s, like the engine's tiles).
        val wantedURLs = wanted.mapTo(HashSet()) { it.url }
        for (dropped in loader.retainOnly(wantedURLs)) {
            when (val target = dropped.target) {
                RadarLoader.Target.Tile ->
                    if (tileTextures[dropped.url]?.isLoading == true) tileTextures.remove(dropped.url)
                is RadarLoader.Target.Mosaic -> mosaics[target.key]?.forgetIfLoading(target.tile)
                is RadarLoader.Target.Flow -> mosaics[target.key]?.forgetIfLoading(target.tile)
            }
        }
        val retryBefore = wallClock() - RETRY_AFTER_SECONDS
        val seen = HashSet<String>()
        val needed = wanted.filter { request ->
            if (!seen.add(request.url)) return@filter false
            when (val target = request.target) {
                RadarLoader.Target.Tile -> {
                    val texture = tileTextures[request.url] ?: return@filter true
                    val state = texture.state
                    state is RadarTexture.State.Failed && state.at < retryBefore
                }
                is RadarLoader.Target.Mosaic -> mosaics[target.key]?.needsLoad(target.tile, retryBefore) ?: true
                is RadarLoader.Target.Flow -> mosaics[target.key]?.needsLoad(target.tile, retryBefore) ?: true
            }
        }
        for (request in needed) {
            when (val target = request.target) {
                RadarLoader.Target.Tile -> tileTextures[request.url] = RadarTexture()
                is RadarLoader.Target.Mosaic -> markMosaicLoading(target.key, target.tile, nearest = false)
                is RadarLoader.Target.Flow -> markMosaicLoading(target.key, target.tile, nearest = true)
            }
        }
        everythingRequested = needed.isEmpty()
        loader.enqueue(needed)
        pruneTextures(timing)
    }

    /** Motion vectors are read with nearest sampling: interpolating split 16-bit values breaks them. */
    private fun markMosaicLoading(key: MosaicKey, tile: TileID, nearest: Boolean) {
        val mosaic = mosaics.getOrPut(key) { RadarMosaic(nearest) }
        mosaic.markLoading(tile)
    }

    private fun apply(result: RadarLoader.Result) {
        when (val target = result.target) {
            RadarLoader.Target.Tile -> {
                val texture = tileTextures[result.url] ?: return
                texture.state = when (val content = result.content) {
                    is RadarLoader.Content.Pixels ->
                        RadarTexture.State.Ready(GPUTexture.rgba(content.pixels, content.width, content.height))
                    RadarLoader.Content.Empty -> RadarTexture.State.Ready(null)
                    RadarLoader.Content.Failed -> {
                        noteFailure()
                        RadarTexture.State.Failed(wallClock())
                    }
                }
            }
            is RadarLoader.Target.Mosaic -> applyMosaic(target.key, target.tile, result, isFlow = false)
            is RadarLoader.Target.Flow -> applyMosaic(target.key, target.tile, result, isFlow = true)
        }
        onNeedsDisplay?.invoke()
    }

    private fun applyMosaic(key: MosaicKey, tile: TileID, result: RadarLoader.Result, isFlow: Boolean) {
        val mosaic = mosaics[key] ?: return
        when (val content = result.content) {
            is RadarLoader.Content.Pixels ->
                if (content.width == 256 && content.height == 256) mosaic.upload(tile, content.pixels)
                else mosaic.markEmpty(tile)
            RadarLoader.Content.Empty -> mosaic.markEmpty(tile)
            RadarLoader.Content.Failed -> {
                mosaic.markFailed(tile)
                noteFailure()
                if (isFlow) {
                    // `MorphingAdvectionTile::ensureLoadTextures`: fall back to morphing for a while.
                    lastSeenAdvectionFailure = wallClock()
                    if (BuildConfig.DEBUG) {
                        Log.d(LOG_TAG, "motion vectors unavailable (${result.url}); " +
                            "morphing without them for 30 minutes")
                    }
                }
            }
        }
    }

    /** Drops textures for frames and zooms that are no longer in the loop. */
    private fun pruneTextures(timing: RadarTiming) {
        if (tileTextures.size + mosaics.size <= 400) return
        val times = HashSet<String>()
        for (frame in frames) {
            times.add(RadarTimingBuilder.iowaString(frame.date))
            times.add(RadarTimingBuilder.iowaString(frame.date - timing.nominalFrameTimeInterval))
        }
        times.add(RadarTimingBuilder.iowaString(timing.advectionFrameTimestamp))
        fun current(url: String) = times.any { url.contains("/$it/") }
        // Keep the zooms on screen: the visible tiles, predicted frames' and the fallback's.
        val zooms = (listOf(tileZoom) + futureTiles.map { it.z } + fallbackTiles.map { it.z }).toHashSet()
        tileTextures.entries.removeAll { (url, texture) ->
            !(texture.isLoading || (current(url) && zooms.any { url.contains("/$it/") }))
        }
        mosaics.entries.removeAll { (key, _) -> !(current(key.format) && (key.parent.z + 1) in zooms) }
    }

    // MARK: Drawing

    private fun paletteTexture(): GPUTexture? {
        val mode = if (settings.lightBasemap) RadarPaletteMode.CLASSIFIED_LIGHT else RadarPaletteMode.CLASSIFIED_DARK
        palettes[mode]?.let { return it }
        // `MorphingLayerMetaGraphic::draw`: morphing frames use the morphing palettes for any product.
        val json = when (mode) {
            RadarPaletteMode.CLASSIFIED_LIGHT -> RadarPaletteData.morphingLight
            else -> RadarPaletteData.morphingDark
        }
        val palette = RadarPalette.parse(json) ?: return null
        val texture = GPUTexture.rgba(palette.pixels, palette.width, palette.rows) ?: return null
        palettes[mode] = texture
        return texture
    }

    private fun drawFrame(context: RenderContext, frame: Frame, timing: RadarTiming, lerp: Float, tiles: List<TileID>,
                          alpha: (TileID) -> Float) {
        val unitQuad = unitQuad ?: GPUMesh.create(QUAD_VERTICES, QUAD_INDICES, QUAD_LAYOUT)?.also { unitQuad = it }
            ?: return
        val emptyTexture = emptyTexture ?: GPUTexture.rgba(ByteArray(4), 1, 1)?.also { emptyTexture = it } ?: return
        val transform = context.transform
        val projection = transform.projectionMatrix
        var opacity = settings.opacity
        if (timing.product != RadarProduct.StandardDefinitionRadar) opacity *= HD_OPACITY_MULTIPLIER
        // `WeatherAnimationLayerMetaGraphic::draw`'s fragment mode.
        val fragmentMode = when (timing.blendMode) {
            RadarBlendMode.ALPHA -> 0f
            RadarBlendMode.ADDITIVE_OVER_DARK_BASEMAP -> if (settings.lightBasemap) 0f else 1f
            RadarBlendMode.ANTI_ALIASED_NEAREST_NEIGHBOR -> 2f
        }
        val current = frameURLFormat(frame.date, timing)
        val previous = frameURLFormat(frame.date - timing.nominalFrameTimeInterval, timing)

        val fragment = when (frame.kind) {
            FrameKind.BITMAP -> "radar_tile_fs"
            FrameKind.MORPH -> "radar_morph_fs"
            FrameKind.ADVECTION -> "radar_advection_fs"
            FrameKind.FUTURE -> "radar_future_fs"
        }
        val program = context.use("radar_vs", fragment) ?: return
        when (frame.kind) {
            FrameKind.BITMAP -> {
                program.setVec4Array("fs_per_draw_uniforms_tile", floatArrayOf(fragmentMode, 0f, 0f, 0f))
                // `fs_per_frame_uniforms_tile`: atmosphere color, lightning (Mercator xy, radius,
                // height), camera direction. `LightningDataDummyProgram::lightningDrawUbo`.
                val lightning = FloatArray(12)
                lightningFlash?.let { flash ->
                    val m = meters(flash)
                    lightning[4] = m.first
                    lightning[5] = m.second
                    lightning[6] = 2e9f
                    lightning[7] = 10_000f
                }
                program.setVec4Array("fs_per_frame_uniforms_tile", lightning)
            }
            FrameKind.MORPH -> {
                val palette = paletteTexture() ?: return
                program.setVec4Array("fs_per_draw_uniforms_tile", floatArrayOf(fragmentMode, 0f, 0f, 0f))
                program.setVec4Array("morphing_fs_per_frame_uniforms", floatArrayOf(lerp, 0f, 0f, 0f))
                palette.bind(program, 0, "u_palette")
            }
            FrameKind.ADVECTION -> {
                val palette = paletteTexture() ?: return
                program.setVec4Array("advection_fs_per_frame_uniforms", floatArrayOf(lerp, 0f, 0f, 0f))
                palette.bind(program, 0, "u_palette")
            }
            FrameKind.FUTURE -> {
                val palette = paletteTexture() ?: return
                // `AdvectionMetaGraphic::lerpFactor`: "overlerping" by the frame's distance past the scan,
                // so the Nth predicted frame moves the scan from N-1 to N steps of motion.
                val steps = ((frame.date - timing.newestObservationFrame) / 300 - 1).toFloat()
                program.setVec4Array("advection_fs_per_frame_uniforms", floatArrayOf(lerp + steps, 0f, 0f, 0f))
                palette.bind(program, 0, "u_palette")
            }
        }

        val worldMeters = METERS_PER_WORLD.toFloat()
        val base = frameURLFormat(timing.newestObservationFrame, timing)
        for (tile in tiles) {
            val tileAlpha = alpha(tile)
            if (tileAlpha <= 0) continue
            val n = (1 shl tile.z).toDouble()
            val corner = meters(Vec2(tile.x / n + tile.wrap, tile.y / n))
            var texTransform = floatArrayOf(1f, 1f, 0f, 0f)
            when (frame.kind) {
                FrameKind.BITMAP -> {
                    val state = tileTextures[url(current, tile)]?.state as? RadarTexture.State.Ready ?: continue
                    val texture = state.texture ?: continue
                    texture.bind(program, 0, "u_texture")
                }
                FrameKind.MORPH -> {
                    val a = tileTextures[url(current, tile)]?.state as? RadarTexture.State.Ready ?: continue
                    val b = tileTextures[url(previous, tile)]?.state as? RadarTexture.State.Ready ?: continue
                    (a.texture ?: emptyTexture).bind(program, 1, "u_texture_a")
                    (b.texture ?: emptyTexture).bind(program, 2, "u_texture_b")
                }
                FrameKind.ADVECTION -> {
                    if (!tileReady(tile, frame, timing)) continue
                    texTransform = bindAdvectionTextures(program, tile, current, previous, timing, emptyTexture)
                }
                FrameKind.FUTURE -> {
                    if (!tileReady(tile, frame, timing)) continue
                    texTransform = bindAdvectionTextures(program, tile, base, null, timing, emptyTexture)
                }
            }
            program.setMat4("u_matrix", transform.tileMatrix(tile.z, tile.x, tile.y, tile.wrap, 1.0, projection))
            program.setVec4("u_tex_transform", texTransform[0], texTransform[1], texTransform[2], texTransform[3])
            program.setVec4("u_tile_meters", corner.first, corner.second, worldMeters / n.toFloat(), 0f)
            program.setFloat("u_opacity", opacity * tileAlpha)
            unitQuad.draw()
        }
    }

    /**
     * `MorphingAdvectionTile::ensureLoadTextures` and `MorphingAdvectionProgram::setupTextureBindings`.
     * Returns the tile's texture transform.
     */
    private fun bindAdvectionTextures(program: Program, tile: TileID, current: String, previous: String?,
                                      timing: RadarTiming, empty: GPUTexture): FloatArray {
        val neighbors = neighborhood(tile)
        val formats = if (previous != null) listOf(current, previous) else listOf(current)
        for ((kind, format) in formats.withIndex()) {
            // The 3×3 neighbourhood spans at most 2×2 parents; each parent's mosaic goes in the
            // slot of its parity, which together form a wrapping 4×4 tile area. Units 1-4 are
            // `u_texture_a_0...3`, 5-8 `u_texture_b_0...3`.
            val name = if (kind == 0) "u_texture_a_" else "u_texture_b_"
            for (corner in CORNERS) {
                val parent = neighbors[corner].parent!!
                val slot = 2 * (parent.y and 1) + (parent.x and 1)
                (mosaics[MosaicKey(format, parent)]?.texture ?: empty).bind(program, 1 + kind * 4 + slot, "$name$slot")
            }
        }
        val flow = mosaics[MosaicKey(flowURLFormat(timing), tile.canonical.parent!!)]
        (flow?.texture ?: empty).bind(program, 9, "u_texture_advection_0")

        // The tile's place in the 4×4 area, and how far samples may move: one tile either way.
        val xIndex = (tile.canonical.x and 3).toFloat()
        val yIndex = (tile.canonical.y and 3).toFloat()
        val scale = 1f / 4
        val u = xIndex / 4
        val v = yIndex / 4
        // 2 × (2 × 256): motion vectors are in pixels of the tile, the shader works in the 4×4 area.
        program.setVec4Array("advection_fs_per_draw_uniforms", floatArrayOf(
            u - scale, v - scale, u + scale + scale, v + scale + scale,
            1f / 1024, 1f / 1024, 0f, 0f,
        ))
        return floatArrayOf(scale, scale, xIndex, yIndex)
    }

    companion object {
        /** Failed tiles are retried after this long, like the engine's tiles. */
        private const val RETRY_AFTER_SECONDS = 30.0

        /** CPU time per frame for uploading loaded radar tiles. */
        private const val UPLOAD_BUDGET_NANOS = 2_000_000L
        private const val LOG_TAG = "MyRadarSDK"
        /** `FWTile::_tileFadeDuration`. */
        private const val TILE_FADE_DURATION = 0.5f
        /** `kHDRadarOpacityMultiplier`. */
        private const val HD_OPACITY_MULTIPLIER = 1.5f
        private const val ADVECTION_FAILURE_BACKOFF = 30 * 60.0
        /** Web Mercator meters across the world (`2 * FWWebMercatorBound`). */
        private const val METERS_PER_WORLD = 2 * 20_037_508.342789244
        /** The corners of a 3×3 neighbourhood, whose parents cover it. */
        private val CORNERS = intArrayOf(0, 2, 6, 8)

        private val QUAD_VERTICES = floatArrayOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f)
        private val QUAD_INDICES = intArrayOf(0, 1, 2, 0, 2, 3)
        private val QUAD_LAYOUT = VertexLayout(2)

        private fun wallClock(): Double = System.currentTimeMillis() / 1000.0

        private fun date(seconds: Double): Date = Date(Math.round(seconds * 1000))

        /** Mercator (0...1, y down) to the engine's Mercator meters (y up). */
        private fun meters(m: Vec2): Pair<Float, Float> =
            ((m.x - 0.5) * METERS_PER_WORLD).toFloat() to ((0.5 - m.y) * METERS_PER_WORLD).toFloat()

        /**
         * The tile and its eight neighbours (`FWTileCoordinate::neighborhood`), west to east, north to
         * south. Longitudes wrap; rows past the poles repeat the edge row.
         */
        fun neighborhood(tile: TileID): List<TileID> {
            val n = 1 shl tile.z
            val result = ArrayList<TileID>(9)
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val y = (tile.y + dy).coerceIn(0, n - 1)
                    val x = ((tile.x + dx) % n + n) % n
                    result.add(TileID(tile.z, x, y))
                }
            }
            return result
        }

        /** The JSON of a palette the engine names, as reported to the map view's listener. */
        fun paletteJSON(name: String): String? = when (name) {
            "palette_morphing_dark.json" -> RadarPaletteData.morphingDark
            "palette_morphing_light.json" -> RadarPaletteData.morphingLight
            "palette_morphing_no_classification.json" -> RadarPaletteData.morphingUnclassified
            "palette_unsmoothed_dark.json" -> RadarPaletteData.unsmoothedDark
            "palette_unsmoothed_light.json" -> RadarPaletteData.unsmoothedLight
            "palette_unsmoothed_unclassified.json" -> RadarPaletteData.unsmoothedUnclassified
            "palette_classic_radar_n0q.json" -> RadarPaletteData.classicN0Q
            else -> null
        }
    }
}
