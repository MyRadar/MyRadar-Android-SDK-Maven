// A parsed Mapbox GL style: its sources and layers, limited to what the base map styles use.

package com.acmeaom.myradar.sdk.engine.basemap

import java.net.URI
import java.net.URISyntaxException

internal enum class StyleSourceKind {
    VECTOR,
    RASTER,
    GEOJSON,
}

internal data class StyleSource(
    val id: String,
    val kind: StyleSourceKind,
    /** A TileJSON URL to resolve, or null when the tiles are given inline. */
    val tileJsonUrl: String?,
    val tiles: List<String>,
    val minZoom: Int,
    val maxZoom: Int,
    /** Raster tiles' size in style pixels (512 unless the source says otherwise). */
    val tileSize: Double,
    /** Inline GeoJSON data (as parsed by [parseJson]), for GeoJSON sources. */
    val geojson: Any?,
)

internal enum class StyleLayerKind(val rawValue: String) {
    BACKGROUND("background"),
    FILL("fill"),
    LINE("line"),
    SYMBOL("symbol"),
    RASTER("raster"),
    ;

    companion object {
        fun fromRawValue(rawValue: String): StyleLayerKind? = entries.firstOrNull { it.rawValue == rawValue }
    }
}

internal class StyleLayer private constructor(
    val id: String,
    val kind: StyleLayerKind,
    json: Map<String, Any?>,
) {
    val source: String? = json["source"] as? String
    val sourceLayer: String? = json["source-layer"] as? String
    val minZoom: Double = json["minzoom"]?.let(StyleConvert::number) ?: 0.0
    val maxZoom: Double = json["maxzoom"]?.let(StyleConvert::number) ?: 24.0
    val filter: StyleFilter = StyleFilter.fromJson(json["filter"])

    /** The raw layout and paint objects, for the symbol renderer. */
    val layout: Map<String, Any?> = jsonObject(json["layout"]) ?: emptyMap()
    val paint: Map<String, Any?> = jsonObject(json["paint"]) ?: emptyMap()

    val visible: Boolean = (layout["visibility"] as? String) != "none"

    // background / fill
    val backgroundColor: StyleProperty<RGBA>? = StyleProperty.color(paint["background-color"])
    val backgroundOpacity: StyleProperty<Double>? = StyleProperty.number(paint["background-opacity"])
    val fillColor: StyleProperty<RGBA>? = StyleProperty.color(paint["fill-color"])
    val fillOpacity: StyleProperty<Double>? = StyleProperty.number(paint["fill-opacity"])
    val fillOutlineColor: StyleProperty<RGBA>? = StyleProperty.color(paint["fill-outline-color"])
    val fillAntialias: Boolean = paint["fill-antialias"]?.let(StyleConvert::bool) ?: true

    // line
    val lineColor: StyleProperty<RGBA>? = StyleProperty.color(paint["line-color"])
    val lineWidth: StyleProperty<Double>? = StyleProperty.number(paint["line-width"])
    val lineOpacity: StyleProperty<Double>? = StyleProperty.number(paint["line-opacity"])
    val lineDashArray: StyleProperty<List<Double>>? =
        StyleProperty.fromJson(paint["line-dasharray"], StyleConvert::numbers)
    val lineJoin: StyleProperty<String>? = StyleProperty.fromJson(layout["line-join"], StyleConvert::string)
    val lineCap: StyleProperty<String>? = StyleProperty.fromJson(layout["line-cap"], StyleConvert::string)
    val lineMiterLimit: Double = layout["line-miter-limit"]?.let(StyleConvert::number) ?: 2.0

    // raster
    val rasterOpacity: StyleProperty<Double>? = StyleProperty.number(paint["raster-opacity"])

    /** Whether the layer draws at a style zoom. */
    fun isVisible(atStyleZoom: Double): Boolean = visible && atStyleZoom >= minZoom && atStyleZoom < maxZoom

    companion object {
        /** Parses a style layer; null without an id or with a type that isn't drawn. */
        fun fromJson(json: Map<String, Any?>): StyleLayer? {
            val id = json["id"] as? String ?: return null
            val type = json["type"] as? String ?: return null
            val kind = StyleLayerKind.fromRawValue(type) ?: return null
            return StyleLayer(id, kind, json)
        }
    }
}

internal class MapStyleSheet private constructor(
    val name: String,
    sources: Map<String, StyleSource>,
    val layers: List<StyleLayer>,
    val glyphsUrl: String?,
    val spriteUrl: String?,
) {
    var sources: Map<String, StyleSource> = sources
        private set

    /** Applies a TileJSON document to a source. */
    fun resolve(sourceId: String, tileJson: ByteArray) {
        var source = sources[sourceId] ?: return
        val json = jsonObject(parseJson(tileJson)) ?: return
        jsonStrings(json["tiles"])?.let { source = source.copy(tiles = it) }
        json["minzoom"]?.let(StyleConvert::number)?.let { source = source.copy(minZoom = it.toInt()) }
        json["maxzoom"]?.let(StyleConvert::number)?.let { source = source.copy(maxZoom = it.toInt()) }
        json["tileSize"]?.let(StyleConvert::number)?.let { source = source.copy(tileSize = it) }
        sources = LinkedHashMap(sources).apply { put(sourceId, source) }
    }

    /** The source layers each vector source needs, so tiles decode only what's drawn. */
    fun sourceLayers(sourceId: String): Set<String> =
        layers.filter { it.source == sourceId && it.kind != StyleLayerKind.RASTER }.mapNotNull { it.sourceLayer }.toSet()

    companion object {
        /** Parses a style document; null when it isn't JSON or has no valid `layers` array. */
        fun parse(data: ByteArray): MapStyleSheet? {
            val json = jsonObject(parseJson(data)) ?: return null
            val rawLayers = jsonObjects(json["layers"]) ?: return null
            val sources = LinkedHashMap<String, StyleSource>()
            for ((id, value) in jsonObject(json["sources"]) ?: emptyMap()) {
                val source = jsonObject(value) ?: continue
                val kind = when (source["type"] as? String) {
                    "vector" -> StyleSourceKind.VECTOR
                    "raster" -> StyleSourceKind.RASTER
                    "geojson" -> StyleSourceKind.GEOJSON
                    else -> continue
                }
                sources[id] = StyleSource(
                    id = id,
                    kind = kind,
                    tileJsonUrl = (source["url"] as? String)?.takeIf(::isValidUrl),
                    tiles = jsonStrings(source["tiles"]) ?: emptyList(),
                    minZoom = source["minzoom"]?.let(StyleConvert::number)?.toInt() ?: 0,
                    maxZoom = source["maxzoom"]?.let(StyleConvert::number)?.toInt()
                        ?: if (kind == StyleSourceKind.VECTOR) 14 else 22,
                    tileSize = source["tileSize"]?.let(StyleConvert::number) ?: 512.0,
                    geojson = source["data"],
                )
            }
            return MapStyleSheet(
                name = json["name"] as? String ?: "",
                sources = sources,
                layers = rawLayers.mapNotNull(StyleLayer::fromJson),
                glyphsUrl = json["glyphs"] as? String,
                spriteUrl = json["sprite"] as? String,
            )
        }

        /** Parses a style document from text; see [parse]. */
        fun parse(text: String): MapStyleSheet? = parse(text.toByteArray(Charsets.UTF_8))

        /** Whether a string parses as a URL, as the TileJSON URL must. */
        private fun isValidUrl(s: String): Boolean = try {
            URI(s)
            s.isNotEmpty()
        } catch (e: URISyntaxException) {
            false
        }
    }
}
