package com.acmeaom.myradar.sdk

import android.graphics.Bitmap
import androidx.annotation.ColorInt
import java.time.Instant

/**
 * Everything known about a flight shown with [MyRadarMapView.showFlight].
 *
 * @property flightId Opaque id of this particular flight (one departure of the flight number).
 * @property ident The flight number as printed on tickets when known (`UA 1`), otherwise the callsign.
 * @property identIata Airline flight number, for example `UA1`.
 * @property identIcao Callsign the aircraft broadcasts, for example `UAL1`.
 * @property operatorCode Operating airline's ICAO code, for example `UAL`.
 * @property aircraftType ICAO aircraft type, for example `B789`.
 * @property registration Aircraft registration (tail number).
 * @property status Human-readable status, for example `En Route / On Time`.
 * @property isAirborne Taken off and not yet landed.
 * @property hasLanded Landed (or arrived at the gate).
 * @property actualDeparture Take-off time.
 * @property estimatedArrival Expected landing time while airborne.
 * @property actualArrival Landing time.
 * @property progress Share of the trip flown, `0..1`, when known.
 * @property position Where the aircraft is, when known.
 * @property plannedRoute The filed route, origin to destination. Empty when not available.
 * @property track The track flown so far, oldest first.
 */
public data class FlightInfo(
    val flightId: String,
    val ident: String,
    val identIata: String?,
    val identIcao: String?,
    val operatorCode: String?,
    val aircraftType: String?,
    val registration: String?,
    val status: String,
    val isAirborne: Boolean,
    val hasLanded: Boolean,
    val isCancelled: Boolean,
    val origin: FlightAirport?,
    val destination: FlightAirport?,
    val scheduledDeparture: Instant?,
    val actualDeparture: Instant?,
    val scheduledArrival: Instant?,
    val estimatedArrival: Instant?,
    val actualArrival: Instant?,
    val progress: Double?,
    val position: FlightPosition?,
    val plannedRoute: List<LatLng>,
    val track: List<FlightTrackPoint>,
)

/**
 * An airport at one end of a flight.
 *
 * @property code IATA code when the airport has one (`SFO`), otherwise its ICAO code.
 * @property coordinate Position, when known (from the flight's planned route).
 */
public data class FlightAirport(
    val code: String,
    val iata: String?,
    val icao: String?,
    val name: String,
    val city: String,
    val coordinate: LatLng?,
)

/**
 * Where the aircraft is.
 *
 * @property altitudeFeet Feet above sea level, when reported.
 * @property heading Degrees clockwise from north, when reported.
 * @property timestamp When the position was reported or estimated.
 * @property isEstimated True when the position is an estimate from the flight plan rather than
 *   a report, which is common over oceans between position reports. The map draws the aircraft
 *   hollow.
 */
public data class FlightPosition(
    val coordinate: LatLng,
    val altitudeFeet: Double?,
    val groundSpeedKnots: Double?,
    val heading: Double?,
    val timestamp: Instant,
    val isEstimated: Boolean,
)

/** One recorded position along the track the aircraft has flown. */
public data class FlightTrackPoint(
    val coordinate: LatLng,
    val altitudeFeet: Double?,
    val timestamp: Instant,
)

/**
 * What [MyRadarMapView.showFlight] draws, and how it behaves.
 *
 * @property plannedRoute The whole filed route, origin to destination, as faint dashes.
 * @property track The track the aircraft has flown, as a solid white line.
 * @property remainingRoute The route still ahead, aircraft to destination, as bold dashes.
 * @property airports Origin and destination markers.
 * @property aircraft The aircraft, pointing along its heading, with a label.
 * @property fitToFlight Move the map to show the whole flight once it's loaded.
 * @property refreshIntervalSeconds How often the flight is updated while it hasn't landed; 0
 *   turns updates off. Values below 15 seconds are raised to 15.
 * @property color Route and marker color.
 * @property aircraftIcon Your own image for the aircraft, in place of the built-in one. Draw it
 *   nose up; the map turns it to the heading. While the position is estimated it's drawn half
 *   transparent.
 * @property aircraftIconSizeDp The aircraft's size on screen, in dp (an icon's longer side).
 */
public data class FlightOptions @JvmOverloads constructor(
    val plannedRoute: Boolean = true,
    val track: Boolean = true,
    val remainingRoute: Boolean = true,
    val airports: Boolean = true,
    val aircraft: Boolean = true,
    val fitToFlight: Boolean = true,
    val refreshIntervalSeconds: Long = 60,
    @ColorInt val color: Int = DEFAULT_COLOR,
    val aircraftIcon: Bitmap? = null,
    val aircraftIconSizeDp: Float = 32f,
) {
    public companion object {
        /** Light blue. */
        @ColorInt public const val DEFAULT_COLOR: Int = 0xFF4DA3FF.toInt()
    }
}

/**
 * Why a flight couldn't be shown or updated.
 *
 * @property reason What went wrong.
 * @property ident The flight number as given.
 */
public class FlightException(
    public val reason: Reason,
    public val ident: String,
    message: String,
) : Exception(message) {

    public enum class Reason {
        /** The text isn't a flight number, callsign or registration. */
        InvalidIdent,
        /** No flight with that number was found. */
        NotFound,
        /** Flight data didn't respond; try again later. */
        Unavailable,
        /** The API key was missing or not accepted. See [MyRadarSdk.configure]. */
        KeyRejected,
    }
}
