package com.acmeaom.myradar.sdk.engine.gl

/**
 * The engine's weather shaders: radar tiles and wind particles. The fragment shaders are the
 * engine's own ([WeatherShaderSources]); the vertex shaders here feed them the inputs they expect,
 * and `radar_future_fs` builds on the advection shader's helpers.
 *
 * The engine's fragment uniforms are packed into `vec4` arrays, members in declaration order:
 * - `fs_per_draw_uniforms_tile[1]`: x blending mode (0 alpha, 1 additive, 2 anti-aliased nearest).
 * - `fs_per_frame_uniforms_tile[3]`: [0] atmosphere color; [1] lightning Mercator xy, radius,
 *   height; [2] xyz camera direction.
 * - `morphing_fs_per_frame_uniforms[1]`, `advection_fs_per_frame_uniforms[1]`: x lerp factor.
 * - `advection_fs_per_draw_uniforms[2]`: [0] sample coord min xy, max zw; [1] xy inverse mosaic
 *   size in texels.
 * - `per_frame_fs_ubo_particle[1]`: x opacity.
 */
internal object WeatherShaders {
    private const val VERTEX_HEADER = "#version 300 es\nprecision highp float;\nprecision highp int;\n"
    /** As the engine's own fragment shaders declare it. */
    private const val FRAGMENT_HEADER = "#version 300 es\nprecision mediump float;\nprecision highp int;\n"

    val vertex: Map<String, String> = mapOf(
        // A unit quad per tile, with the outputs the engine's tile fragment shaders read: texture
        // coordinates through `_textureCoordinateTransform` (scale in xy, translation in zw,
        // applied as `scale * (uv + translation)`), opacity, and the position in Mercator meters
        // for the lightning flash. The tiles are flat, so there's no globe position or sun shading.
        "radar_vs" to """
            layout(location = 0) in vec2 a_pos;
            uniform mat4 u_matrix;
            uniform vec4 u_tex_transform;
            // xy: north-west corner, z: tile size, in Web Mercator meters (y up).
            uniform vec4 u_tile_meters;
            uniform float u_opacity;
            out vec2 v_tex_coord;
            out float v_opacity;
            out vec3 v_cartesian_coord;
            out vec2 v_mercator_coord;
            out float v_sun_shading_factor;
            void main() {
                gl_Position = u_matrix * vec4(a_pos, 0.0, 1.0);
                v_tex_coord = u_tex_transform.xy * (a_pos + u_tex_transform.zw);
                v_opacity = u_opacity;
                v_cartesian_coord = vec3(0.0);
                v_mercator_coord = u_tile_meters.xy + vec2(a_pos.x, -a_pos.y) * u_tile_meters.z;
                v_sun_shading_factor = 1.0;
            }
        """,
        // The engine's `particle_program` vertex stage on the flat map: trail vertices in the
        // engine's Mercator meters (y down), each widened sideways by `u_size` in clip space,
        // colored by speed and faded by age, feeding the engine's own `particle_fs`.
        "particle_vs" to """
            layout(location = 0) in vec2 a_pos;
            layout(location = 1) in float a_offset;
            layout(location = 2) in float a_generation;
            layout(location = 3) in float a_birth_time;
            layout(location = 4) in vec2 a_prev;
            layout(location = 5) in float a_speed_factor;
            uniform mat4 u_map_to_ndc;
            uniform float u_size;
            uniform float u_sim_time;
            uniform float u_trail_decay_rate;
            out float v_discard_marker;
            out vec2 v_opacity;
            out float v_palette_coord_u;
            out vec3 v_bary;
            void main() {
                vec4 ortho = u_map_to_ndc * vec4(a_pos, 0.0, 1.0);
                gl_Position = ortho / ortho.w;
                vec2 velocity = a_speed_factor != 0.0 ? (a_pos - a_prev) / a_speed_factor : vec2(0.0);
                if (velocity.x != 0.0 || velocity.y != 0.0) {
                    vec2 dir = normalize(velocity);
                    // As the engine has it: "something about velocity's y component is sign flipped".
                    vec2 dir90ccw = vec2(-dir.y, -dir.x);
                    float offset = mod(a_offset, 2.0) * 2.0 - 1.0;
                    gl_Position.xy += u_size * dir90ccw * offset;
                }
                float speed = length(velocity); // m/s
                v_palette_coord_u = clamp(speed * 1.94 / 50.0, 0.0, 1.0);
                v_discard_marker = a_generation;
                // Age is 0 when newborn, 1 when dead.
                float age = clamp((u_sim_time - a_birth_time) * (1.0 - u_trail_decay_rate), 0.0, 1.0);
                v_opacity = vec2(2.0 * (0.5 - abs(0.5 - age)), 1.0 - age);
                float corner = mod(a_offset, 3.0);
                v_bary = corner == 0.0 ? vec3(0.0, 0.0, 1.0)
                    : corner == 1.0 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
            }
        """,
    ).mapValues { VERTEX_HEADER + it.value.trimIndent() + "\n" }

    /**
     * A predicted frame: the engine's `advection_tile_program` fragment logic on the same 2×2
     * mosaic layout as observed frames, using the engine's own helpers. Each pixel samples the
     * newest scan upstream along the storm motion by the lerp factor's frame steps; precipitation
     * type is taken unmoved ("we intentionally don't advect the classification"), and samples that
     * would leave the loaded neighbourhood are dropped.
     */
    private val radarFuture = FRAGMENT_HEADER + WeatherShaderSources.radarAdvectionLibrary + """
layout(location = 0) out highp vec4 frag_color;

void main()
{
    highp vec4 advection_raw = texture(u_texture_advection_0, fract(v_tex_coord * 2.0));
    highp vec2 inverse_size = advection_fs_per_draw_uniforms[1].xy;
    highp vec2 advection_uv = -inverse_size * vec2(ucomp(advection_raw), vcomp(advection_raw));
    highp vec2 advected = v_tex_coord + advection_uv * advection_fs_per_frame_uniforms[0].x;
    // Don't bilerp past the edge of the safe area: inset it by half a pixel.
    highp vec2 clamped = clamp(advected, advection_fs_per_draw_uniforms[0].xy + 0.5 * inverse_size,
                               advection_fs_per_draw_uniforms[0].zw - 0.5 * inverse_size);
    highp vec2 advected_coord = fract(clamped);
    highp vec4 advected_sample = texture_a_lookup(advected_coord);
    highp float advected_dbz = advected_sample.a == 0.0 ? 0.0 : advected_sample.g;
    highp vec2 here = fract(clamp(v_tex_coord, advection_fs_per_draw_uniforms[0].xy,
                                  advection_fs_per_draw_uniforms[0].zw));
    highp vec4 classification = texture_a_lookup(here);
    if (all(equal(clamped, advected)))
    {
        vec4 encoded = vec4(classification.r, advected_dbz, classification.b, 0.0);
        frag_color = v_opacity * applyPalette(encoded);
    }
    else
    {
        frag_color = vec4(0.0);
    }
}
"""

    val fragment: Map<String, String> = mapOf(
        "radar_morph_fs" to WeatherShaderSources.radarMorph,
        "radar_advection_fs" to WeatherShaderSources.radarAdvection,
        "radar_tile_fs" to WeatherShaderSources.radarTile,
        "radar_future_fs" to radarFuture,
        "particle_fs" to WeatherShaderSources.particle,
    )
}
