// Polygon triangulation with holes: a port of Mapbox's earcut (ISC License,
// Copyright (c) 2016, Mapbox).

package com.acmeaom.myradar.sdk.engine.basemap

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

internal object Earcut {
    /**
     * Triangulates a polygon given as flat x, y coordinates. [holeIndices] are the vertex indices
     * (not coordinate indices) where each hole starts. Returns vertex indices, three per triangle.
     *
     * Takes and returns primitive arrays so large tiles don't box every coordinate.
     */
    fun triangulate(data: DoubleArray, holeIndices: IntArray = IntArray(0)): IntArray {
        val hasHoles = holeIndices.isNotEmpty()
        val outerLen = if (hasHoles) holeIndices[0] * 2 else data.size
        var outer = linkedList(data, 0, outerLen, true) ?: return IntArray(0)
        if (outer.next === outer.prev) return IntArray(0)
        val triangles = IntList()
        if (hasHoles) outer = eliminateHoles(data, holeIndices, outer)

        var minX = 0.0
        var minY = 0.0
        var invSize = 0.0
        // Hash the vertices of large polygons to speed up the ear test.
        if (data.size > 80 * 2) {
            minX = data[0]; minY = data[1]
            var maxX = minX
            var maxY = minY
            var i = 2
            while (i < outerLen) {
                val x = data[i]
                val y = data[i + 1]
                minX = min(minX, x); minY = min(minY, y); maxX = max(maxX, x); maxY = max(maxY, y)
                i += 2
            }
            invSize = max(maxX - minX, maxY - minY)
            invSize = if (invSize != 0.0) 32767 / invSize else 0.0
        }
        earcutLinked(outer, triangles, minX, minY, invSize, 0)
        return triangles.toArray()
    }

    /** Convenience over [triangulate] for boxed lists. */
    fun triangulate(data: List<Double>, holeIndices: List<Int> = emptyList()): List<Int> =
        triangulate(data.toDoubleArray(), holeIndices.toIntArray()).asList()

    private class Node(val i: Int, val x: Double, val y: Double) {
        lateinit var prev: Node
        lateinit var next: Node
        // z-order is computed in 64 bits: interleaving two 16-bit-plus coordinates can exceed 31 bits.
        var z: Long = 0
        var prevZ: Node? = null
        var nextZ: Node? = null
        var steiner = false
    }

    /** A growable int array for the output indices. */
    private class IntList {
        var values = IntArray(64)
        var size = 0

        fun add(v: Int) {
            if (size == values.size) values = values.copyOf(size * 2)
            values[size++] = v
        }

        fun toArray(): IntArray = values.copyOf(size)
    }

    private fun linkedList(data: DoubleArray, start: Int, end: Int, clockwise: Boolean): Node? {
        var last: Node? = null
        if (clockwise == (signedArea(data, start, end) > 0)) {
            var i = start
            while (i < end) { last = insertNode(i / 2, data[i], data[i + 1], last); i += 2 }
        } else {
            var i = end - 2
            while (i >= start) { last = insertNode(i / 2, data[i], data[i + 1], last); i -= 2 }
        }
        if (last != null && equals(last, last.next)) {
            removeNode(last)
            last = last.next
        }
        return last
    }

    private fun filterPoints(start: Node, end0: Node? = null): Node {
        var end = end0 ?: start
        var p = start
        var again: Boolean
        do {
            again = false
            if (!p.steiner && (equals(p, p.next) || area(p.prev, p, p.next) == 0.0)) {
                removeNode(p)
                p = p.prev
                end = p
                if (p === p.next) break
                again = true
            } else {
                p = p.next
            }
        } while (again || p !== end)
        return end
    }

    private fun earcutLinked(ear0: Node?, triangles: IntList, minX: Double, minY: Double, invSize: Double, pass: Int) {
        var ear = ear0 ?: return
        if (pass == 0 && invSize != 0.0) indexCurve(ear, minX, minY, invSize)
        var stop = ear
        while (ear.prev !== ear.next) {
            val prev = ear.prev
            val next = ear.next
            if (if (invSize != 0.0) isEarHashed(ear, minX, minY, invSize) else isEar(ear)) {
                triangles.add(prev.i); triangles.add(ear.i); triangles.add(next.i)
                removeNode(ear)
                ear = next.next
                stop = next.next
                continue
            }
            ear = next
            if (ear === stop) {
                when (pass) {
                    0 -> earcutLinked(filterPoints(ear), triangles, minX, minY, invSize, 1)
                    1 -> {
                        val e = cureLocalIntersections(filterPoints(ear), triangles)
                        earcutLinked(e, triangles, minX, minY, invSize, 2)
                    }
                    2 -> splitEarcut(ear, triangles, minX, minY, invSize)
                }
                break
            }
        }
    }

    private fun isEar(ear: Node): Boolean {
        val a = ear.prev
        val b = ear
        val c = ear.next
        if (area(a, b, c) >= 0) return false
        val x0 = min(a.x, min(b.x, c.x))
        val y0 = min(a.y, min(b.y, c.y))
        val x1 = max(a.x, max(b.x, c.x))
        val y1 = max(a.y, max(b.y, c.y))
        var p = c.next
        while (p !== a) {
            if (p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1 &&
                pointInTriangle(a.x, a.y, b.x, b.y, c.x, c.y, p.x, p.y) && area(p.prev, p, p.next) >= 0
            ) return false
            p = p.next
        }
        return true
    }

    private fun isEarHashed(ear: Node, minX: Double, minY: Double, invSize: Double): Boolean {
        val a = ear.prev
        val b = ear
        val c = ear.next
        if (area(a, b, c) >= 0) return false
        val x0 = min(a.x, min(b.x, c.x))
        val y0 = min(a.y, min(b.y, c.y))
        val x1 = max(a.x, max(b.x, c.x))
        val y1 = max(a.y, max(b.y, c.y))
        val minZ = zOrder(x0, y0, minX, minY, invSize)
        val maxZ = zOrder(x1, y1, minX, minY, invSize)
        var p = ear.prevZ
        var n = ear.nextZ
        while (p != null && p.z >= minZ && n != null && n.z <= maxZ) {
            if (p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1 && p !== a && p !== c &&
                pointInTriangle(a.x, a.y, b.x, b.y, c.x, c.y, p.x, p.y) && area(p.prev, p, p.next) >= 0
            ) return false
            p = p.prevZ
            if (n.x >= x0 && n.x <= x1 && n.y >= y0 && n.y <= y1 && n !== a && n !== c &&
                pointInTriangle(a.x, a.y, b.x, b.y, c.x, c.y, n.x, n.y) && area(n.prev, n, n.next) >= 0
            ) return false
            n = n.nextZ
        }
        while (p != null && p.z >= minZ) {
            if (p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1 && p !== a && p !== c &&
                pointInTriangle(a.x, a.y, b.x, b.y, c.x, c.y, p.x, p.y) && area(p.prev, p, p.next) >= 0
            ) return false
            p = p.prevZ
        }
        while (n != null && n.z <= maxZ) {
            if (n.x >= x0 && n.x <= x1 && n.y >= y0 && n.y <= y1 && n !== a && n !== c &&
                pointInTriangle(a.x, a.y, b.x, b.y, c.x, c.y, n.x, n.y) && area(n.prev, n, n.next) >= 0
            ) return false
            n = n.nextZ
        }
        return true
    }

    private fun cureLocalIntersections(start0: Node, triangles: IntList): Node {
        var start = start0
        var p = start
        do {
            val a = p.prev
            val b = p.next.next
            if (!equals(a, b) && intersects(a, p, p.next, b) && locallyInside(a, b) && locallyInside(b, a)) {
                triangles.add(a.i); triangles.add(p.i); triangles.add(b.i)
                removeNode(p)
                removeNode(p.next)
                p = b
                start = b
            }
            p = p.next
        } while (p !== start)
        return filterPoints(p)
    }

    private fun splitEarcut(start: Node, triangles: IntList, minX: Double, minY: Double, invSize: Double) {
        var a = start
        do {
            var b = a.next.next
            while (b !== a.prev) {
                if (a.i != b.i && isValidDiagonal(a, b)) {
                    var c = splitPolygon(a, b)
                    val a2 = filterPoints(a, a.next)
                    c = filterPoints(c, c.next)
                    earcutLinked(a2, triangles, minX, minY, invSize, 0)
                    earcutLinked(c, triangles, minX, minY, invSize, 0)
                    return
                }
                b = b.next
            }
            a = a.next
        } while (a !== start)
    }

    private fun eliminateHoles(data: DoubleArray, holeIndices: IntArray, outer0: Node): Node {
        val queue = ArrayList<Node>(holeIndices.size)
        for (n in holeIndices.indices) {
            val start = holeIndices[n] * 2
            val end = if (n < holeIndices.size - 1) holeIndices[n + 1] * 2 else data.size
            val list = linkedList(data, start, end, false) ?: continue
            if (list === list.next) list.steiner = true
            queue.add(leftmost(list))
        }
        // Plain `<` comparisons (not Double.compareTo, which orders -0.0 before 0.0).
        queue.sortWith { a, b ->
            if (a.x != b.x) {
                if (a.x < b.x) -1 else 1
            } else if (a.y < b.y) -1 else if (a.y > b.y) 1 else 0
        }
        var outer = outer0
        for (hole in queue) {
            outer = eliminateHole(hole, outer)
        }
        return outer
    }

    private fun eliminateHole(hole: Node, outer: Node): Node {
        val bridge = findHoleBridge(hole, outer) ?: return outer
        val bridgeReverse = splitPolygon(bridge, hole)
        filterPoints(bridgeReverse, bridgeReverse.next)
        return filterPoints(bridge, bridge.next)
    }

    private fun findHoleBridge(hole: Node, outer: Node): Node? {
        var p = outer
        val hx = hole.x
        val hy = hole.y
        var qx = Double.NEGATIVE_INFINITY
        var m: Node? = null
        do {
            if (hy <= p.y && hy >= p.next.y && p.next.y != p.y) {
                val x = p.x + (hy - p.y) * (p.next.x - p.x) / (p.next.y - p.y)
                if (x <= hx && x > qx) {
                    qx = x
                    m = if (p.x < p.next.x) p else p.next
                    if (x == hx) return m
                }
            }
            p = p.next
        } while (p !== outer)
        var best = m ?: return null
        val stop = best
        val mx = best.x
        val my = best.y
        var tanMin = Double.POSITIVE_INFINITY
        p = best
        do {
            if (hx >= p.x && p.x >= mx && hx != p.x &&
                pointInTriangle(if (hy < my) hx else qx, hy, mx, my, if (hy < my) qx else hx, hy, p.x, p.y)
            ) {
                val tanCur = abs(hy - p.y) / (hx - p.x)
                if (locallyInside(p, hole) && (tanCur < tanMin || (tanCur == tanMin && (p.x > best.x ||
                        (p.x == best.x && sectorContainsSector(best, p)))))
                ) {
                    best = p
                    tanMin = tanCur
                }
            }
            p = p.next
        } while (p !== stop)
        return best
    }

    private fun sectorContainsSector(m: Node, p: Node): Boolean =
        area(m.prev, m, p.prev) < 0 && area(p.next, m, m.next) < 0

    private fun indexCurve(start: Node, minX: Double, minY: Double, invSize: Double) {
        var p = start
        do {
            if (p.z == 0L) p.z = zOrder(p.x, p.y, minX, minY, invSize)
            p.prevZ = p.prev
            p.nextZ = p.next
            p = p.next
        } while (p !== start)
        p.prevZ?.nextZ = null
        p.prevZ = null
        sortLinked(p)
    }

    private fun sortLinked(list0: Node) {
        var list: Node? = list0
        var inSize = 1
        var numMerges: Int
        do {
            var p = list
            list = null
            var tail: Node? = null
            numMerges = 0
            while (p != null) {
                numMerges += 1
                var q = p
                var pSize = 0
                for (k in 0 until inSize) {
                    pSize += 1
                    q = q?.nextZ
                    if (q == null) break
                }
                var qSize = inSize
                while (pSize > 0 || (qSize > 0 && q != null)) {
                    val e: Node
                    if (pSize != 0 && (qSize == 0 || q == null || p!!.z <= q.z)) {
                        e = p!!; p = p.nextZ; pSize -= 1
                    } else {
                        e = q!!; q = q.nextZ; qSize -= 1
                    }
                    if (tail != null) tail.nextZ = e else list = e
                    e.prevZ = tail
                    tail = e
                }
                p = q
            }
            tail?.nextZ = null
            inSize *= 2
        } while (numMerges > 1)
    }

    private fun zOrder(x0: Double, y0: Double, minX: Double, minY: Double, invSize: Double): Long {
        var x = ((x0 - minX) * invSize).toLong()
        var y = ((y0 - minY) * invSize).toLong()
        x = (x or (x shl 8)) and 0x00FF00FF
        x = (x or (x shl 4)) and 0x0F0F0F0F
        x = (x or (x shl 2)) and 0x33333333
        x = (x or (x shl 1)) and 0x55555555
        y = (y or (y shl 8)) and 0x00FF00FF
        y = (y or (y shl 4)) and 0x0F0F0F0F
        y = (y or (y shl 2)) and 0x33333333
        y = (y or (y shl 1)) and 0x55555555
        return x or (y shl 1)
    }

    private fun leftmost(start: Node): Node {
        var p = start
        var left = start
        do {
            if (p.x < left.x || (p.x == left.x && p.y < left.y)) left = p
            p = p.next
        } while (p !== start)
        return left
    }

    @Suppress("LongParameterList")
    private fun pointInTriangle(
        ax: Double, ay: Double, bx: Double, by: Double, cx: Double, cy: Double, px: Double, py: Double,
    ): Boolean =
        (cx - px) * (ay - py) >= (ax - px) * (cy - py) &&
            (ax - px) * (by - py) >= (bx - px) * (ay - py) &&
            (bx - px) * (cy - py) >= (cx - px) * (by - py)

    private fun isValidDiagonal(a: Node, b: Node): Boolean =
        a.next.i != b.i && a.prev.i != b.i && !intersectsPolygon(a, b) &&
            (locallyInside(a, b) && locallyInside(b, a) && middleInside(a, b) &&
                (area(a.prev, a, b.prev) != 0.0 || area(a, b.prev, b) != 0.0) ||
                equals(a, b) && area(a.prev, a, a.next) > 0 && area(b.prev, b, b.next) > 0)

    private fun area(p: Node, q: Node, r: Node): Double = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y)

    private fun equals(p1: Node, p2: Node): Boolean = p1.x == p2.x && p1.y == p2.y

    private fun intersects(p1: Node, q1: Node, p2: Node, q2: Node): Boolean {
        val o1 = sign(area(p1, q1, p2))
        val o2 = sign(area(p1, q1, q2))
        val o3 = sign(area(p2, q2, p1))
        val o4 = sign(area(p2, q2, q1))
        if (o1 != o2 && o3 != o4) return true
        if (o1 == 0 && onSegment(p1, p2, q1)) return true
        if (o2 == 0 && onSegment(p1, q2, q1)) return true
        if (o3 == 0 && onSegment(p2, p1, q2)) return true
        if (o4 == 0 && onSegment(p2, q1, q2)) return true
        return false
    }

    private fun onSegment(p: Node, q: Node, r: Node): Boolean =
        q.x <= max(p.x, r.x) && q.x >= min(p.x, r.x) && q.y <= max(p.y, r.y) && q.y >= min(p.y, r.y)

    private fun sign(v: Double): Int = if (v > 0) 1 else if (v < 0) -1 else 0

    private fun intersectsPolygon(a: Node, b: Node): Boolean {
        var p = a
        do {
            if (p.i != a.i && p.next.i != a.i && p.i != b.i && p.next.i != b.i && intersects(p, p.next, a, b)) {
                return true
            }
            p = p.next
        } while (p !== a)
        return false
    }

    private fun locallyInside(a: Node, b: Node): Boolean =
        if (area(a.prev, a, a.next) < 0) {
            area(a, b, a.next) >= 0 && area(a, a.prev, b) >= 0
        } else {
            area(a, b, a.prev) < 0 || area(a, a.next, b) < 0
        }

    private fun middleInside(a: Node, b: Node): Boolean {
        var p = a
        var inside = false
        val px = (a.x + b.x) / 2
        val py = (a.y + b.y) / 2
        do {
            if ((p.y > py) != (p.next.y > py) && p.next.y != p.y &&
                px < (p.next.x - p.x) * (py - p.y) / (p.next.y - p.y) + p.x
            ) inside = !inside
            p = p.next
        } while (p !== a)
        return inside
    }

    private fun splitPolygon(a: Node, b: Node): Node {
        val a2 = Node(a.i, a.x, a.y)
        val b2 = Node(b.i, b.x, b.y)
        val an = a.next
        val bp = b.prev
        a.next = b; b.prev = a
        a2.next = an; an.prev = a2
        b2.next = a2; a2.prev = b2
        bp.next = b2; b2.prev = bp
        return b2
    }

    private fun insertNode(i: Int, x: Double, y: Double, last: Node?): Node {
        val p = Node(i, x, y)
        if (last != null) {
            p.next = last.next
            p.prev = last
            last.next.prev = p
            last.next = p
        } else {
            p.prev = p
            p.next = p
        }
        return p
    }

    private fun removeNode(p: Node) {
        p.next.prev = p.prev
        p.prev.next = p.next
        p.prevZ?.nextZ = p.nextZ
        p.nextZ?.prevZ = p.prevZ
    }

    private fun signedArea(data: DoubleArray, start: Int, end: Int): Double {
        var sum = 0.0
        var j = end - 2
        var i = start
        while (i < end) {
            sum += (data[j] - data[i]) * (data[i + 1] + data[j + 1])
            j = i
            i += 2
        }
        return sum
    }
}
