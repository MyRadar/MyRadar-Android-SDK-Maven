// Signed-distance-field glyphs for labels, packed into one single-channel texture. Like the
// engine (`FWTypography`), every label uses the bundled Inter SemiBold rather than the style's
// fonts. Glyphs are rendered with `android.graphics` at 24 pixels with a 3-pixel border and turned
// into distance fields with the TinySDF method (radius 8, cutoff 0.25, so the outline is 0.75).

package com.acmeaom.myradar.sdk.engine.basemap

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.Log
import com.acmeaom.myradar.sdk.engine.EngineAssets
import com.acmeaom.myradar.sdk.engine.gl.GPUTexture
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** A glyph's bitmap size and placement, in pixels at [GlyphAtlas.BASE_SIZE]. */
internal data class GlyphMetrics(
    val width: Int,
    val height: Int,
    val left: Int,
    val top: Int,
    val advance: Int,
    /** Where the bitmap (width + 6) × (height + 6) sits in the atlas, in pixels. */
    val atlasX: Int,
    val atlasY: Int,
)

/**
 * The label glyph atlas. Glyphs are rasterized on first use, on the main thread, and uploaded
 * straight into the texture, so the GL context must be current: only call [glyph] while drawing.
 */
internal class GlyphAtlas {
    var onLoaded: (() -> Unit)? = null

    private val glyphs = HashMap<Int, GlyphMetrics>()
    private var shelfX = 0
    private var shelfY = 0
    private var shelfHeight = 0
    private val paint = loadFont(BASE_SIZE)
    private val path = Path()
    private val bounds = RectF()
    private var textureCreated = false

    /** Single channel, 8 bits; created on first use, when a GL context is current. */
    var texture: GPUTexture? = null
        get() {
            if (!textureCreated) {
                textureCreated = true
                field = GPUTexture.create(SIZE, SIZE, singleChannel = true, linear = true)
            }
            return field
        }
        private set

    /** Glyphs are generated locally, so text is always ready. */
    @Suppress("UNUSED_PARAMETER")
    fun isReady(text: String, fontStack: String): Boolean = true

    /** A glyph's metrics, rendering it into the atlas the first time it's used. */
    @Suppress("UNUSED_PARAMETER")
    fun glyph(codepoint: Int, fontStack: String): GlyphMetrics? {
        glyphs[codepoint]?.let { return it }
        if (!Character.isValidCodePoint(codepoint)) return null
        val s = String(Character.toChars(codepoint))
        if (!paint.hasGlyph(s)) {
            // Not in the font: draw nothing, but keep the layout moving.
            val missing = GlyphMetrics(0, 0, 0, 0, 0, 0, 0)
            glyphs[codepoint] = missing
            return missing
        }
        val advance = paint.measureText(s)
        // Outline bounds, y down from the baseline; flipped to Core Text's y-up convention.
        path.reset()
        paint.getTextPath(s, 0, s.length, 0f, 0f, path)
        path.computeBounds(bounds, true)
        val empty = bounds.isEmpty
        val left = if (empty) 0 else floor(bounds.left).toInt()
        val top = if (empty) 0 else ceil(-bounds.top).toInt()
        val width = if (empty) 0 else max(0, ceil(bounds.right).toInt() - left)
        val height = if (empty) 0 else max(0, top - floor(-bounds.bottom).toInt())
        var x = 0
        var y = 0
        if (width > 0 && height > 0) {
            val w = width + 2 * BORDER
            val h = height + 2 * BORDER
            if (shelfX + w + 1 > SIZE) {
                shelfX = 0; shelfY += shelfHeight + 1; shelfHeight = 0
            }
            if (shelfY + h > SIZE) return null
            x = shelfX; y = shelfY
            shelfX += w + 1
            shelfHeight = max(shelfHeight, h)
            val sdf = renderSDF(s, w, h, originX = (BORDER - left).toFloat(), baselineY = (BORDER + top).toFloat())
            texture?.replace(x, y, w, h, sdf)
        }
        val metrics = GlyphMetrics(width, height, left, top, advance.roundToInt(), x, y)
        glyphs[codepoint] = metrics
        return metrics
    }

    /** Renders a glyph's coverage (rows top first, as the atlas is laid out) and converts it to an SDF. */
    private fun renderSDF(s: String, width: Int, height: Int, originX: Float, baselineY: Float): ByteArray {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ALPHA_8)
        Canvas(bitmap).drawText(s, originX, baselineY, paint)
        val rowBytes = bitmap.rowBytes
        val buffer = ByteBuffer.allocate(rowBytes * height)
        bitmap.copyPixelsToBuffer(buffer)
        bitmap.recycle()
        val raw = buffer.array()
        val coverage = ByteArray(width * height)
        for (row in 0 until height) System.arraycopy(raw, row * rowBytes, coverage, row * width, width)
        return tinySDF(coverage, width, height)
    }

    companion object {
        const val SIZE = 2048
        const val BORDER = 3
        /** Glyphs are rendered at 24 pixels; label sizes scale from that. */
        const val BASE_SIZE = 24f
        private const val RADIUS = 8.0
        private const val CUTOFF = 0.25
        private const val INF = 1e20
        private const val LOG_TAG = "MyRadarSDK"

        /** The engine's label font, Inter SemiBold, at a size in pixels. */
        fun loadFont(size: Float): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            val inter = EngineAssets.interSemiBold
            if (inter === Typeface.DEFAULT_BOLD) Log.w(LOG_TAG, "The label font is missing; labels use the system font")
            typeface = inter
            textSize = size
            color = Color.WHITE
            isSubpixelText = true
        }

        /** Converts 8-bit coverage to a signed distance field (TinySDF). */
        fun tinySDF(coverage: ByteArray, width: Int, height: Int): ByteArray {
            val n = width * height
            val outer = DoubleArray(n)
            val inner = DoubleArray(n)
            for (i in 0 until n) {
                val a = (coverage[i].toInt() and 0xFF) / 255.0
                if (a == 1.0) {
                    outer[i] = 0.0; inner[i] = INF
                } else if (a == 0.0) {
                    outer[i] = INF; inner[i] = 0.0
                } else {
                    val d = 0.5 - a
                    outer[i] = if (d > 0) d * d else 0.0
                    inner[i] = if (d < 0) d * d else 0.0
                }
            }
            edt(outer, width, height)
            edt(inner, width, height)
            val result = ByteArray(n)
            for (i in 0 until n) {
                val d = sqrt(outer[i]) - sqrt(inner[i])
                val raw = 255 - 255 * (d / RADIUS + CUTOFF)
                // Rounded half away from zero, like Swift's `rounded()`.
                val rounded = if (raw >= 0) floor(raw + 0.5) else -floor(-raw + 0.5)
                result[i] = max(0.0, min(255.0, rounded)).toInt().toByte()
            }
            return result
        }

        /** 2D squared Euclidean distance transform (Felzenszwalb & Huttenlocher), in place. */
        private fun edt(data: DoubleArray, width: Int, height: Int) {
            val size = max(width, height)
            val f = DoubleArray(size)
            val d = DoubleArray(size)
            val v = IntArray(size)
            val z = DoubleArray(size + 1)
            for (x in 0 until width) {
                for (y in 0 until height) f[y] = data[y * width + x]
                edt1d(f, d, v, z, height)
                for (y in 0 until height) data[y * width + x] = d[y]
            }
            for (y in 0 until height) {
                for (x in 0 until width) f[x] = data[y * width + x]
                edt1d(f, d, v, z, width)
                for (x in 0 until width) data[y * width + x] = d[x]
            }
        }

        private fun edt1d(f: DoubleArray, d: DoubleArray, v: IntArray, z: DoubleArray, n: Int) {
            var k = 0
            v[0] = 0
            z[0] = -INF
            z[1] = INF
            for (q in 1 until n) {
                var s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]).toDouble()
                while (s <= z[k]) {
                    k -= 1
                    s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]).toDouble()
                }
                k += 1
                v[k] = q
                z[k] = s
                z[k + 1] = INF
            }
            k = 0
            for (q in 0 until n) {
                while (z[k + 1] < q) k += 1
                d[q] = ((q - v[k]) * (q - v[k])).toDouble() + f[v[k]]
            }
        }
    }
}

/** The style's sprite sheet: icon images by name, in one premultiplied texture. */
internal class SpriteAtlas(network: EngineNetwork, baseUrl: String) {
    class Icon(val x: Int, val y: Int, val width: Int, val height: Int, val pixelRatio: Float)

    var onLoaded: (() -> Unit)? = null
    var icons: Map<String, Icon> = emptyMap(); private set
    private var image: RGBAImage? = null
    private var uploaded: GPUTexture? = null

    /**
     * The sheet's texture, uploaded on first use while drawing (when a GL context is current);
     * null until the sheet has loaded.
     */
    val texture: GPUTexture?
        get() {
            uploaded?.let { return it }
            val pixels = image ?: return null
            image = null
            uploaded = GPUTexture.rgba(pixels.bytes, pixels.width, pixels.height)
            return uploaded
        }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    init {
        scope.launch {
            val jsonData = runCatching { network.data("$baseUrl@2x.json") }.getOrNull() ?: return@launch
            val pngData = runCatching { network.data("$baseUrl@2x.png") }.getOrNull() ?: return@launch
            val parsed = withContext(Dispatchers.Default) {
                val index = parseIndex(jsonData) ?: return@withContext null
                val decoded = RGBAImage.decode(pngData) ?: return@withContext null
                index to decoded
            } ?: return@launch
            image = parsed.second
            icons = parsed.first
            onLoaded?.invoke()
        }
    }

    companion object {
        /** The sprite index; null unless it's an object of objects. */
        fun parseIndex(data: ByteArray): Map<String, Icon>? {
            val index = jsonObject(parseJson(data)) ?: return null
            val icons = HashMap<String, Icon>()
            for ((name, value) in index) {
                val entry = jsonObject(value) ?: return null
                fun int(key: String): Int? = (entry[key] as? Number)?.toInt()
                val x = int("x") ?: continue
                val y = int("y") ?: continue
                val w = int("width") ?: continue
                val h = int("height") ?: continue
                icons[name] = Icon(x, y, w, h, (entry["pixelRatio"] as? Number)?.toFloat() ?: 2f)
            }
            return icons
        }
    }
}
