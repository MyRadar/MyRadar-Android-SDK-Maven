package com.acmeaom.myradar.sdk.engine.radar

import com.acmeaom.myradar.sdk.engine.gl.GPUTexture
import com.acmeaom.myradar.sdk.engine.tiles.TileID

/** One radar tile's texture as it loads. */
internal class RadarTexture {
    sealed class State {
        object Loading : State()
        /** Loaded; a null texture when the tile has no data. */
        class Ready(val texture: GPUTexture?) : State()
        /** Failed at a time, in seconds since 1970. */
        class Failed(val at: Double) : State()
    }

    var state: State = State.Loading

    val isReady: Boolean get() = state is State.Ready
    val isLoading: Boolean get() = state is State.Loading
}

internal data class MosaicKey(
    /** The frame's URL template (time filled in), which identifies the frame and product. */
    val format: String,
    val parent: TileID,
)

/**
 * A 2×2 mosaic of a parent tile's children (`FWTextureMosaic` with width and height 2): child
 * (x, y) lives in slot (x mod 2, y mod 2).
 */
internal class RadarMosaic(nearest: Boolean) {
    val texture: GPUTexture? = GPUTexture.create(SIZE, SIZE, linear = !nearest)?.also { it.clear() }

    private sealed class Child {
        object Loading : Child()
        object Ready : Child()
        class Failed(val at: Double) : Child()
    }

    private val children = HashMap<Int, Child>()

    private fun slot(tile: TileID): Int = (tile.y and 1) * 2 + (tile.x and 1)

    fun childReady(tile: TileID): Boolean = children[slot(tile)] === Child.Ready

    fun needsLoad(tile: TileID, retryBefore: Double): Boolean = when (val child = children[slot(tile)]) {
        null -> true
        is Child.Failed -> child.at < retryBefore
        else -> false
    }

    fun markLoading(tile: TileID) {
        children[slot(tile)] = Child.Loading
    }

    fun markFailed(tile: TileID) {
        children[slot(tile)] = Child.Failed(System.currentTimeMillis() / 1000.0)
    }

    fun forgetIfLoading(tile: TileID) {
        if (children[slot(tile)] === Child.Loading) children.remove(slot(tile))
    }

    /** A tile with no data: its slot stays zero-filled. */
    fun markEmpty(tile: TileID) {
        upload(tile, ZEROS_CHILD)
    }

    fun upload(tile: TileID, pixels: ByteArray) {
        texture?.replace((tile.x and 1) * CHILD, (tile.y and 1) * CHILD, CHILD, CHILD, pixels)
        children[slot(tile)] = Child.Ready
    }

    private companion object {
        const val CHILD = 256
        const val SIZE = 2 * CHILD
        val ZEROS_CHILD = ByteArray(CHILD * CHILD * 4)
    }
}
