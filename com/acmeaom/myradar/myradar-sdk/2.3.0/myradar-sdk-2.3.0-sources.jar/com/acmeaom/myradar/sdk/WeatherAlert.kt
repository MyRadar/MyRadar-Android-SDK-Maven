package com.acmeaom.myradar.sdk

import java.time.Instant

/**
 * A watch, warning or advisory on the map, as reported when the user taps it
 * ([MyRadarMapListener.onWarningTap]).
 *
 * @property id The alert's identifier in MyRadar's alerts feed.
 * @property title What the alert is, e.g. `Tornado Warning`.
 * @property phenomenon The phenomenon code, e.g. `TO` (tornado) or `FF` (flash flood).
 * @property phenomenonName The phenomenon's name, e.g. `Tornado`.
 * @property significance The significance code: `W` warning, `A` watch, `Y` advisory, `S` statement.
 * @property significanceName The significance's name, e.g. `Warning`.
 * @property begins When the alert takes effect, when the feed says.
 * @property expires When the alert expires, when the feed says.
 * @property colorHex The alert's map color as `RRGGBB` hex.
 * @property tag The feed's tag for the alert type, e.g. `nws.to.w`.
 */
public data class WeatherAlert(
    val id: String,
    val title: String,
    val phenomenon: String,
    val phenomenonName: String?,
    val significance: String,
    val significanceName: String?,
    val begins: Instant?,
    val expires: Instant?,
    val colorHex: String?,
    val tag: String?,
) {
    /** The alert's map color as an opaque ARGB color int, or null when unknown. */
    val color: Int?
        get() = colorHex?.takeIf { it.length == 6 }?.toIntOrNull(16)?.let { it or (0xFF shl 24) }

    /** Whether this is a warning (rather than a watch, advisory or statement). */
    val isWarning: Boolean get() = significance == "W"

    /** Whether this is a watch. */
    val isWatch: Boolean get() = significance == "A"

    internal companion object {
        /** An alert from the feed's GeoJSON properties; null when it has nothing to call it. */
        fun fromProperties(p: Map<String, Any?>): WeatherAlert? {
            fun text(key: String): String? = (p[key] as? String)?.trim()?.takeIf { it.isNotEmpty() }
            fun instant(key: String): Instant? {
                val seconds = when (val v = p[key]) {
                    is String -> v.trim().toDoubleOrNull()
                    is Number -> v.toDouble()
                    else -> null
                } ?: return null
                return if (seconds > 0) Instant.ofEpochMilli((seconds * 1000).toLong()) else null
            }
            val phenomenonName = text("phenomenon_string")
            val significanceName = text("significance_string")
            val fallback = listOfNotNull(phenomenonName, significanceName).joinToString(" ")
            val title = text("headline") ?: fallback.ifEmpty { null } ?: return null
            return WeatherAlert(
                id = text("id") ?: "",
                title = title,
                phenomenon = text("phenomenon") ?: "",
                phenomenonName = phenomenonName,
                significance = text("significance") ?: "",
                significanceName = significanceName,
                begins = instant("begin"),
                expires = instant("end"),
                colorHex = text("color")?.uppercase(),
                tag = text("tag"),
            )
        }
    }
}
