package com.acmeaom.myradar.sdk.internal

import android.content.Context
import java.util.UUID

/**
 * A random identifier for this installation of the host app, sent to the API gateway so MyRadar
 * can count active installs of the SDK per API key (for billing). It is not a device or
 * advertising identifier: it is a UUID the SDK generates once, shared with no other app.
 *
 * It is kept in the SDK's own shared preferences file, which Android's Auto Backup includes by
 * default, so the ID comes back when the app is reinstalled or restored onto a new phone.
 */
internal object InstallId {
    /** The header the ID is sent in, on gateway requests only. */
    const val HEADER_FIELD = "X-MyRadar-Install-Id"

    /** The SDK's shared preferences file (`shared_prefs/com.acmeaom.myradar.sdk.xml`). */
    const val PREFERENCES = "com.acmeaom.myradar.sdk"
    private const val KEY = "install_id"

    @Volatile private var cached: String? = null

    /** The app's install ID, created and saved on first use. */
    fun get(context: Context): String = cached ?: synchronized(this) {
        cached ?: run {
            val preferences = context.applicationContext.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
            preferences.getString(KEY, null)?.let(::valid) ?: UUID.randomUUID().toString().also {
                preferences.edit().putString(KEY, it).apply()
            }
        }.also { cached = it }
    }

    /** The ID if `string` is a UUID, normalized to lowercase. */
    fun valid(string: String): String? = runCatching { UUID.fromString(string).toString() }.getOrNull()
        ?.takeIf { it.equals(string, ignoreCase = true) }
}
