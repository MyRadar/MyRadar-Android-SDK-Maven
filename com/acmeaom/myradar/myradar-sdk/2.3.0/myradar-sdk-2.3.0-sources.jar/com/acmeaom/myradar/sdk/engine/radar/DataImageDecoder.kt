package com.acmeaom.myradar.sdk.engine.radar

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorSpace
import com.acmeaom.myradar.sdk.engine.basemap.RGBAImage
import java.nio.ByteBuffer

/**
 * Decodes WebP and PNG tiles whose channels are data (radar classification and reflectivity,
 * wind components), not colors, to their stored bytes: alpha isn't premultiplied into the color
 * channels, and the image is kept in its own color space so nothing is color managed.
 */
internal object DataImageDecoder {
    /** Straight RGBA, rows top first; null when the data isn't an image the system can decode. */
    fun decode(data: ByteArray): RGBAImage? {
        // The image's own color space, so decoding doesn't convert it (to sRGB by default).
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inPremultiplied = false
            inScaled = false
            bounds.outColorSpace?.takeIf { it.model == ColorSpace.Model.RGB }?.let { inPreferredColorSpace = it }
        }
        val bitmap = BitmapFactory.decodeByteArray(data, 0, data.size, options) ?: return null
        if (bitmap.config != Bitmap.Config.ARGB_8888) return null
        // ARGB_8888 is R, G, B, A in memory; this bitmap holds them unpremultiplied.
        val buffer = ByteBuffer.allocate(bitmap.rowBytes * bitmap.height)
        bitmap.copyPixelsToBuffer(buffer)
        val width = bitmap.width
        val height = bitmap.height
        val bytes = if (bitmap.rowBytes == width * 4) {
            buffer.array()
        } else {
            ByteArray(width * height * 4).also { out ->
                for (y in 0 until height) {
                    System.arraycopy(buffer.array(), y * bitmap.rowBytes, out, y * width * 4, width * 4)
                }
            }
        }
        bitmap.recycle()
        return RGBAImage(bytes, width, height)
    }
}
