package com.acmeaom.myradar.sdk.engine.basemap

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** A growable float array, so geometry builds don't box. */
internal class FloatList(capacity: Int = 256) {
    var data = FloatArray(capacity); private set
    var size = 0; private set

    fun add(v: Float) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = v
    }

    fun toArray(): FloatArray = data.copyOf(size)

    fun clear() { size = 0 }
}

/** A growable int array. */
internal class IntList(capacity: Int = 256) {
    var data = IntArray(capacity); private set
    var size = 0; private set

    fun add(v: Int) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = v
    }

    fun add(vararg vs: Int) = vs.forEach(::add)

    fun toArray(): IntArray = data.copyOf(size)
}

/**
 * Triangles for a fill layer: x, y per vertex.
 *
 * Builds GPU-ready geometry from features. Line width isn't baked into [LineGeometry]: vertices
 * carry a unit extrusion vector that the shader scales by the current width, so zooming doesn't
 * rebuild geometry.
 */
internal class FillGeometry {
    val vertices = FloatList()
    val indices = IntList()

    val isEmpty: Boolean get() = indices.size == 0

    /** Adds a polygon feature's rings: outer rings followed by their holes, grouped by winding. */
    fun add(rings: List<Ring>) {
        for (polygon in classify(rings)) {
            var total = 0
            for (ring in polygon) total += ring.size
            val coords = DoubleArray(total)
            val holes = IntArray(polygon.size - 1)
            var count = 0
            for ((n, ring) in polygon.withIndex()) {
                if (n > 0) holes[n - 1] = count / 2
                // Rings repeat their first point at the end; earcut doesn't want it.
                val points = if (ring.pointCount > 1 && closes(ring)) ring.size - 2 else ring.size
                for (i in 0 until points) coords[count++] = ring[i].toDouble()
            }
            if (count < 6) continue
            val flat = if (count == total) coords else coords.copyOf(count)
            val base = vertices.size / 2
            val triangles = Earcut.triangulate(flat, holes)
            for (i in 0 until count) vertices.add(flat[i].toFloat())
            for (t in triangles) indices.add(base + t)
        }
    }

    companion object {
        /** Splits rings into polygons: a ring wound like the first starts a polygon, the others are its holes. */
        fun classify(rings: List<Ring>): List<List<Ring>> {
            val polygons = ArrayList<MutableList<Ring>>()
            var outerIsNegative: Boolean? = null
            for (ring in rings) {
                if (ring.pointCount < 3) continue
                val area = signedArea(ring)
                if (area == 0f) continue
                if (outerIsNegative == null) outerIsNegative = area < 0
                if ((area < 0) == outerIsNegative || polygons.isEmpty()) {
                    polygons.add(mutableListOf(ring))
                } else {
                    polygons.last().add(ring)
                }
            }
            return polygons
        }

        fun signedArea(ring: Ring): Float {
            var sum = 0f
            val n = ring.pointCount
            var j = n - 1
            for (i in 0 until n) {
                sum += (ring[2 * j] - ring[2 * i]) * (ring[2 * i + 1] + ring[2 * j + 1])
                j = i
            }
            return sum
        }

        /** Whether a ring's last point repeats its first. */
        fun closes(ring: Ring): Boolean =
            ring[0] == ring[ring.size - 2] && ring[1] == ring[ring.size - 1]
    }
}

internal enum class LineJoin { MITER, BEVEL, ROUND;
    companion object {
        fun of(s: String?) = when (s) { "bevel" -> BEVEL; "round" -> ROUND; else -> MITER }
    }
}

internal enum class LineCap { BUTT, SQUARE, ROUND;
    companion object {
        fun of(s: String?) = when (s) { "square" -> SQUARE; "round" -> ROUND; else -> BUTT }
    }
}

/** Triangles for a line layer: x, y, extrude x, extrude y, distance along the line per vertex. */
internal class LineGeometry {
    val vertices = FloatList(1024)
    val indices = IntList(1024)

    val isEmpty: Boolean get() = indices.size == 0

    private val vertexCount: Int get() = vertices.size / FLOATS_PER_VERTEX

    private fun vertex(px: Float, py: Float, ex: Float, ey: Float, distance: Float): Int {
        val index = vertexCount
        vertices.add(px); vertices.add(py); vertices.add(ex); vertices.add(ey); vertices.add(distance)
        return index
    }

    /** Scratch space for a line's de-duplicated points and distances, reused between lines. */
    private var px = FloatArray(64)
    private var py = FloatArray(64)
    private var distances = FloatArray(65)

    /** Adds a line. Closed rings (first point repeated at the end) get a join instead of caps. */
    fun add(line: Ring, join: LineJoin, cap: LineCap, miterLimit: Float) {
        val raw = line.pointCount
        if (px.size < raw) { px = FloatArray(raw * 2); py = FloatArray(raw * 2); distances = FloatArray(raw * 2 + 1) }
        var n = 0
        for (i in 0 until raw) {
            val x = line[2 * i]; val y = line[2 * i + 1]
            if (n > 0 && px[n - 1] == x && py[n - 1] == y) continue
            px[n] = x; py[n] = y; n++
        }
        if (n < 2) return
        val closed = n > 2 && px[0] == px[n - 1] && py[0] == py[n - 1]
        if (closed) n--
        val segmentCount = if (closed) n else n - 1

        distances[0] = 0f
        for (i in 0 until segmentCount) {
            val j = (i + 1) % n
            distances[i + 1] = distances[i] + hypot(px[j] - px[i], py[j] - py[i])
        }

        // One quad per segment, with butt ends.
        for (i in 0 until segmentCount) {
            val j = (i + 1) % n
            val ax = px[i]; val ay = py[i]; val bx = px[j]; val by = py[j]
            val len = hypot(bx - ax, by - ay)
            val dx = (bx - ax) / len; val dy = (by - ay) / len
            val nx = -dy; val ny = dx
            val da = distances[i]; val db = distances[i + 1]
            val v0 = vertex(ax, ay, nx, ny, da); val v1 = vertex(ax, ay, -nx, -ny, da)
            val v2 = vertex(bx, by, nx, ny, db); val v3 = vertex(bx, by, -nx, -ny, db)
            indices.add(v0, v1, v2, v1, v3, v2)
        }

        // Joins fill the wedge on the outside of each bend.
        if (n > 2 || closed) {
            val first = if (closed) 0 else 1
            val last = if (closed) n else max(n - 1, 1)
            for (i in first until last) {
                val pi = (i - 1 + n) % n; val ni = (i + 1) % n
                val x = px[i]; val y = py[i]
                val l1 = hypot(x - px[pi], y - py[pi]); val l2 = hypot(px[ni] - x, py[ni] - y)
                val d1x = (x - px[pi]) / l1; val d1y = (y - py[pi]) / l1
                val d2x = (px[ni] - x) / l2; val d2y = (py[ni] - y) / l2
                val turn = d1x * d2y - d1y * d2x
                if (!(abs(turn) > 1e-6f || d1x * d2x + d1y * d2y < 0)) continue
                // The outer side is opposite the turn direction.
                val side = if (turn > 0) -1f else 1f
                val o1x = -d1y * side; val o1y = d1x * side
                val o2x = -d2y * side; val o2y = d2x * side
                val distance = distances[i]
                val center = vertex(x, y, 0f, 0f, distance)
                when (join) {
                    LineJoin.ROUND -> addFan(center, x, y, o1x, o1y, o2x, o2y, false, 0f, 0f, distance)
                    LineJoin.MITER, LineJoin.BEVEL -> {
                        var bx = o1x + o2x; var by = o1y + o2y
                        val bl = hypot(bx, by)
                        bx /= bl; by /= bl
                        val cosHalf = bx * o1x + by * o1y
                        val miterLength = if (cosHalf > 1e-4f) 1 / cosHalf else Float.POSITIVE_INFINITY
                        val a = vertex(x, y, o1x, o1y, distance); val b = vertex(x, y, o2x, o2y, distance)
                        if (join == LineJoin.MITER && miterLength <= miterLimit) {
                            val m = vertex(x, y, bx * miterLength, by * miterLength, distance)
                            indices.add(center, a, m, center, m, b)
                        } else {
                            indices.add(center, a, b)
                        }
                    }
                }
            }
        }

        if (closed || cap == LineCap.BUTT) return
        for (start in booleanArrayOf(true, false)) {
            val e = if (start) 0 else n - 1
            val o = if (start) 1 else n - 2
            val ex = px[e]; val ey = py[e]
            val l = hypot(ex - px[o], ey - py[o])
            val dx = (ex - px[o]) / l; val dy = (ey - py[o]) / l
            val nx = -dy; val ny = dx
            val distance = if (start) distances[0] else distances[segmentCount]
            if (cap == LineCap.SQUARE) {
                val v0 = vertex(ex, ey, nx, ny, distance); val v1 = vertex(ex, ey, -nx, -ny, distance)
                val v2 = vertex(ex, ey, nx + dx, ny + dy, distance)
                val v3 = vertex(ex, ey, -nx + dx, -ny + dy, distance)
                indices.add(v0, v1, v2, v1, v3, v2)
            } else {
                val center = vertex(ex, ey, 0f, 0f, distance)
                addFan(center, ex, ey, nx, ny, -nx, -ny, true, dx, dy, distance)
            }
        }
    }

    /**
     * A triangle fan around `center` sweeping from one unit vector to another (the short way, or
     * through `through` when given, for half circles).
     */
    private fun addFan(center: Int, x: Float, y: Float, ax: Float, ay: Float, bx: Float, by: Float, hasThrough: Boolean,
                       tx: Float, ty: Float, distance: Float) {
        val start = atan2(ay, ax)
        var sweep = atan2(by, bx) - start
        val twoPi = (2 * PI).toFloat()
        if (hasThrough) {
            // Choose the direction that passes through (tx, ty).
            var m = atan2(ty, tx) - start
            while (m < 0) m += twoPi
            if (sweep < 0) sweep += twoPi
            if (m > sweep) sweep -= twoPi
        } else {
            while (sweep > PI) sweep -= twoPi
            while (sweep < -PI) sweep += twoPi
        }
        val steps = max(2, ceil(abs(sweep) / (PI / 8)).toInt())
        var previous = vertex(x, y, ax, ay, distance)
        for (s in 1..steps) {
            val angle = start + sweep * s / steps
            val next = vertex(x, y, cos(angle), sin(angle), distance)
            indices.add(center, previous, next)
            previous = next
        }
    }

    companion object {
        const val FLOATS_PER_VERTEX = 5
        private fun hypot(x: Float, y: Float) = sqrt(x * x + y * y)
    }
}
