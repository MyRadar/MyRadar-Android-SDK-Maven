package com.acmeaom.myradar.sdk.internal

/**
 * The preference keys behind the public API. The strings are the old engine's names, kept so apps
 * that set them through the deprecated `setAdvancedPreference` keep working; they match the iOS
 * SDK's `EngineKeys`.
 */
internal object EngineKeys {
    // Base map
    const val MAP_TILE_TYPE = "kMapTileType2Key"

    // Weather animation (radar)
    const val WEATHER_ANIMATION_STATUS = "kWeatherAnimationStatusKey"
    const val WEATHER_ANIMATION_TYPE = "kWeatherAnimationTypeKey"
    const val WEATHER_ANIMATION_SCRUBBER_STATUS = "kWeatherAnimationScrubberStatusKey"
    const val WEATHER_ANIMATION_SCRUBBER = "kWeatherAnimationScrubberKey"
    /** Predicted frames after the latest scan; the old engine's key, so apps that set it keep working. */
    const val FUTURE_RADAR = "kFutureRadarStatus2Key"
    /** Playback speed as a multiple of the default (SDK-only). */
    const val WEATHER_ANIMATION_SPEED = "kMyRadarAnimationSpeedKey"
    /** [com.acmeaom.myradar.sdk.RadarTransition] ordinal (SDK-only). */
    const val WEATHER_ANIMATION_TRANSITION = "kMyRadarAnimationTransitionKey"

    // Per-product opacity keys
    const val MORPH_RADAR_OPACITY = "kWeatherAnimationMorphRadarOpacityKey"
    const val HD_RADAR_OPACITY = "kWeatherAnimationHdRadarOpacityKey"
    const val SD_RADAR_OPACITY = "kWeatherAnimationSdRadarOpacityKey"

    // Per-product loop length keys (minutes of history shown per loop)
    const val MORPH_RADAR_LOOP_LENGTH = "kWeatherAnimationMorphRadarLoopLengthKey"
    const val HD_RADAR_LOOP_LENGTH = "kWeatherAnimationHdRadarLoopLengthKey"
    const val SD_RADAR_LOOP_LENGTH = "kWeatherAnimationSdRadarLoopLengthKey"

    // Lightning
    const val LIGHTNING_MARKERS_STATUS = "kLightningMarkersStatusKey"
    const val LIGHTNING_EFFECT_STATUS = "kLightningEffectStatusKey"

    // Watches / warnings
    const val WARNINGS_STATUS = "kWarningsStatusKey"
    const val WARNINGS_ENABLED_TAGS = "kWarningsEnabledTags4Key"
    const val WARNINGS_ALPHA = "kWarningsAlphaKey" // default 0.4
    const val WATCHES_ALPHA = "kWatchesAlphaKey" // default 0.2

    // Overlay opacity (defaults 0.65)
    const val HURRICANES_OPACITY = "kHurricanesOpacityKey"
    const val WIND_OPACITY = "kWindOpacityKey"

    // Hurricanes: each element of the storm graphics behind its own key.
    const val HURRICANES_STATUS = "kHurricanesStatusKey"
    const val HURRICANES_TRACK_ENABLED = "kHurricanesTrackEnabledKey"
    const val HURRICANES_PAST_TRACK_ENABLED = "kHurricanesPastTrackEnabledKey"
    const val HURRICANES_CONE_ENABLED = "kHurricanesConeEnabledKey"
    const val HURRICANES_STORM_CENTER_ENABLED = "kHurricanesStormCenterEnabledKey"

    // Wind particles
    const val WIND_STATUS = "kWindStatusKey"


    /**
     * National Weather Service watch, warning and advisory tags.
     *
     * The engine default also includes Australian and French alerts plus the NWS Special
     * Weather Statement and Hazardous Weather Outlook feeds, each of which costs an extra network
     * poll. The SDK narrows the default to NWS weather products only; hosts can widen it with
     * [com.acmeaom.myradar.sdk.MyRadarMapView.setAdvancedPreference].
     */
    val defaultWarningsTags: String = listOf(
        "nws.av.a", "nws.av.w", "nws.bz.a", "nws.bz.w", "nws.ds.w", "nws.du.w", "nws.du.y",
        "nws.eh.a", "nws.eh.w", "nws.fa.a", "nws.fa.w", "nws.ff.a", "nws.ff.w", "nws.fg.y",
        "nws.fl.a", "nws.fl.w", "nws.fw.a", "nws.fw.w", "nws.gl.a", "nws.gl.w", "nws.hi.a",
        "nws.hi.w", "nws.ht.y", "nws.hu.a", "nws.hu.w", "nws.hw.a", "nws.hw.w", "nws.hz.a",
        "nws.hz.w", "nws.is.w", "nws.le.a", "nws.le.w", "nws.ma.w", "nws.rp.s", "nws.ss.a",
        "nws.ss.w", "nws.su.w", "nws.su.y", "nws.sv.a", "nws.sv.w", "nws.ti.a", "nws.ti.w",
        "nws.to.a", "nws.to.w", "nws.tr.a", "nws.tr.w", "nws.ts.a", "nws.ts.w", "nws.ty.a",
        "nws.ty.w", "nws.wc.a", "nws.wc.w", "nws.ws.a", "nws.ws.w", "nws.ww.y", "nws.zf.y",
        "nws.zr.y",
    ).joinToString(",")

    /** The preference values every map view starts with. */
    fun initialValues(): Map<String, Any> = buildMap {
        // Radar on by default: it is the point of this SDK.
        put(WEATHER_ANIMATION_STATUS, true)
        put(WEATHER_ANIMATION_TYPE, 3)
        // NWS products only.
        put(WARNINGS_ENABLED_TAGS, defaultWarningsTags)
        // Hurricanes: the center, tracks and cone.
        put(HURRICANES_TRACK_ENABLED, true)
        put(HURRICANES_PAST_TRACK_ENABLED, true)
        put(HURRICANES_CONE_ENABLED, true)
        put(HURRICANES_STORM_CENTER_ENABLED, true)
    }
}

/** Whether a preference holds an endpoint URL, which apps can't change. */
internal fun EngineKeys.isEndpoint(key: String, value: Any?): Boolean =
    key.contains("Url", ignoreCase = true) || (value as? String)?.let { "://" in it } == true
