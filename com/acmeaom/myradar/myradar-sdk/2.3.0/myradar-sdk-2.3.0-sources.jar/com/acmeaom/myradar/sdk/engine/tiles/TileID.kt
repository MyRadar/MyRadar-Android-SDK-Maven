package com.acmeaom.myradar.sdk.engine.tiles

import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.ScreenPoint
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * A tile in the XYZ scheme (y down from the north). `wrap` counts whole worlds east of the
 * primary one, so a view across the date line can draw the same tile twice.
 */
internal data class TileID(val z: Int, val x: Int, val y: Int, val wrap: Int = 0) : Comparable<TileID> {
    /** The same tile in the primary world, which is how tiles are fetched and cached. */
    val canonical: TileID get() = if (wrap == 0) this else TileID(z, x, y)

    val parent: TileID? get() = if (z > 0) TileID(z - 1, x shr 1, y shr 1, wrap) else null

    fun ancestor(atZoom: Int): TileID {
        if (atZoom >= z) return this
        val shift = z - atZoom
        return TileID(atZoom, x shr shift, y shr shift, wrap)
    }

    val children: List<TileID>
        get() {
            val cx = x * 2; val cy = y * 2
            return listOf(TileID(z + 1, cx, cy, wrap), TileID(z + 1, cx + 1, cy, wrap),
                TileID(z + 1, cx, cy + 1, wrap), TileID(z + 1, cx + 1, cy + 1, wrap))
        }

    /** Fills a URL template's `{z}`, `{x}` and `{y}`. */
    fun url(template: String): String =
        template.replace("{z}", z.toString()).replace("{x}", x.toString()).replace("{y}", y.toString())

    override fun compareTo(other: TileID): Int =
        compareValuesBy(this, other, { it.z }, { it.wrap }, { it.y }, { it.x })
}

internal object TileCover {
    /** Tiles at zoom `z` that intersect the viewport, nearest the center first. */
    fun tiles(transform: MapTransform, z: Int, limit: Int = 128): List<TileID> {
        val n = (1 shl z).toDouble()
        val projection = transform.projectionMatrix
        val w = transform.width; val h = transform.height
        // The viewport's corners on the map, in tile units. When the top of a tilted view is
        // above the horizon, walk the corner down until it reaches the ground.
        val step = max(h / 20, 1.0)
        var corners = mutableListOf<Vec2>()
        for ((cx, cy) in listOf(0.0 to 0.0, w to 0.0, w to h, 0.0 to h)) {
            var y = cy
            var point: Vec2? = null
            while (point == null && y <= h) {
                point = transform.mercatorAt(ScreenPoint(cx, y), projection)
                y += step
            }
            if (point != null) corners.add(point * n)
        }
        if (corners.size < 3) return emptyList()
        // Unwrap longitudes around the center so a view across the date line stays contiguous.
        val centerX = transform.center.x * n
        corners = corners.map { c ->
            var x = c.x
            while (x - centerX > n / 2) x -= n
            while (centerX - x > n / 2) x += n
            Vec2(x, c.y)
        }.toMutableList()
        val minX = floor(corners.minOf { it.x }).toInt()
        val maxX = floor(corners.maxOf { it.x }).toInt()
        val minY = max(floor(corners.minOf { it.y }).toInt(), 0)
        val maxY = min(floor(corners.maxOf { it.y }).toInt(), n.toInt() - 1)
        if (minY > maxY) return emptyList()

        val center = Vec2(centerX, transform.center.y * n)
        val result = ArrayList<Pair<TileID, Double>>()
        for (ty in minY..maxY) for (tx in minX..maxX) {
            if (!intersects(corners, tx.toDouble(), ty.toDouble())) continue
            val wrap = floor(tx / n).toInt()
            val x = tx - wrap * n.toInt()
            val d = (Vec2(tx + 0.5, ty + 0.5) - center).length
            result.add(TileID(z, x, ty, wrap) to d)
        }
        result.sortBy { it.second }
        return result.take(limit).map { it.first }
    }

    /** Whether a convex polygon intersects the unit square at (tileX, tileY), by separating axes. */
    private fun intersects(polygon: List<Vec2>, tileX: Double, tileY: Double): Boolean {
        val square = listOf(Vec2(tileX, tileY), Vec2(tileX + 1, tileY), Vec2(tileX + 1, tileY + 1), Vec2(tileX, tileY + 1))
        val axes = mutableListOf(Vec2(1.0, 0.0), Vec2(0.0, 1.0))
        for (i in polygon.indices) {
            val e = polygon[(i + 1) % polygon.size] - polygon[i]
            axes.add(Vec2(-e.y, e.x))
        }
        for (axis in axes) {
            val a = polygon.map { it.dot(axis) }
            val b = square.map { it.dot(axis) }
            if (a.max() < b.min() || b.max() < a.min()) return false
        }
        return true
    }
}
