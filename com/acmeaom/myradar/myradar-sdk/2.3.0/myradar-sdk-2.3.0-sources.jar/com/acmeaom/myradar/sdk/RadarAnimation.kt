package com.acmeaom.myradar.sdk

import androidx.annotation.MainThread
import com.acmeaom.myradar.sdk.internal.PreferenceStore
import com.acmeaom.myradar.sdk.internal.EngineKeys
import java.util.Date

/**
 * Controls the animated weather (radar) layer of a [MyRadarMapView].
 *
 * Access through [MyRadarMapView.radar]:
 * ```kotlin
 * mapView.radar.isEnabled = true
 * mapView.radar.pause()
 * mapView.radar.scrubberPosition = 0.5f
 * ```
 */
@MainThread
public class RadarAnimation internal constructor(private val preferences: PreferenceStore) {

    // MARK: Layer state

    /** Whether the weather animation layer is displayed. Defaults to `true`. */
    public var isEnabled: Boolean
        get() = preferences.bool(EngineKeys.WEATHER_ANIMATION_STATUS, default = true)
        set(value) = preferences.set(EngineKeys.WEATHER_ANIMATION_STATUS, value)

    /** The weather product being animated. Defaults to [RadarProduct.Radar]. */
    public var product: RadarProduct
        get() = RadarProduct.fromEngineValue(
            preferences.int(EngineKeys.WEATHER_ANIMATION_TYPE, RadarProduct.Radar.engineValue),
        ) ?: RadarProduct.Radar
        set(value) = preferences.set(EngineKeys.WEATHER_ANIMATION_TYPE, value.engineValue)

    /** Layer opacity in `0..1` for the current [product]. Defaults to `0.65`. */
    public var opacity: Float
        get() = preferences.float(product.opacityPreferenceKey, default = 0.65f)
        set(value) = preferences.set(product.opacityPreferenceKey, value.coerceIn(0f, 1f))

    /**
     * How far back the loop goes, in minutes, for the current [product]; `null` uses the product's
     * default (100 minutes for [RadarProduct.Radar], 60 for the others).
     *
     * Frames are 5 minutes apart, so this sets the number of frames: 30 minutes plays 6 frames, 120
     * minutes (the most) plays 24. Values are kept to `5..120`. Each product keeps its own length,
     * so set this after choosing [product].
     */
    public var loopLengthMinutes: Int?
        get() = (preferences.value(product.loopLengthPreferenceKey) as? Number)?.toInt()
        set(value) = preferences.set(product.loopLengthPreferenceKey, value?.coerceIn(5, 120))

    /**
     * Whether the loop continues past the latest radar scan with 10 predicted frames (50 minutes),
     * where predictions are available: the United States and Australia, with [RadarProduct.Radar].
     * Elsewhere, and with other products, the loop ends at the latest scan. Predicted frames are
     * computed on the device from the latest scan and the storm motion. Defaults to `false`.
     */
    public var showsFutureRadar: Boolean
        get() = preferences.bool(EngineKeys.FUTURE_RADAR, default = false)
        set(value) = preferences.set(EngineKeys.FUTURE_RADAR, value)

    // MARK: Playback

    /**
     * How fast the loop plays, as a multiple of the default speed: `0.5` takes twice as long per
     * frame, `2` half as long. Kept to `0.1..4`. Defaults to `1`. The pause on the latest frame
     * lengthens and shortens with it.
     */
    public var speed: Float
        get() = preferences.float(EngineKeys.WEATHER_ANIMATION_SPEED, default = 1f)
        set(value) = preferences.set(EngineKeys.WEATHER_ANIMATION_SPEED, value.coerceIn(0.1f, 4f))

    /**
     * How the loop moves from one frame to the next: blending smoothly along the storms' motion
     * ([RadarTransition.Morph], the default) or switching frames outright ([RadarTransition.Step]).
     * [RadarProduct.StandardDefinitionRadar] always steps.
     */
    public var transition: RadarTransition
        get() = RadarTransition.entries.getOrNull(preferences.int(EngineKeys.WEATHER_ANIMATION_TRANSITION, 0))
            ?: RadarTransition.Morph
        set(value) = preferences.set(EngineKeys.WEATHER_ANIMATION_TRANSITION, value.ordinal)

    /**
     * Whether the animation timeline is advancing. Defaults to `true`.
     *
     * When paused, the frame indicated by [scrubberPosition] stays on screen.
     */
    public var isPlaying: Boolean
        get() = !preferences.bool(EngineKeys.WEATHER_ANIMATION_SCRUBBER_STATUS, default = false)
        set(value) = preferences.set(EngineKeys.WEATHER_ANIMATION_SCRUBBER_STATUS, !value)

    /** Resumes the animation. */
    public fun play() {
        isPlaying = true
    }

    /** Pauses the animation on the current frame. */
    public fun pause() {
        isPlaying = false
    }

    /**
     * Position of the timeline scrubber in `0..1`, where `1` is the most recent frame.
     *
     * Setting this pauses the animation and jumps to the requested frame. While the animation
     * is playing, this reflects the engine-reported playhead.
     */
    public var scrubberPosition: Float
        get() = reportedScrubberPosition
        set(value) {
            val clamped = value.coerceIn(0f, 1f)
            reportedScrubberPosition = clamped
            if (isPlaying) pause()
            preferences.set(EngineKeys.WEATHER_ANIMATION_SCRUBBER, clamped)
        }

    /** The timestamp of the radar frame currently displayed, or `null` while loading. */
    public var currentFrameDate: Date? = null
        internal set

    /** Latest playhead position reported by the engine. */
    internal var reportedScrubberPosition: Float = 1f
}

/** How the radar loop moves between frames. See [RadarAnimation.transition]. */
public enum class RadarTransition {
    /** Each frame blends into the next, following the storms' motion where it's known. */
    Morph,
    /** Each frame replaces the last outright, as a classic radar loop. */
    Step,
}
