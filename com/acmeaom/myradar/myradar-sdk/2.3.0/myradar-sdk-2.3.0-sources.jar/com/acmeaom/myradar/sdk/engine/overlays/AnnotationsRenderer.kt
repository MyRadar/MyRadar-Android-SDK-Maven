package com.acmeaom.myradar.sdk.engine.overlays

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.DisplayMetrics
import com.acmeaom.myradar.sdk.MapMarker
import com.acmeaom.myradar.sdk.MapPolygon
import com.acmeaom.myradar.sdk.MapPolyline
import com.acmeaom.myradar.sdk.engine.EngineAssets
import com.acmeaom.myradar.sdk.engine.MapEngineView
import com.acmeaom.myradar.sdk.engine.basemap.RGBA
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.ScreenPoint
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import com.acmeaom.myradar.sdk.engine.gl.GPUTexture
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * The host's polygons, polylines and markers (and the flight being shown, which arrives as
 * polylines and markers). Drawn the way the engine's local GeoJSON layer drew the documents the
 * SDK used to encode for it (`FWGeoJsonModule`):
 *
 * - Polygons: the fill color, then an optional outline of `strokeWidthDp` points.
 * - Polylines: an optional opaque outline 2 points wider, under the stroke, which may be dashed
 *   (the pattern in points). Earlier polylines draw on top, as lower engine weights do.
 * - Markers: asset images and runtime images at their dp size; text in Inter SemiBold at 15pt
 *   with a 3pt halo fading from black. Headings rotate the icon clockwise from true north. New
 *   markers fade in over 0.45 seconds like engine stamps; earlier markers draw on top.
 *
 * Polygons draw beneath polylines and markers, as the SDK documents.
 *
 * Hit testing follows the engine: markers by their image bounds, polylines within an 8 point
 * touch radius of the line, polygons when the touch is inside.
 *
 * Main thread only (textures and meshes are made as content arrives).
 */
internal class AnnotationsRenderer(context: Context) {
    private val appContext: Context = context.applicationContext ?: context

    var onNeedsDisplay: (() -> Unit)? = null

    var polygons: List<MapPolygon> = emptyList(); private set
    var polylines: List<MapPolyline> = emptyList(); private set
    var markers: List<MapMarker> = emptyList(); private set

    private var polygonShapes: MercatorShapes? = null
    private var polylineShapes: List<Pair<MercatorShapes, List<Float>>> = emptyList()
    private var markerSprites: List<MarkerSprite> = emptyList()
    private val markerFirstSeen = HashMap<String, Double>()
    private val iconCache = HashMap<IconKey, SpriteImage>()
    private val textureCache = HashMap<IconKey, GPUTexture>()

    private class MarkerSprite(val id: String, val sprite: Sprite, val heading: Double?)

    /** Multiplies the size of text markers. */
    var textScale: Float = 1f
        set(value) {
            if (value == field) return
            field = value
            for (key in textureCache.keys.filter { it is IconKey.Text }) {
                textureCache.remove(key); iconCache.remove(key)
            }
            setMarkers(markers)
        }

    private sealed class IconKey {
        data class Asset(val name: String) : IconKey()
        class Image(val bitmap: Bitmap) : IconKey() {
            override fun equals(other: Any?) = other is Image && other.bitmap === bitmap
            override fun hashCode() = System.identityHashCode(bitmap)
        }
        data class Text(val text: String, val color: Int) : IconKey()
    }

    // MARK: Content

    fun setShapes(polygons: List<MapPolygon>, polylines: List<MapPolyline>) {
        this.polygons = polygons
        this.polylines = polylines

        var builder: MercatorShapeBuilder? = null
        for (polygon in polygons) {
            if (polygon.coordinates.size < 3) continue
            val ring = polygon.coordinates.map(MapTransform::mercator)
            val b = builder ?: MercatorShapeBuilder(ring[0]).also { builder = it }
            b.addFill(listOf(ring), premultiplied(polygon.fillColor))
            polygon.strokeColor?.let { stroke ->
                b.addLine(ring, polygon.strokeWidthDp, premultiplied(stroke), closed = true)
            }
        }
        polygonShapes = builder?.takeIf { !it.isEmpty }?.let(::MercatorShapes)

        // Back to front: the last polyline first.
        polylineShapes = polylines.asReversed().mapNotNull { line ->
            if (line.coordinates.size < 2) return@mapNotNull null
            val points = unwrapped(line.coordinates.map(MapTransform::mercator))
            val b = MercatorShapeBuilder(points[0])
            line.outlineColor?.let { outline ->
                // The engine only supports opaque outlines.
                b.addLine(points, line.widthDp + 2, premultiplied(outline or OPAQUE))
            }
            val dash = line.dashPattern ?: emptyList()
            b.addLine(points, line.widthDp, premultiplied(line.color), dashed = dash.isNotEmpty())
            if (b.isEmpty) null else MercatorShapes(b) to dash
        }
        onNeedsDisplay?.invoke()
    }

    fun setMarkers(markers: List<MapMarker>) {
        this.markers = markers
        val now = MapEngineView.nowSeconds()
        val scale = EngineAssets.density
        val seen = HashSet<String>()
        // Back to front: the last marker first.
        markerSprites = markers.asReversed().mapNotNull { marker ->
            if (!marker.coordinate.isValid) return@mapNotNull null
            val (texture, image) = icon(marker.icon, scale) ?: return@mapNotNull null
            seen.add(marker.id)
            markerFirstSeen.getOrPut(marker.id) { now }
            val sprite = Sprite(texture, MapTransform.mercator(marker.coordinate), image.width, image.height)
            MarkerSprite(marker.id, sprite, marker.heading)
        }
        markerFirstSeen.keys.retainAll(seen)
        onNeedsDisplay?.invoke()
    }

    private fun icon(icon: MapMarker.Icon, scale: Float): Pair<GPUTexture, SpriteImage>? {
        val key = when (icon) {
            is MapMarker.Icon.Asset -> IconKey.Asset(icon.name)
            is MapMarker.Icon.Image -> IconKey.Image(icon.bitmap)
            is MapMarker.Icon.Text -> IconKey.Text(icon.text, icon.color)
        }
        val cachedTexture = textureCache[key]
        val cachedImage = iconCache[key]
        if (cachedTexture != null && cachedImage != null) return cachedTexture to cachedImage
        val image = when (icon) {
            is MapMarker.Icon.Asset -> loadAsset(icon.name)?.let { (bitmap, w, h) -> render(bitmap, w, h, scale) }
            is MapMarker.Icon.Image -> bitmapSize(icon.bitmap)?.let { (w, h) -> render(icon.bitmap, w, h, scale) }
            is MapMarker.Icon.Text -> textLabel(icon.text, icon.color, scale, textScale)
        } ?: return null
        val texture = image.texture() ?: return null
        // Runtime images come and go with moving markers; keep the cache small.
        if (textureCache.size > 64) {
            textureCache.clear(); iconCache.clear()
        }
        textureCache[key] = texture
        iconCache[key] = image
        return texture to image
    }

    /**
     * An image packaged with the app, as [MapMarker.Icon.Asset] documents the lookup: an asset
     * file (`name`, `name@2x.png`, `name.png`), then a drawable resource. Returns the bitmap and
     * its size in dp.
     */
    private fun loadAsset(name: String): Triple<Bitmap, Float, Float>? {
        for (file in listOf(name, "$name@2x.png", "$name.png")) {
            val bitmap = runCatching {
                appContext.assets.open(file).use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inScaled = false })
                }
            }.getOrNull() ?: continue
            // An "@3x" style suffix gives the scale; otherwise the engine's image scale, 2.
            val fileScale = Regex("@(\\d+(?:\\.\\d+)?)x").find(file)?.groupValues?.get(1)?.toFloatOrNull()
                ?: ASSET_SCALE
            return Triple(bitmap, bitmap.width / fileScale, bitmap.height / fileScale)
        }
        val resources = appContext.resources
        @Suppress("DiscouragedApi")
        val id = resources.getIdentifier(name, "drawable", appContext.packageName)
        if (id == 0) return null
        val drawable = runCatching { resources.getDrawable(id, appContext.theme) }.getOrNull() ?: return null
        val w = drawable.intrinsicWidth; val h = drawable.intrinsicHeight
        if (w <= 0 || h <= 0) return null
        // Intrinsic sizes are in device pixels.
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        drawable.setBounds(0, 0, w, h)
        drawable.draw(Canvas(bitmap))
        val density = resources.displayMetrics.density
        return Triple(bitmap, w / density, h / density)
    }

    // MARK: Drawing

    /** Polygons and polylines, with the other map shapes (above the radar). */
    fun drawShapes(context: RenderContext) {
        polygonShapes?.draw(context)
        for ((shapes, dash) in polylineShapes) shapes.draw(context, dash = dash)
    }

    /** Markers, among the map stamps. Returns true while a new marker is fading in. */
    fun drawMarkers(context: RenderContext): Boolean {
        if (markerSprites.isEmpty()) return false
        val now = context.now
        val mapHeading = context.transform.heading
        var fading = false
        val sprites = markerSprites.map { entry ->
            var sprite = entry.sprite
            entry.heading?.let { heading ->
                // Clockwise from north on the map; sprite rotations are counterclockwise on screen.
                sprite = sprite.copy(rotation = (-(heading - mapHeading) * PI / 180).toFloat())
            }
            val age = now - (markerFirstSeen[entry.id] ?: 0.0)
            val alpha = (age / 0.45).coerceIn(0.0, 1.0).toFloat()
            if (alpha < 1) fading = true
            sprite.copy(alpha = alpha)
        }
        SpriteDrawer.draw(context, sprites)
        return fading
    }

    // MARK: Hit testing

    sealed class Hit {
        data class Marker(val marker: MapMarker) : Hit()
        data class Polyline(val polyline: MapPolyline) : Hit()
        data class Polygon(val polygon: MapPolygon) : Hit()
    }

    /**
     * Everything under a screen point (dp), topmost first within each kind: markers, polylines,
     * polygons.
     */
    fun hits(point: ScreenPoint, transform: MapTransform): List<Hit> {
        val result = ArrayList<Hit>()
        val projection = transform.projectionMatrix
        for (marker in markers) {
            val entry = markerSprites.firstOrNull { it.id == marker.id } ?: continue
            val sprite = entry.sprite
            for (wrap in WRAPS) {
                val p = transform.screenPoint(sprite.position + Vec2(wrap, 0.0), projection) ?: continue
                if (abs(point.x - p.x) <= sprite.width / 2 && abs(point.y - p.y) <= sprite.height / 2) {
                    result.add(Hit.Marker(marker))
                    break
                }
            }
        }
        for (line in polylines) {
            if (line.coordinates.size < 2) continue
            val points = unwrapped(line.coordinates.map(MapTransform::mercator))
            var hit = false
            for (wrap in WRAPS) {
                if (hit) break
                val screen = points.map { transform.screenPoint(it + Vec2(wrap, 0.0), projection) }
                for (i in 1 until screen.size) {
                    val a = screen[i - 1] ?: continue
                    val b = screen[i] ?: continue
                    if (distance(point, a, b) <= TOUCH_RADIUS) {
                        hit = true; break
                    }
                }
            }
            if (hit) result.add(Hit.Polyline(line))
        }
        transform.mercatorAt(point, projection)?.let { m ->
            for (polygon in polygons) {
                if (polygon.coordinates.size < 3) continue
                val ring = polygon.coordinates.map(MapTransform::mercator)
                if (WRAPS.any { contains(ring, m + Vec2(it, 0.0)) }) result.add(Hit.Polygon(polygon))
            }
        }
        return result
    }

    companion object {
        private val WRAPS = doubleArrayOf(-1.0, 0.0, 1.0)
        private const val TOUCH_RADIUS = 8.0
        private const val OPAQUE = 0xFF shl 24
        /** Asset images without a scale suffix are read at the engine's image scale. */
        private const val ASSET_SCALE = 2f

        /** Distance from `p` to the segment `a`–`b`. */
        fun distance(p: ScreenPoint, a: ScreenPoint, b: ScreenPoint): Double {
            val dx = b.x - a.x; val dy = b.y - a.y
            val lengthSquared = dx * dx + dy * dy
            var t = 0.0
            if (lengthSquared > 0) t = max(0.0, min(1.0, ((p.x - a.x) * dx + (p.y - a.y) * dy) / lengthSquared))
            val cx = a.x + t * dx; val cy = a.y + t * dy
            return hypot(p.x - cx, p.y - cy)
        }

        /** Even-odd point in polygon, in Web Mercator. */
        fun contains(ring: List<Vec2>, p: Vec2): Boolean {
            var inside = false
            var j = ring.size - 1
            for (i in ring.indices) {
                val a = ring[i]; val b = ring[j]
                if ((a.y > p.y) != (b.y > p.y) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) inside = !inside
                j = i
            }
            return inside
        }

        // MARK: Helpers

        /**
         * Keeps consecutive points within half a world of each other, so lines crossing the
         * antimeridian take the short way.
         */
        fun unwrapped(points: List<Vec2>): List<Vec2> {
            var previous = points.firstOrNull() ?: return points
            val result = ArrayList<Vec2>(points.size)
            result.add(previous)
            for (k in 1 until points.size) {
                var x = points[k].x
                while (x - previous.x > 0.5) x -= 1
                while (previous.x - x > 0.5) x += 1
                val p = Vec2(x, points[k].y)
                result.add(p)
                previous = p
            }
            return result
        }

        /** An ARGB color int as premultiplied RGBA. */
        fun premultiplied(argb: Int): RGBA {
            val a = (argb ushr 24 and 0xFF) / 255f
            val r = (argb shr 16 and 0xFF) / 255f
            val g = (argb shr 8 and 0xFF) / 255f
            val b = (argb and 0xFF) / 255f
            return RGBA(r * a, g * a, b * a, a)
        }

        /** A bitmap's size in dp; bitmaps without a density are taken to be in device pixels. */
        private fun bitmapSize(bitmap: Bitmap): Pair<Float, Float>? {
            if (bitmap.width <= 0 || bitmap.height <= 0) return null
            val density = bitmap.density.takeIf { it != Bitmap.DENSITY_NONE && it > 0 }
                ?: (EngineAssets.density * DisplayMetrics.DENSITY_DEFAULT).toInt()
            val scale = DisplayMetrics.DENSITY_DEFAULT.toFloat() / density
            return bitmap.width * scale to bitmap.height * scale
        }

        /** An image at its dp size. */
        fun render(bitmap: Bitmap, width: Float, height: Float, scale: Float): SpriteImage? {
            if (width <= 0 || height <= 0) return null
            return SpriteImage.draw(width, height, scale) { canvas ->
                canvas.drawBitmap(bitmap, null, RectF(0f, 0f, width, height), Paint(Paint.FILTER_BITMAP_FLAG))
            }
        }

        /**
         * A text marker (`FWTypography::createLabelBitmap` with the default 15pt size): the text
         * over a halo that fades from black at the glyph edge to clear 3 points out.
         */
        fun textLabel(text: String, color: Int, scale: Float, textScale: Float = 1f): SpriteImage? {
            if (text.isEmpty()) return null
            val t = textScale
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = EngineAssets.interSemiBold
                textSize = 15 * t
            }
            val metrics = paint.fontMetrics
            val ascent = -metrics.ascent; val descent = metrics.descent
            val width = paint.measureText(text)
            val padding = 3 * t
            val w = ceil(width + 2 * padding); val h = ceil(ascent + descent + 2 * padding)
            return SpriteImage.draw(w, h, scale) { canvas ->
                // The halo: progressively wider, fainter strokes of the glyph outlines.
                val halo = Paint(paint).apply {
                    style = Paint.Style.STROKE
                    strokeJoin = Paint.Join.ROUND
                }
                for (step in 3 downTo 1) {
                    halo.color = android.graphics.Color.BLACK
                    halo.alpha = ((4 - step) / 3f * 255).toInt()
                    halo.strokeWidth = step * 2 * t
                    canvas.drawText(text, padding, padding + ascent, halo)
                }
                paint.style = Paint.Style.FILL
                paint.color = color
                canvas.drawText(text, padding, padding + ascent, paint)
            }
        }
    }
}
