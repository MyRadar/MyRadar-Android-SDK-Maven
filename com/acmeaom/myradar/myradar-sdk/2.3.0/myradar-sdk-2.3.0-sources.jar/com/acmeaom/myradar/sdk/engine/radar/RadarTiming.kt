package com.acmeaom.myradar.sdk.engine.radar

import com.acmeaom.myradar.sdk.RadarProduct
import com.acmeaom.myradar.sdk.engine.tiles.TileID
import com.acmeaom.myradar.sdk.internal.GatewayConfiguration
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.floor

// Which radar frames to show and where they come from. Port of the engine's
// `FWWeatherModule::radarTiming` for the SDK's three products, `targetRadarRegion`, and the
// `^` placeholders of `FWModule::formatTemplateUrl` that radar URLs use.
//
// Times are seconds since 1970 (UTC) throughout.

internal enum class RadarRegion { JAPAN, FUTURE_RADAR, NOT_JAPAN }

/** `FWWeatherAnimationLayerClass`, limited to the classes the SDK's products use. */
internal enum class RadarLayerClass {
    /** Pre-colored tiles drawn as they are (SD radar). */
    BITMAP,
    /** Two frames blended in the palette's value space. */
    MORPH,
    /** Morphing, with samples moved along the storm motion where vectors are available. */
    MORPH_ADVECTION_WHERE_AVAILABLE,
}

/** `FWRadarTimingBlendMode`. */
internal enum class RadarBlendMode { ADDITIVE_OVER_DARK_BASEMAP, ALPHA, ANTI_ALIASED_NEAREST_NEIGHBOR }

/** The palette set, from the base map: `FWWeatherModule`'s `_radarPaletteMode`. */
internal enum class RadarPaletteMode { CLASSIFIED_DARK, CLASSIFIED_LIGHT, UNCLASSIFIED }

/** A radar loop's frames and sources. Equality compares what decides the frames, as the engine does. */
internal data class RadarTiming(
    var product: RadarProduct,
    var region: RadarRegion,
    var nominalFrameTimeInterval: Double,
    var observationFrameCount: Int,
    /** Predicted frames after the newest scan (`kFutureRadarFrameCount`), 0 without future radar. */
    var predictionFrameCount: Int = 0,
    var oldestFrame: Double,
    var newestObservationFrame: Double,
    var advectionFrameTimestamp: Double,
    var animationLoopEndTime: Double,
    /** Radar tile URL with `^1` and `^2` filled; `^j` (time) and `^p` (tile) remain. */
    var animationURLFormat: String,
    var layerClass: RadarLayerClass,
    var blendMode: RadarBlendMode,
    var minZoom: Int,
    var maxZoom: Int,
    var paletteName: String,
) {
    /** Observation frame times, newest first, as the engine orders its animation frames. */
    val frameDates: List<Double>
        get() = (0 until observationFrameCount).map { newestObservationFrame - it * nominalFrameTimeInterval }

    /** Predicted frame times, newest first. */
    val predictionDates: List<Double>
        get() = (0 until predictionFrameCount).map {
            newestObservationFrame + (predictionFrameCount - it) * nominalFrameTimeInterval
        }

    override fun equals(other: Any?): Boolean {
        if (other !is RadarTiming) return false
        return product == other.product && region == other.region &&
            observationFrameCount == other.observationFrameCount &&
            newestObservationFrame == other.newestObservationFrame &&
            animationURLFormat == other.animationURLFormat && layerClass == other.layerClass &&
            advectionFrameTimestamp == other.advectionFrameTimestamp && maxZoom == other.maxZoom &&
            paletteName == other.paletteName && predictionFrameCount == other.predictionFrameCount
    }

    override fun hashCode(): Int =
        listOf(product, region, observationFrameCount, newestObservationFrame, animationURLFormat, layerClass,
            advectionFrameTimestamp, maxZoom, paletteName, predictionFrameCount).hashCode()
}

internal object RadarTimingBuilder {
    /** Gateway paths of the radar products, as the engine's URL preferences hold them. */
    val morphRadarURLFormat: String = GatewayConfiguration.endpoint("/v2/ref_d^1^2/^j")
    val unsmoothedRadarURLFormat: String = GatewayConfiguration.endpoint("/v2/ref_d_unsmoothed^1^2/^j")
    val iowaRadarURLFormat: String = GatewayConfiguration.endpoint("/c/tile.py/1.0.0/ridge::USCOMP-N0Q-^j")
    val advectionURLFormat: String = GatewayConfiguration.endpoint("/v2/flow/^j")

    /** Engine preference defaults the SDK doesn't change. */
    const val USE_GLOBAL_RADAR = true
    const val MORPH_RADAR_LOOP_LENGTH_MINUTES = 100
    const val HD_RADAR_LOOP_LENGTH_MINUTES = 60
    const val SD_RADAR_LOOP_LENGTH_MINUTES = 60
    const val HD_RADAR_FRAME_INTERVAL_MINUTES = 5
    const val SD_RADAR_FRAME_INTERVAL_MINUTES = 5
    const val MAX_ZOOM = 9
    const val HI_DEF_MAX_ZOOM = 9
    const val UNSMOOTHED_RADAR_MORPHING_ENABLED = true
    /** `kFutureRadarFrameCount`. */
    const val FUTURE_RADAR_FRAME_COUNT = 10
    /**
     * `AdvectionLayer::_maxZoom`: predicted frames draw from tiles no deeper than this, so a storm's
     * motion over 50 minutes stays within a tile's neighbours.
     */
    const val FUTURE_RADAR_MAX_ZOOM = 7

    fun timing(
        product: RadarProduct,
        region: RadarRegion,
        paletteMode: RadarPaletteMode,
        loopLengthMinutes: Int?,
        futureRadar: Boolean = false,
        now: Double = System.currentTimeMillis() / 1000.0,
    ): RadarTiming {
        val ghe = if (USE_GLOBAL_RADAR) "_syn" else "" // global hydro-meteor estimator
        val japan = if (region == RadarRegion.JAPAN) "_all" else ""
        val maxObservationFrames = 24

        fun japanAdjustedNewestObservationFrame(): Double = when (region) {
            // Per the radar data provider's docs.
            RadarRegion.JAPAN -> roundedDown(10, now - 18 * 60) + 5 * 60
            RadarRegion.FUTURE_RADAR, RadarRegion.NOT_JAPAN -> roundedDown(5, now - 5 * 60)
        }

        val morphPalette = when (paletteMode) {
            RadarPaletteMode.CLASSIFIED_DARK -> "palette_morphing_dark.json"
            RadarPaletteMode.UNCLASSIFIED -> "palette_morphing_no_classification.json"
            RadarPaletteMode.CLASSIFIED_LIGHT -> "palette_morphing_light.json"
        }

        val urlFormat: String
        val loopLength: Int
        val interval: Double
        val newest: Double
        var layerClass = RadarLayerClass.BITMAP
        var blendMode = RadarBlendMode.ADDITIVE_OVER_DARK_BASEMAP
        val paletteName: String
        var maxZoom = -1

        when (product) {
            RadarProduct.StandardDefinitionRadar -> {
                urlFormat = iowaRadarURLFormat
                loopLength = loopLengthMinutes ?: SD_RADAR_LOOP_LENGTH_MINUTES
                interval = SD_RADAR_FRAME_INTERVAL_MINUTES * 60.0
                newest = roundedDown(5, now - 5 * 60)
                paletteName = "palette_classic_radar_n0q.json"
            }
            RadarProduct.HighDefinitionRadar -> {
                // The unsmoothed HD product (the engine's FWWeatherTileTypeUnsmoothedRadar).
                urlFormat = fill(unsmoothedRadarURLFormat, ghe, japan)
                loopLength = loopLengthMinutes ?: HD_RADAR_LOOP_LENGTH_MINUTES
                interval = HD_RADAR_FRAME_INTERVAL_MINUTES * 60.0
                newest = japanAdjustedNewestObservationFrame()
                layerClass = if (UNSMOOTHED_RADAR_MORPHING_ENABLED) RadarLayerClass.MORPH else RadarLayerClass.BITMAP
                blendMode = RadarBlendMode.ANTI_ALIASED_NEAREST_NEIGHBOR
                paletteName = when (paletteMode) {
                    RadarPaletteMode.CLASSIFIED_DARK -> "palette_unsmoothed_dark.json"
                    RadarPaletteMode.UNCLASSIFIED -> "palette_unsmoothed_unclassified.json"
                    RadarPaletteMode.CLASSIFIED_LIGHT -> "palette_unsmoothed_light.json"
                }
            }
            RadarProduct.Radar -> {
                loopLength = loopLengthMinutes ?: MORPH_RADAR_LOOP_LENGTH_MINUTES
                interval = 5 * 60.0
                layerClass = RadarLayerClass.MORPH_ADVECTION_WHERE_AVAILABLE
                urlFormat = fill(morphRadarURLFormat, ghe, japan)
                newest = japanAdjustedNewestObservationFrame()
                paletteName = morphPalette
                maxZoom = HI_DEF_MAX_ZOOM
            }
        }

        // At least one frame, however short the loop asked for.
        val count = minOf(maxOf(loopLength / (interval / 60).toInt(), 1), maxObservationFrames)
        val oldest = newest - (count - 1) * interval
        if (maxZoom == -1) maxZoom = MAX_ZOOM
        // `FWWeatherModule::radarTiming`: future radar runs in its region with the morphing product.
        val predictions =
            if (futureRadar && region == RadarRegion.FUTURE_RADAR && product == RadarProduct.Radar) {
                FUTURE_RADAR_FRAME_COUNT
            } else {
                0
            }
        return RadarTiming(
            product = product, region = region, nominalFrameTimeInterval = interval,
            observationFrameCount = count, predictionFrameCount = predictions, oldestFrame = oldest,
            newestObservationFrame = newest, advectionFrameTimestamp = newest,
            animationLoopEndTime = newest + predictions * 5 * 60.0,
            animationURLFormat = urlFormat, layerClass = layerClass, blendMode = blendMode,
            minZoom = 3, maxZoom = maxZoom, paletteName = paletteName,
        )
    }

    private fun fill(format: String, ghe: String, japan: String): String =
        format.replace("^1", ghe).replace("^2", japan)

    /** `FWDate::roundedDownDate`: down to a whole number of minutes. */
    fun roundedDown(minutes: Int, date: Double): Double {
        val step = minutes * 60.0
        return floor(date / step) * step
    }

    // MARK: Regions

    /** A region box in degrees. */
    data class Box(val north: Double, val west: Double, val south: Double, val east: Double)

    /** `FWWeatherModule`'s region boxes. */
    val japanBox = Box(north = 48.0, west = 120.0, south = 20.0, east = 150.0)
    val usaBox = Box(north = 72.0, west = -169.0, south = 18.0, east = -64.0) // includes Alaska and Hawaii
    val australiaBox = Box(north = -10.0, west = 113.0, south = -44.0, east = 154.0)

    /**
     * `FWWeatherModule::targetRadarRegion`: Japan when it's visible, otherwise the future radar
     * region when the US or Australia is visible.
     */
    fun region(viewNorth: Double, viewWest: Double, viewSouth: Double, viewEast: Double): RadarRegion {
        fun visible(box: Box): Boolean {
            if (!(viewSouth <= box.north && viewNorth >= box.south)) return false
            for (shift in doubleArrayOf(-360.0, 0.0, 360.0)) {
                if (viewWest <= box.east + shift && viewEast >= box.west + shift) return true
            }
            return false
        }
        if (visible(japanBox)) return RadarRegion.JAPAN
        if (visible(usaBox) || visible(australiaBox)) return RadarRegion.FUTURE_RADAR
        return RadarRegion.NOT_JAPAN
    }

    // MARK: URL templates

    private val iowaFormatter: DateTimeFormatter =
        DateTimeFormatter.ofPattern("yyyyMMddHHmm", Locale.US).withZone(ZoneOffset.UTC)

    /** `^j`: the "iowa" timestamp, `YYYYMMDDHHmm` in UTC. */
    fun iowaString(date: Double): String =
        iowaFormatter.format(Instant.ofEpochMilli(floor(date * 1000).toLong()))

    /** Fills `^j` with a time. */
    fun format(template: String, date: Double): String = template.replace("^j", iowaString(date))

    /** Fills `^p` with a tile path. */
    fun format(template: String, tile: TileID): String = template.replace("^p", "${tile.z}/${tile.x}/${tile.y}")
}
