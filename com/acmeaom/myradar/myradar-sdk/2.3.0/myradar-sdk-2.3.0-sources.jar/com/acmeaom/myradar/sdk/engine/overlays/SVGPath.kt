package com.acmeaom.myradar.sdk.engine.overlays

import android.graphics.Path

/**
 * Parses SVG path data with absolute M, L, C and Z commands (all the engine's hurricane icons
 * use), including repeated coordinate sets after a command.
 *
 * Parsing yields plain [Command]s, so it can be checked without a real [Path]; [path] replays
 * them into one.
 */
internal object SVGPath {
    /** One drawing command, in the path's coordinates. */
    sealed class Command {
        data class MoveTo(val x: Float, val y: Float) : Command()
        data class LineTo(val x: Float, val y: Float) : Command()
        data class CubicTo(
            val x1: Float, val y1: Float, val x2: Float, val y2: Float, val x: Float, val y: Float,
        ) : Command()
        object Close : Command()
    }

    fun parse(d: String): List<Command> {
        val tokens = ArrayList<String>()
        val number = StringBuilder()
        fun flush() {
            if (number.isNotEmpty()) {
                tokens.add(number.toString())
                number.setLength(0)
            }
        }
        for (ch in d) {
            if (ch.isLetter() && ch != 'e' && ch != 'E') {
                flush(); tokens.add(ch.toString())
            } else if (ch == ',' || ch == ' ' || ch == '\n' || ch == '\t') {
                flush()
            } else if (ch == '-' && number.isNotEmpty() && !(number.last() == 'e' || number.last() == 'E')) {
                flush(); number.append(ch)
            } else {
                number.append(ch)
            }
        }
        flush()
        val commands = ArrayList<Command>()
        var i = 0
        var command = "M"
        fun next(): Float? {
            val v = tokens.getOrNull(i)?.toDoubleOrNull() ?: return null
            i++
            return v.toFloat()
        }
        while (i < tokens.size) {
            if (tokens[i].toDoubleOrNull() == null) {
                command = tokens[i]
                i++
                if (command == "Z" || command == "z") commands.add(Command.Close)
                continue
            }
            when (command) {
                "M" -> {
                    val x = next() ?: return commands
                    val y = next() ?: return commands
                    commands.add(Command.MoveTo(x, y))
                    command = "L" // further pairs are line-tos
                }
                "L" -> {
                    val x = next() ?: return commands
                    val y = next() ?: return commands
                    commands.add(Command.LineTo(x, y))
                }
                "C" -> {
                    val x1 = next() ?: return commands
                    val y1 = next() ?: return commands
                    val x2 = next() ?: return commands
                    val y2 = next() ?: return commands
                    val x = next() ?: return commands
                    val y = next() ?: return commands
                    commands.add(Command.CubicTo(x1, y1, x2, y2, x, y))
                }
                else -> i++
            }
        }
        return commands
    }

    /** The commands as an Android path. */
    fun path(commands: List<Command>): Path {
        val path = Path()
        for (c in commands) {
            when (c) {
                is Command.MoveTo -> path.moveTo(c.x, c.y)
                is Command.LineTo -> path.lineTo(c.x, c.y)
                is Command.CubicTo -> path.cubicTo(c.x1, c.y1, c.x2, c.y2, c.x, c.y)
                Command.Close -> path.close()
            }
        }
        return path
    }

    /** Parses path data straight into an Android path. */
    fun path(d: String): Path = path(parse(d))
}
