package com.acmeaom.myradar.sdk.internal

import com.acmeaom.myradar.sdk.FlightAirport
import com.acmeaom.myradar.sdk.FlightException
import com.acmeaom.myradar.sdk.FlightException.Reason
import com.acmeaom.myradar.sdk.FlightInfo
import com.acmeaom.myradar.sdk.FlightPosition
import com.acmeaom.myradar.sdk.FlightTrackPoint
import com.acmeaom.myradar.sdk.LatLng
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetworkException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.time.Instant
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Flight data from the MyRadar flight API, through the gateway: which leg a flight number refers
 * to right now, where it is, the route it filed and the track it has flown.
 */
internal object FlightData {

    // MARK: Idents

    /** `ua 1` → `UA1`. Returns null for anything that can't be a flight number, callsign or registration. */
    fun normalizeIdent(raw: String): String? {
        val ident = raw.uppercase().filter { it != ' ' && it != '-' }
        val valid = ident.length in 2..8 && ident.all { it in 'A'..'Z' || it in '0'..'9' } && ident.any { it.isDigit() }
        return ident.takeIf { valid }
    }

    /** `UA1` → `UA 1`, the way it's printed on tickets. */
    fun formatFlightNumber(ident: String): String =
        Regex("^([A-Z0-9]{2})(\\d+[A-Z]?)$").matchEntire(ident)?.let { "${it.groupValues[1]} ${it.groupValues[2]}" } ?: ident

    // MARK: Parsing (flight API responses; only the fields the SDK reads)

    private fun JSONObject.str(key: String): String? = optString(key, "").takeIf { !isNull(key) && it.isNotEmpty() }

    private fun JSONObject.num(key: String): Double? = if (has(key) && !isNull(key)) optDouble(key).takeIf { it.isFinite() } else null

    fun instant(s: String?): Instant? = s?.let { runCatching { Instant.parse(it) }.getOrNull() }

    /** The API gives ICAO airport codes; US ones (`KDFW`) carry the IATA code after the `K`. */
    fun airport(icao: String?): FlightAirport? {
        if (icao.isNullOrEmpty()) return null
        val iata = if (icao.length == 4 && icao.startsWith("K")) icao.substring(1) else null
        // The API has no airport names; name and city are left empty.
        return FlightAirport(iata ?: icao, iata, icao, name = "", city = "", coordinate = null)
    }

    /** `…/route`: the filed waypoints as `[lat, lon]`, origin and destination airports first and last. */
    fun waypoints(route: JSONObject?): List<LatLng> {
        val list = route?.optJSONArray("waypoints") ?: return emptyList()
        return (0 until list.length()).mapNotNull { i ->
            val p = list.optJSONArray(i) ?: return@mapNotNull null
            val lat = p.optDouble(0); val lon = p.optDouble(1)
            if (p.length() >= 2 && lat.isFinite() && lon.isFinite()) LatLng(lat, lon) else null
        }
    }

    /** `…/track`: rows of `[time, lat, lon, altitudeFt, groundSpeedKt, heading, source]`, oldest first. */
    fun track(raw: JSONObject?): List<FlightTrackPoint> {
        val rows = raw?.optJSONArray("points") ?: return emptyList()
        return (0 until rows.length()).mapNotNull { i ->
            val row = rows.optJSONArray(i) ?: return@mapNotNull null
            val time = instant(row.optString(0, "")) ?: return@mapNotNull null
            val lat = row.optDouble(1); val lon = row.optDouble(2)
            if (!lat.isFinite() || !lon.isFinite()) return@mapNotNull null
            val altitude = row.optDouble(3).takeIf { row.length() > 3 && !row.isNull(3) && it.isFinite() }
            FlightTrackPoint(LatLng(lat, lon), altitude, time)
        }
    }

    /** `flight.status`, which the API derives from actual events only. */
    fun statusText(status: String?, diverted: Boolean): String {
        val text = when (status) {
            "scheduled" -> "Scheduled"
            "filed" -> "Flight plan filed"
            "taxiing_out" -> "Taxiing for departure"
            "airborne" -> "In the air"
            "landed" -> "Landed"
            "taxiing_in" -> "Taxiing to the gate"
            "arrived" -> "Arrived"
            "cancelled" -> "Cancelled"
            else -> status?.replace("_", " ")?.replaceFirstChar { it.uppercase() } ?: ""
        }
        return if (diverted) "$text (diverted)" else text
    }

    /**
     * Positions older than this, in the air, are moved along the filed route (reports stop over
     * oceans for hours at a time).
     */
    const val ESTIMATE_AFTER_SECONDS = 3 * 60L

    /**
     * Where the aircraft probably is: the last report moved along the filed route, stopping at the
     * destination. With an expected arrival, it covers the share of the remaining route that the
     * time since the report is of the time left then (winds and routing are in the estimate);
     * otherwise it flies on at the reported ground speed. Null when there's nothing to estimate from.
     */
    fun estimate(p: FlightPosition, route: List<LatLng>, arrival: Instant?, now: Instant): FlightPosition? {
        val age = (now.toEpochMilli() - p.timestamp.toEpochMilli()) / 1000.0
        if (age <= ESTIMATE_AFTER_SECONDS || route.size < 2) return null
        val line = FlightGeometry.densify(route.map { LngLat(it) }, maxStepKm = 50.0)
        val hit = FlightGeometry.project(LngLat(p.coordinate), line) ?: return null
        val ahead = listOf(hit.point) + line.subList(hit.index + 1, line.size)
        var remaining = if (arrival != null && arrival.isAfter(p.timestamp)) {
            val left = ahead.zipWithNext { a, b -> FlightGeometry.distanceKm(a, b) }.sum()
            left * min(age / ((arrival.toEpochMilli() - p.timestamp.toEpochMilli()) / 1000.0), 1.0)
        } else {
            val knots = p.groundSpeedKnots ?: return null
            if (knots <= 0) return null
            knots * 1.852 * age / 3600
        }
        var at = hit.point
        var heading = p.heading
        for (next in ahead.drop(1)) {
            val step = FlightGeometry.distanceKm(at, next)
            heading = bearing(at, next)
            if (step >= remaining && step > 0) {
                val t = remaining / step
                at = LngLat(at.lng + t * (next.lng - at.lng), at.lat + t * (next.lat - at.lat))
                break
            }
            remaining -= step
            at = next
        }
        return p.copy(coordinate = at.coordinate, heading = heading, timestamp = now, isEstimated = true)
    }

    /** Initial great-circle bearing from `a` to `b`, degrees clockwise from north. */
    fun bearing(a: LngLat, b: LngLat): Double {
        val rad = Math.PI / 180
        val dLng = (b.lng - a.lng) * rad
        val y = sin(dLng) * cos(b.lat * rad)
        val x = cos(a.lat * rad) * sin(b.lat * rad) - sin(a.lat * rad) * cos(b.lat * rad) * cos(dLng)
        return (Math.toDegrees(atan2(y, x)) + 360) % 360
    }

    /** Combines the leg, its route and its track into a FlightInfo. [ident] is what the app asked for. */
    fun flightInfo(f: JSONObject, ident: String, route: JSONObject?, trackJson: JSONObject?,
                   now: Instant = Instant.now()): FlightInfo {
        val waypoints = waypoints(route)
        val track = track(trackJson)
        var origin = airport(f.str("origin"))
        var destination = airport(f.str("destination"))
        // The filed route starts and ends at the airports, which places them on the map.
        if (waypoints.size >= 2) {
            origin = origin?.copy(coordinate = waypoints.first())
            destination = destination?.copy(coordinate = waypoints.last())
        } else {
            origin = origin?.copy(coordinate = track.firstOrNull()?.coordinate)
        }
        val times = f.optJSONObject("times")
        fun time(vararg keys: String): Instant? = keys.firstNotNullOfOrNull { instant(times?.str(it)) }
        val status = f.str("status") ?: ""
        val landed = status in setOf("landed", "taxiing_in", "arrived")
        val airborne = status == "airborne"
        val departed = time("departure_actual", "surface_off", "airline_off")
        val arrived = if (landed) time("arrival_actual", "surface_on", "airline_on") else null
        val expected = if (airborne) time("arrival_estimated", "airline_on", "arrival_scheduled") else null

        var position = f.optJSONObject("position")?.let { p ->
            if (!p.has("lat") || !p.has("lon")) return@let null
            FlightPosition(
                coordinate = LatLng(p.getDouble("lat"), p.getDouble("lon")),
                altitudeFeet = p.num("altitudeFt"),
                groundSpeedKnots = p.num("groundSpeedKt"),
                heading = p.num("heading"),
                timestamp = instant(p.str("time")) ?: now,
                isEstimated = false,
            )
        }
        if (airborne && position != null) {
            val estimated = estimate(position, waypoints, expected, now)
            if (estimated != null) {
                position = estimated
            } else if (position.heading == null && track.size >= 2) {
                // Reports without a heading point along the last stretch of the track.
                val a = track[track.size - 2].coordinate; val b = track[track.size - 1].coordinate
                position = position.copy(heading = bearing(LngLat(a), LngLat(b)))
            }
        }

        val progress = when {
            landed -> 1.0
            airborne && departed != null && expected != null && expected.isAfter(departed) ->
                ((now.toEpochMilli() - departed.toEpochMilli()).toDouble() /
                    (expected.toEpochMilli() - departed.toEpochMilli())).coerceIn(0.0, 1.0)
            else -> null
        }

        val formatted = formatFlightNumber(ident)
        val callsign = f.str("callsign")
        return FlightInfo(
            flightId = f.getString("flightRef"),
            ident = if (formatted != ident || callsign == null) formatted else callsign,
            identIata = if (formatted != ident) ident else null,
            identIcao = callsign,
            operatorCode = f.str("airline"),
            aircraftType = f.str("aircraftType"),
            registration = null,
            status = statusText(f.str("status"), f.optBoolean("diverted", false)),
            isAirborne = airborne,
            hasLanded = landed,
            isCancelled = status == "cancelled",
            origin = origin,
            destination = destination,
            scheduledDeparture = time("departure_scheduled", "departure_proposed", "airline_original_departure"),
            actualDeparture = departed,
            scheduledArrival = time("arrival_scheduled", "airline_original_arrival"),
            estimatedArrival = expected,
            actualArrival = arrived,
            progress = progress,
            position = position,
            plannedRoute = waypoints,
            track = track,
        )
    }

    // MARK: Requests

    /** The flight API's routes on the gateway. */
    const val BASE_PATH = "/flight/v1/flights"

    fun url(path: String): String = GatewayConfiguration.endpoint(BASE_PATH + path)

    private suspend fun get(path: String, network: EngineNetwork): JSONObject = JSONObject(String(network.data(url(path))))

    /** A part of the flight that may be missing; cancellation still propagates. */
    private suspend fun getOrNull(path: String, network: EngineNetwork): JSONObject? = try {
        get(path, network)
    } catch (e: IOException) {
        null
    } catch (e: JSONException) {
        null
    }

    private fun failure(e: Throwable, ident: String): FlightException = when {
        e is FlightException -> e
        e is EngineNetworkException.Status && e.code == 401 ->
            FlightException(Reason.KeyRejected, ident, "The MyRadar API key was not accepted")
        e is EngineNetworkException.Status && e.code == 429 ->
            FlightException(Reason.Unavailable, ident, "Flight data is busy; try again in a minute")
        e is EngineNetworkException.Status -> FlightException(Reason.Unavailable, ident, "Flight data did not respond (HTTP ${e.code})")
        e is EngineNetworkException.NotConfigured -> FlightException(Reason.KeyRejected, ident, NOT_CONFIGURED_MESSAGE)
        e is JSONException -> FlightException(Reason.Unavailable, ident, "Flight data sent an unexpected response")
        else -> FlightException(Reason.Unavailable, ident, "Flight data did not respond (${e.message})")
    }

    private fun pathSegment(s: String): String = java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    /**
     * Looks a flight number up and gathers its filed route and track. Throws a FlightException
     * when the flight can't be shown at all; a missing route or track only leaves that part out.
     * [flightId] keeps following a leg already shown, even after the number moves on to its next one.
     */
    suspend fun lookUp(raw: String, network: EngineNetwork, flightId: String? = null): FlightInfo {
        val ident = normalizeIdent(raw)
            ?: throw FlightException(Reason.InvalidIdent, raw, "\"$raw\" is not a flight number")
        if (GatewayConfiguration.current == null) throw FlightException(Reason.KeyRejected, ident, NOT_CONFIGURED_MESSAGE)
        val path = flightId?.let { "/ref/${pathSegment(it)}" } ?: "/${pathSegment(ident)}"
        val flight = try {
            get(path, network).optJSONObject("flight")
        } catch (e: EngineNetworkException.Status) {
            if (e.code == 404) throw FlightException(Reason.NotFound, ident, "No flight $ident was found")
            throw failure(e, ident)
        } catch (e: IOException) {
            throw failure(e, ident)
        } catch (e: JSONException) {
            throw failure(e, ident)
        } ?: throw FlightException(Reason.NotFound, ident, "No flight $ident was found")
        val ref = "/ref/${pathSegment(flight.getString("flightRef"))}"
        return coroutineScope {
            val route = async { getOrNull("$ref/route", network) }
            val track = async { getOrNull("$ref/track", network) }
            flightInfo(flight, ident, route.await(), track.await())
        }
    }
}
