// The value types of a Mapbox GL style, limited to what the base map styles use: CSS colors,
// zoom functions with stops and an exponential base, and the legacy filter syntax.

package com.acmeaom.myradar.sdk.engine.basemap

import java.math.BigDecimal
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToLong

/** A straight-alpha color with components in 0..1. */
internal data class RGBA(val r: Float, val g: Float, val b: Float, val a: Float) {
    /** Premultiplied, with an extra opacity applied, ready for `ONE, ONE_MINUS_SRC_ALPHA` blending. */
    fun premultiplied(opacity: Float = 1f): RGBA {
        val alpha = a * opacity
        return RGBA(r * alpha, g * alpha, b * alpha, alpha)
    }

    companion object {
        val clear = RGBA(0f, 0f, 0f, 0f)
        val black = RGBA(0f, 0f, 0f, 1f)

        fun mix(x: RGBA, y: RGBA, t: Float): RGBA =
            RGBA(x.r + (y.r - x.r) * t, x.g + (y.g - x.g) * t, x.b + (y.b - x.b) * t, x.a + (y.a - x.a) * t)

        /** Parses `#rgb`, `#rgba`, `#rrggbb`, `#rrggbbaa`, `rgb()`, `rgba()`, `hsl()`, `hsla()` and a few names. */
        fun fromCss(css: String): RGBA? {
            val s = css.trimSpaces().lowercase()
            if (s.startsWith("#")) {
                val hex = s.substring(1)
                when (hex.length) {
                    3, 4 -> {
                        val v = FloatArray(hex.length)
                        for (i in hex.indices) v[i] = (nibble(hex[i]) ?: return null) * 17 / 255
                        return RGBA(v[0], v[1], v[2], if (v.size == 4) v[3] else 1f)
                    }
                    6, 8 -> {
                        val v = FloatArray(hex.length / 2)
                        for (i in v.indices) {
                            val hi = nibble(hex[2 * i]) ?: return null
                            val lo = nibble(hex[2 * i + 1]) ?: return null
                            v[i] = (hi * 16 + lo) / 255
                        }
                        return RGBA(v[0], v[1], v[2], if (v.size == 4) v[3] else 1f)
                    }
                    else -> return null
                }
            }
            val open = s.indexOf('(')
            if (open >= 0 && s.endsWith(")")) {
                val name = s.substring(0, open).trimSpaces()
                // Empty pieces are dropped before trimming, like splitting on a separator in Swift.
                val args = s.substring(open + 1, s.length - 1)
                    .split(',').filter { it.isNotEmpty() }.map { it.trimSpaces() }
                fun number(t: String): Float? = parseFloat(t.replace("%", ""))
                return when (name) {
                    "rgb", "rgba" -> {
                        if (args.size < 3) return null
                        val r = number(args[0]) ?: return null
                        val g = number(args[1]) ?: return null
                        val b = number(args[2]) ?: return null
                        val a = if (args.size > 3) number(args[3]) ?: 1f else 1f
                        RGBA(r / 255, g / 255, b / 255, a)
                    }
                    "hsl", "hsla" -> {
                        if (args.size < 3) return null
                        val h = number(args[0]) ?: return null
                        val sat = number(args[1]) ?: return null
                        val l = number(args[2]) ?: return null
                        val a = if (args.size > 3) number(args[3]) ?: 1f else 1f
                        val rgb = hslToRGB(h, sat / 100, l / 100)
                        RGBA(rgb[0], rgb[1], rgb[2], a)
                    }
                    else -> null
                }
            }
            return when (s) {
                "white" -> RGBA(1f, 1f, 1f, 1f)
                "black" -> RGBA(0f, 0f, 0f, 1f)
                "transparent" -> RGBA(0f, 0f, 0f, 0f)
                else -> null
            }
        }

        private fun nibble(c: Char): Float? = when (c) {
            in '0'..'9' -> (c - '0').toFloat()
            in 'a'..'f' -> (c - 'a' + 10).toFloat()
            in 'A'..'F' -> (c - 'A' + 10).toFloat()
            else -> null
        }

        private val decimalNumber = Regex("[+-]?(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d+)?")

        /**
         * A strict float parse: no surrounding spaces or Java's `f`/`d` suffixes, but `inf` and
         * `nan` are accepted.
         */
        private fun parseFloat(t: String): Float? = when {
            decimalNumber.matches(t) -> t.toFloatOrNull()
            else -> when (t.lowercase().removePrefix("+")) {
                "inf", "infinity" -> Float.POSITIVE_INFINITY
                "-inf", "-infinity" -> Float.NEGATIVE_INFINITY
                "nan", "-nan" -> Float.NaN
                else -> null
            }
        }

        private fun hslToRGB(h: Float, s: Float, l: Float): FloatArray {
            val hue = ((h % 360) + 360) % 360 / 360
            if (!(s > 0)) return floatArrayOf(l, l, l)
            val q = if (l < 0.5f) l * (1 + s) else l + s - l * s
            val p = 2 * l - q
            fun channel(t0: Float): Float {
                var t = t0
                if (t < 0) t += 1
                if (t > 1) t -= 1
                if (t < 1f / 6) return p + (q - p) * 6 * t
                if (t < 1f / 2) return q
                if (t < 2f / 3) return p + (q - p) * (2f / 3 - t) * 6
                return p
            }
            return floatArrayOf(channel(hue + 1f / 3), channel(hue), channel(hue - 1f / 3))
        }
    }
}

/** Trims spaces and tabs (not newlines), like trimming `.whitespaces` in Swift. */
private fun String.trimSpaces(): String =
    trim { it == ' ' || it == '\t' || Character.getType(it) == Character.SPACE_SEPARATOR.toInt() }

/**
 * A paint or layout property: a constant or a zoom function (`{"stops": [[z, v], ...], "base": b}`).
 *
 * Construct a constant with the primary constructor, or parse JSON with [fromJson], [number] or [color].
 */
internal class StyleProperty<T : Any> private constructor(
    private val constant: T?,
    private val stopZooms: DoubleArray,
    private val stopValues: List<T>,
    private val base: Double,
    private val interpolate: ((T, T, Double) -> T)?,
) {
    constructor(constant: T) : this(constant, DoubleArray(0), emptyList(), 1.0, null)

    val isZoomDependent: Boolean get() = constant == null

    fun evaluate(zoom: Double): T {
        constant?.let { return it }
        val last = stopZooms.size - 1
        if (zoom <= stopZooms[0]) return stopValues[0]
        if (zoom >= stopZooms[last]) return stopValues[last]
        var i = 0
        while (i + 1 < stopZooms.size && stopZooms[i + 1] <= zoom) i += 1
        val lower = stopValues[i]
        val interpolate = interpolate ?: return lower
        return interpolate(
            lower, stopValues[i + 1],
            interpolationFactor(zoom, stopZooms[i], stopZooms[i + 1], base),
        )
    }

    companion object {
        /** Parses a property, using [convert] for each value. Returns null when the JSON isn't usable. */
        fun <T : Any> fromJson(
            json: Any?,
            convert: (Any) -> T?,
            interpolate: ((T, T, Double) -> T)? = null,
        ): StyleProperty<T>? {
            if (json == null) return null
            val function = jsonObject(json)
            val rawStops = function?.get("stops")?.let { stops ->
                // Every stop must be an array for this to be a zoom function.
                (stops as? List<*>)?.map { it as? List<*> ?: return@let null }
            }
            if (function != null && rawStops != null) {
                val parsed = ArrayList<Pair<Double, T>>()
                for (stop in rawStops) {
                    if (stop.size != 2) continue
                    val z = StyleConvert.number(stop[0] ?: continue) ?: continue
                    val v = convert(stop[1] ?: continue) ?: continue
                    parsed.add(z to v)
                }
                if (parsed.isEmpty()) return null
                val sorted = parsed.sortedWith { a, b -> if (a.first < b.first) -1 else if (b.first < a.first) 1 else 0 }
                val base = function["base"]?.let { StyleConvert.number(it) } ?: 1.0
                // Functions over values that can't be interpolated (strings, arrays) step between stops.
                val interp = if ((function["type"] as? String) == "interval") null else interpolate
                return StyleProperty(
                    null, DoubleArray(sorted.size) { sorted[it].first }, sorted.map { it.second }, base, interp,
                )
            }
            val value = convert(json) ?: return null
            return StyleProperty(value)
        }

        fun number(json: Any?): StyleProperty<Double>? =
            fromJson(json, StyleConvert::number, StyleConvert::lerp)

        fun color(json: Any?): StyleProperty<RGBA>? =
            fromJson(json, StyleConvert::color, StyleConvert::lerpColor)

        /** Mapbox GL's exponential interpolation factor between two stops. */
        fun interpolationFactor(zoom: Double, lower: Double, upper: Double, base: Double): Double {
            val range = upper - lower
            if (!(range > 0)) return 0.0
            val progress = zoom - lower
            if (base == 1.0) return progress / range
            return (base.pow(progress) - 1) / (base.pow(range) - 1)
        }
    }
}

internal object StyleConvert {
    /** JSON booleans count as numbers (0 or 1), as they do for a JSON number in Swift. */
    fun number(v: Any): Double? = when (v) {
        is Double -> v
        is Number -> v.toDouble()
        is Boolean -> if (v) 1.0 else 0.0
        else -> null
    }

    fun color(v: Any): RGBA? = (v as? String)?.let(RGBA::fromCss)
    fun string(v: Any): String? = v as? String

    /** JSON numbers count as booleans (non-zero is true), as they do in Swift. */
    fun bool(v: Any): Boolean? = when (v) {
        is Boolean -> v
        is Number -> v.toDouble() != 0.0
        else -> null
    }

    fun numbers(v: Any): List<Double>? = (v as? List<*>)?.mapNotNull { it?.let(::number) }
    fun strings(v: Any): List<String>? = (v as? List<*>)?.mapNotNull { it as? String }

    fun lerp(a: Double, b: Double, t: Double): Double = a + (b - a) * t
    fun lerpColor(a: RGBA, b: RGBA, t: Double): RGBA = RGBA.mix(a, b, t.toFloat())
    fun lerpNumbers(a: List<Double>, b: List<Double>, t: Double): List<Double> =
        if (a.size == b.size) a.zip(b) { x, y -> x + (y - x) * t } else if (t < 0.5) a else b
}

// Features and filters

/** A feature property value from a vector tile or GeoJSON. */
internal sealed class FeatureValue {
    data class StringValue(val value: String) : FeatureValue()

    /** Compares with `==` on the double, so 0.0 equals -0.0 and NaN equals nothing. */
    class NumberValue(val value: Double) : FeatureValue() {
        override fun equals(other: Any?): Boolean = other is NumberValue && other.value == value
        override fun hashCode(): Int = (value + 0.0).hashCode()
        override fun toString(): String = "NumberValue($value)"
    }

    data class BoolValue(val value: Boolean) : FeatureValue()

    val stringValue: String
        get() = when (this) {
            is StringValue -> value
            is NumberValue -> {
                val n = value
                if (n == Math.rint(n) && abs(n) < 1e15) n.roundToLong().toString() else swiftDescription(n)
            }
            is BoolValue -> if (value) "true" else "false"
        }

    companion object {
        /** A JSON string, number or boolean; null for anything else. */
        fun fromJson(json: Any?): FeatureValue? = when (json) {
            is String -> StringValue(json)
            is Boolean -> BoolValue(json)
            is Number -> NumberValue(json.toDouble())
            else -> null
        }

        /** Orders two numbers or two strings; null when the types differ. */
        fun lessThan(a: FeatureValue, b: FeatureValue): Boolean? = when {
            a is NumberValue && b is NumberValue -> a.value < b.value
            a is StringValue && b is StringValue -> a.value < b.value
            else -> null
        }

        /**
         * Formats a double the way Swift's `String(Double)` does (shortest round-trip digits,
         * exponent form below 1e-4 and from 1e16, e.g. `1e-05`, `1.5e+16`), so labels match iOS.
         */
        fun swiftDescription(n: Double): String {
            if (n.isNaN()) return "nan"
            if (n.isInfinite()) return if (n > 0) "inf" else "-inf"
            if (n == 0.0) return if (1.0 / n < 0) "-0.0" else "0.0"
            val d = BigDecimal(n.toString()).stripTrailingZeros()
            val exponent = d.precision() - d.scale() - 1
            if (exponent < -4 || exponent >= 16) {
                val digits = d.unscaledValue().abs().toString()
                val mantissa = if (digits.length == 1) digits else digits[0] + "." + digits.substring(1)
                val sign = if (n < 0) "-" else ""
                val expSign = if (exponent < 0) "-" else "+"
                return sign + mantissa + "e" + expSign + abs(exponent).toString().padStart(2, '0')
            }
            val plain = d.toPlainString()
            return if (plain.contains('.')) plain else "$plain.0"
        }
    }
}

internal enum class GeometryType(val rawValue: Int) {
    POINT(1), LINE_STRING(2), POLYGON(3);

    val filterName: String
        get() = when (this) {
            POINT -> "Point"
            LINE_STRING -> "LineString"
            POLYGON -> "Polygon"
        }

    companion object {
        fun fromRawValue(rawValue: Int): GeometryType? = entries.firstOrNull { it.rawValue == rawValue }
    }
}

/**
 * A legacy (pre-expression) style filter. The combinators are [All], [AnyOf] and [NoneOf]
 * (`any`/`none` would clash with Kotlin names).
 */
internal sealed class StyleFilter {
    object Always : StyleFilter()
    data class Compare(val op: String, val key: String, val value: FeatureValue) : StyleFilter()
    data class Membership(val key: String, val values: List<FeatureValue>, val negated: Boolean) : StyleFilter()
    data class Has(val key: String, val negated: Boolean) : StyleFilter()
    data class All(val filters: List<StyleFilter>) : StyleFilter()
    data class AnyOf(val filters: List<StyleFilter>) : StyleFilter()
    data class NoneOf(val filters: List<StyleFilter>) : StyleFilter()

    fun matches(properties: Map<String, FeatureValue>, type: GeometryType, id: ULong?): Boolean {
        fun lookup(key: String): FeatureValue? = when (key) {
            "\$type" -> FeatureValue.StringValue(type.filterName)
            "\$id" -> id?.let { FeatureValue.NumberValue(it.toDouble()) }
            else -> properties[key]
        }
        return when (this) {
            Always -> true
            is Compare -> {
                val actual = lookup(key) ?: return op == "!="
                when (op) {
                    "==" -> actual == value
                    "!=" -> actual != value
                    "<" -> FeatureValue.lessThan(actual, value) ?: false
                    "<=" -> actual == value || (FeatureValue.lessThan(actual, value) ?: false)
                    ">" -> FeatureValue.lessThan(value, actual) ?: false
                    ">=" -> actual == value || (FeatureValue.lessThan(value, actual) ?: false)
                    else -> false
                }
            }
            is Membership -> {
                val found = lookup(key)?.let { values.contains(it) } ?: false
                if (negated) !found else found
            }
            is Has -> {
                val found = lookup(key) != null
                if (negated) !found else found
            }
            is All -> filters.all { it.matches(properties, type, id) }
            is AnyOf -> filters.any { it.matches(properties, type, id) }
            is NoneOf -> filters.none { it.matches(properties, type, id) }
        }
    }

    companion object {
        fun fromJson(json: Any?): StyleFilter {
            val array = json as? List<*> ?: return Always
            val op = array.firstOrNull() as? String ?: return Always
            val args = array.drop(1)
            return when (op) {
                "all" -> All(args.map(::fromJson))
                "any" -> AnyOf(args.map(::fromJson))
                "none" -> NoneOf(args.map(::fromJson))
                "has", "!has" -> Has(args.firstOrNull() as? String ?: "", op == "!has")
                "in", "!in" -> {
                    val values = args.drop(1).mapNotNull(FeatureValue::fromJson)
                    Membership(args.firstOrNull() as? String ?: "", values, op == "!in")
                }
                "==", "!=", "<", "<=", ">", ">=" -> {
                    if (args.size != 2) return Always
                    val key = args[0] as? String ?: return Always
                    val value = FeatureValue.fromJson(args[1]) ?: return Always
                    Compare(op, key, value)
                }
                else -> Always
            }
        }
    }
}
