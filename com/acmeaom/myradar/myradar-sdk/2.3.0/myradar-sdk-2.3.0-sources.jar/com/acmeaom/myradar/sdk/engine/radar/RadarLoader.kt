package com.acmeaom.myradar.sdk.engine.radar

import com.acmeaom.myradar.sdk.engine.basemap.RGBAImage
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.engine.tiles.TileID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Fetches and decodes radar tiles, a limited number at a time, most urgent first. Runs on the
 * main thread; downloads and decoding happen off it.
 */
internal class RadarLoader(private val network: EngineNetwork, private val scope: CoroutineScope) {
    sealed class Target {
        object Tile : Target()
        data class Mosaic(val key: MosaicKey, val tile: TileID) : Target()
        data class Flow(val key: MosaicKey, val tile: TileID) : Target()
    }

    class Request(
        val url: String,
        val target: Target,
        val priority: Int,
        /** Pre-colored tiles (SD radar), decoded premultiplied like any picture. */
        val colors: Boolean = false,
    )

    sealed class Content {
        class Pixels(val pixels: ByteArray, val width: Int, val height: Int) : Content()
        object Empty : Content()
        object Failed : Content()
    }

    class Result(val url: String, val target: Target, val content: Content)

    var onLoaded: ((Result) -> Unit)? = null

    private val queue = ArrayList<Request>()
    private var inFlight = 0

    /** Removes queued (not yet started) requests whose URLs aren't wanted, and returns them. */
    fun retainOnly(urls: Set<String>): List<Request> {
        val dropped = ArrayList<Request>()
        queue.removeAll { request ->
            if (request.url in urls) return@removeAll false
            dropped.add(request)
            true
        }
        return dropped
    }

    fun enqueue(requests: List<Request>) {
        if (requests.isEmpty()) return
        queue.addAll(requests)
        queue.sortBy { it.priority }
        pump()
    }

    private fun pump() {
        while (inFlight < MAX_IN_FLIGHT && queue.isNotEmpty()) {
            val request = queue.removeAt(0)
            inFlight += 1
            val isFlow = request.target is Target.Flow
            // Dispatched (not immediate), so a load that fails at once doesn't re-enter this loop.
            scope.launch(Dispatchers.Main) {
                val content = try {
                    val data = network.data(request.url)
                    withContext(Dispatchers.Default) { decode(data, exact = isFlow, colors = request.colors) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // 404 and 403 (no tile), other statuses and transport errors alike.
                    Content.Failed
                }
                inFlight -= 1
                onLoaded?.invoke(Result(request.url, request.target, content))
                pump()
            }
        }
    }

    companion object {
        private const val MAX_IN_FLIGHT = 12

        /**
         * Motion vectors decode exactly with [PNGDecoder]; radar tiles, whose channels are data
         * too, without premultiplying ([DataImageDecoder]); pre-colored tiles premultiplied, for
         * drawing as they are. A 1×1 image means the tile has no data.
         */
        fun decode(data: ByteArray, exact: Boolean, colors: Boolean): Content {
            if (exact) {
                val image = PNGDecoder.decode(data) ?: return Content.Failed
                if (image.width <= 1 && image.height <= 1) return Content.Empty
                return Content.Pixels(image.pixels, image.width, image.height)
            }
            val image = (if (colors) RGBAImage.decode(data) else DataImageDecoder.decode(data))
                ?: return Content.Failed
            if (image.width <= 1 && image.height <= 1) return Content.Empty
            return Content.Pixels(image.bytes, image.width, image.height)
        }
    }
}
