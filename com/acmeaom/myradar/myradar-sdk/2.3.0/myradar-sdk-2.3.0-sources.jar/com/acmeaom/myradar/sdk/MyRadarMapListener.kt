package com.acmeaom.myradar.sdk

import android.graphics.PointF
import java.util.Date

/**
 * Receives map and radar animation events from a [MyRadarMapView].
 *
 * All methods have empty default implementations and are always called on the main thread.
 */
public interface MyRadarMapListener {

    /** Called repeatedly while the viewport is changing. */
    public fun onMapMoved(mapView: MyRadarMapView) {}

    /** Called once when the viewport has settled. */
    public fun onMapStoppedMoving(mapView: MyRadarMapView) {}

    /**
     * Called when the radar animation advances to a new frame.
     *
     * @param date The timestamp of the displayed frame, or `null` while the frame is loading.
     */
    public fun onRadarFrame(mapView: MyRadarMapView, date: Date?) {}

    /** Called as the radar animation plays, reporting the playhead position in `0..1`. */
    public fun onRadarScrubberPosition(mapView: MyRadarMapView, position: Float) {}

    /**
     * Called when the radar color palette becomes available or changes. The palette is a
     * JSON document describing value-to-color spans, useful for rendering a legend.
     */
    public fun onRadarPalette(mapView: MyRadarMapView, paletteJson: String?) {}

    /** Called when the user taps a marker from [MyRadarMapView.markers]. */
    public fun onMarkerTap(mapView: MyRadarMapView, marker: MapMarker) {}

    /** Called when the user taps a polyline from [MyRadarMapView.polylines]. */
    public fun onPolylineTap(mapView: MyRadarMapView, polyline: MapPolyline) {}

    /** Called when the user taps a polygon from [MyRadarMapView.polygons]. */
    public fun onPolygonTap(mapView: MyRadarMapView, polygon: MapPolygon) {}

    /**
     * Called when the user taps watches, warnings or advisories, with every alert under the tap,
     * most important first. Called whether or not the map shows its own tooltip
     * ([MyRadarMapView.showsWarningTooltips]).
     *
     * @param point The tap location in pixels, relative to the map view.
     */
    public fun onWarningTap(mapView: MyRadarMapView, alerts: List<WeatherAlert>, point: PointF) {}

    /**
     * Called when the user taps tappable engine graphics that are not SDK markers, polylines
     * or polygons (for example warning polygons).
     *
     * @param graphicsJson Each tapped graphic's properties, as JSON object strings.
     * @param pointDp The tap location in dp, relative to the map view.
     */
    public fun onGraphicsTap(mapView: MyRadarMapView, graphicsJson: List<String>, pointDp: PointF) {}

    /**
     * Called when the flight shown with [MyRadarMapView.showFlight] loads, and after every update
     * until it lands.
     */
    public fun onFlightUpdate(mapView: MyRadarMapView, flight: FlightInfo) {}

    /**
     * Called when the flight couldn't be loaded or updated. After a failed update the last data
     * stays on the map and the next update is tried as usual.
     */
    public fun onFlightError(mapView: MyRadarMapView, error: FlightException) {}
}
