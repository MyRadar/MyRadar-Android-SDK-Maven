package com.acmeaom.myradar.sdk.engine

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.opengl.EGL14
import android.opengl.EGLSurface
import android.opengl.GLES30
import android.view.Choreographer
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.VelocityTracker
import android.view.ViewConfiguration
import com.acmeaom.myradar.sdk.LatLng
import com.acmeaom.myradar.sdk.engine.basemap.BasemapRenderer
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.ScreenPoint
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import com.acmeaom.myradar.sdk.engine.gl.GLContext
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.overlays.AnnotationsRenderer
import com.acmeaom.myradar.sdk.engine.overlays.HurricanesRenderer
import com.acmeaom.myradar.sdk.engine.overlays.LightningRenderer
import com.acmeaom.myradar.sdk.engine.overlays.WindRenderer
import com.acmeaom.myradar.sdk.engine.radar.RadarRenderer
import com.acmeaom.myradar.sdk.engine.overlays.WarningsRenderer
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.log2
import kotlin.math.pow

/** Events the engine reports to its host, on the main thread. */
internal interface MapEngineListener {
    fun engineDidMove(engine: MapEngineView)
    fun engineDidStopMoving(engine: MapEngineView)
    /** A tap at a point in dp. */
    fun engineDidTap(engine: MapEngineView, x: Float, y: Float)
}

/**
 * The engine's view: an OpenGL ES surface drawn on the main thread by a frame callback when
 * something changed, the camera and its gestures and animations, and the layers drawn on the map.
 */
@SuppressLint("ViewConstructor")
internal class MapEngineView(context: Context, val network: EngineNetwork) : SurfaceView(context), SurfaceHolder.Callback {
    var listener: MapEngineListener? = null

    val transform = MapTransform()
    private val density = resources.displayMetrics.density.toDouble()

    private val gl: GLContext? = GLContext.shared
    private var eglSurface: EGLSurface? = null
    private var pixelWidth = 0
    private var pixelHeight = 0
    private var needsRender = true
    private var isRendering = false
    private var frameScheduled = false

    val basemap = BasemapRenderer(network).also { it.onNeedsDisplay = ::setNeedsRender }
    val warnings = WarningsRenderer(network).also { it.onNeedsDisplay = ::setNeedsRender }
    val lightning = LightningRenderer(network).also { it.onNeedsDisplay = ::setNeedsRender }
    val hurricanes = HurricanesRenderer(network).also { it.onNeedsDisplay = ::setNeedsRender }
    val annotations = AnnotationsRenderer(context).also { it.onNeedsDisplay = ::setNeedsRender }
    val radar = RadarRenderer(network).also {
        it.onNeedsDisplay = ::setNeedsRender
        it.onTimingChanged = { lightning.refresh() }
    }
    val wind = WindRenderer(network).also { it.onNeedsDisplay = ::setNeedsRender }
    private var radarAnimating = false
    private var windAnimating = false
    private var labelsFading = false
    private var lightningFading = false
    private var markersFading = false
    /** When the hurricane layer next needs a frame (its spinning icons and fades). */
    private var hurricanesNextFrame: Double? = null

    /**
     * Multiplies the size of the text the map draws: base map labels, hurricane labels and text
     * markers. Set by the map view from the system font scale or the app's choice.
     */
    var textScale: Float = 1f
        set(value) {
            if (value == field) return
            field = value
            basemap.textScale = value
            hurricanes.textScale = value
            annotations.textScale = value
            setNeedsRender()
        }

    /** Stops the layers' feeds and loads; the view can't draw afterwards. */
    fun dispose() {
        basemap.dispose()
        warnings.dispose()
        lightning.dispose()
        hurricanes.dispose()
        radar.dispose()
        wind.dispose()
    }

    private var animation: CameraAnimation? = null
    private var deceleration: Deceleration? = null

    init {
        EngineAssets.install(context)
        holder.addCallback(this)
        // Nothing polls until the map starts drawing.
        setRendering(false)
    }

    // MARK: Camera

    var centerCoordinate: LatLng
        get() = transform.coordinate
        set(value) { cancelMotion(); transform.coordinate = value; cameraChanged() }

    var zoom: Double
        get() = transform.zoom
        set(value) { cancelMotion(); transform.setZoom(value); cameraChanged() }

    var heading: Double
        get() = transform.heading
        set(value) { cancelMotion(); transform.setHeading(value); cameraChanged() }

    var tilt: Double
        get() = transform.tilt
        set(value) { cancelMotion(); transform.setTilt(value); cameraChanged() }

    fun setCenter(coordinate: LatLng, zoom: Double, animated: Boolean) {
        cancelMotion()
        val target = MapTransform.mercator(coordinate)
        val targetZoom = zoom.coerceIn(MapTransform.MIN_ZOOM, MapTransform.MAX_ZOOM)
        if (!animated) {
            transform.setCenter(target)
            transform.setZoom(targetZoom)
            cameraChanged()
            cameraStopped()
            return
        }
        // Animate across the shorter way around the world.
        var start = transform.center
        if (target.x - start.x > 0.5) start = Vec2(start.x + 1, start.y)
        else if (start.x - target.x > 0.5) start = Vec2(start.x - 1, start.y)
        animation = CameraAnimation(nowSeconds(), 0.45, start, target, transform.zoom, targetZoom)
        setNeedsRender()
    }

    fun zoomFitting(latitudeDelta: Double, longitudeDelta: Double, centerLatitude: Double): Double =
        transform.zoomFitting(latitudeDelta, longitudeDelta, centerLatitude)

    /** The coordinate under a point in dp. */
    fun coordinate(x: Float, y: Float): LatLng? =
        transform.mercatorAt(ScreenPoint(x.toDouble(), y.toDouble()))?.let(MapTransform::coordinate)

    /** The point in dp for a coordinate, or null when it's behind the camera. */
    fun point(coordinate: LatLng): ScreenPoint? = transform.screenPoint(MapTransform.mercator(coordinate))

    private fun cameraChanged() {
        setNeedsRender()
        hurricanes.mapMoved(nowSeconds())
        listener?.engineDidMove(this)
    }

    private fun cameraStopped() {
        listener?.engineDidStopMoving(this)
    }

    private fun cancelMotion() {
        animation = null
        deceleration = null
    }

    /** Engine graphics under a point in dp that respond to taps: storm icons, then warnings. */
    fun graphics(x: Float, y: Float): List<Map<String, Any?>> {
        val point = ScreenPoint(x.toDouble(), y.toDouble())
        val result = hurricanes.features(point, transform).toMutableList()
        transform.mercatorAt(point)?.let { result += warnings.features(it) }
        return result
    }

    // MARK: Style

    fun setStyleUrl(url: String) {
        basemap.load(url)
        setNeedsRender()
    }

    // MARK: Rendering

    fun setNeedsRender() {
        needsRender = true
        scheduleFrame()
    }

    /** Starts or stops drawing (the host stops it while the map isn't visible). */
    fun setRendering(enabled: Boolean) {
        isRendering = enabled
        // Feeds poll only while the map draws, so a map that's gone doesn't keep polling (and
        // isn't kept alive by its polling).
        warnings.feedsActive = enabled
        hurricanes.feedsActive = enabled
        wind.feedsActive = enabled
        if (enabled) setNeedsRender()
    }

    private fun scheduleFrame() {
        if (frameScheduled || !isRendering) return
        frameScheduled = true
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    private val frameCallback = Choreographer.FrameCallback { frameTimeNanos ->
        frameScheduled = false
        tick(frameTimeNanos / 1e9)
    }

    private fun tick(now: Double) {
        stepMotion(now)
        if (radarAnimating || windAnimating || labelsFading || lightningFading || markersFading) needsRender = true
        hurricanesNextFrame?.let { if (now >= it) needsRender = true }
        val animating = animation != null || deceleration != null
        if (needsRender && isRendering && eglSurface != null && pixelWidth > 0 && pixelHeight > 0) {
            needsRender = false
            render(now)
        }
        // Keep the frame callback going while anything moves, fades or waits for its next frame.
        if (animating || needsRender || radarAnimating || windAnimating || labelsFading || lightningFading || markersFading ||
            hurricanesNextFrame != null) scheduleFrame()
    }

    private fun render(now: Double) {
        val gl = gl ?: return
        val surface = eglSurface ?: return
        if (!gl.makeCurrent(surface)) return
        drawFrame(gl, now)
        EGL14.eglSwapBuffers(gl.display, surface)
    }

    private fun drawFrame(gl: GLContext, now: Double) {
        gl.drainDeletes()
        GLES30.glViewport(0, 0, pixelWidth, pixelHeight)
        val clear = basemap.clearColor(transform.zoom)
        GLES30.glClearColor(clear.r * clear.a, clear.g * clear.a, clear.b * clear.a, 1f)
        GLES30.glStencilMask(0xFF)
        GLES30.glClearStencil(0)
        GLES30.glColorMask(true, true, true, true)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_STENCIL_BUFFER_BIT)
        val context = RenderContext(gl, transform, density, now, pixelWidth, pixelHeight)

        // Back to front, as the engine's layer weights order them: the base map with its labels,
        // ordinary warnings and watches, the radar, wind particles, hurricane cones and tracks,
        // the most severe warnings, then map stamps.
        basemap.draw(context)
        // Layers above the base map start from a clear stencil (shape fills count coverage in it).
        context.clearStencil()
        // A lightning flash lights up the map itself, not the labels or weather drawn over it.
        lightning.drawFlash(context, radar)
        labelsFading = basemap.drawLabels(context)
        warnings.drawUnderRadar(context)
        radar.lightningFlash = lightning.currentFlash
        radarAnimating = radar.draw(context)
        windAnimating = wind.draw(context)
        hurricanes.drawShapes(context)
        annotations.drawShapes(context)
        warnings.drawOverRadar(context)
        // Map stamps, back to front by weight: hurricane labels, lightning, hurricane icons.
        hurricanes.drawLabels(context)
        lightningFading = lightning.drawMarkers(context, radar)
        hurricanesNextFrame = hurricanes.drawIcons(context)
        markersFading = annotations.drawMarkers(context)
    }

    /** Captures the current frame. */
    fun snapshot(): Bitmap? {
        val gl = gl ?: return null
        val surface = eglSurface ?: return null
        if (pixelWidth <= 0 || pixelHeight <= 0 || !gl.makeCurrent(surface)) return null
        // The window surface may be multisampled, which can't be read back: draw into a plain
        // framebuffer instead.
        val ids = IntArray(1); val rb = IntArray(2)
        GLES30.glGenFramebuffers(1, ids, 0)
        GLES30.glGenRenderbuffers(2, rb, 0)
        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, rb[0])
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_RGBA8, pixelWidth, pixelHeight)
        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, rb[1])
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_STENCIL_INDEX8, pixelWidth, pixelHeight)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, ids[0])
        GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_RENDERBUFFER, rb[0])
        GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_STENCIL_ATTACHMENT, GLES30.GL_RENDERBUFFER, rb[1])
        drawFrame(gl, nowSeconds())
        val buffer = ByteBuffer.allocateDirect(pixelWidth * pixelHeight * 4).order(ByteOrder.nativeOrder())
        GLES30.glReadPixels(0, 0, pixelWidth, pixelHeight, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buffer)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glDeleteFramebuffers(1, ids, 0)
        GLES30.glDeleteRenderbuffers(2, rb, 0)
        val raw = Bitmap.createBitmap(pixelWidth, pixelHeight, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(buffer)
        // GL rows run bottom up.
        val flip = android.graphics.Matrix().apply { preScale(1f, -1f) }
        return Bitmap.createBitmap(raw, 0, 0, pixelWidth, pixelHeight, flip, false)
    }

    // MARK: Surface

    override fun surfaceCreated(holder: SurfaceHolder) {
        val gl = gl ?: return
        eglSurface = gl.createWindowSurface(holder.surface)
        setNeedsRender()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        pixelWidth = width
        pixelHeight = height
        transform.width = width / density
        transform.height = height / density
        setNeedsRender()
        cameraChanged()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        val surface = eglSurface ?: return
        eglSurface = null
        gl?.destroySurface(surface)
    }

    // MARK: Motion

    private fun stepMotion(now: Double) {
        animation?.let { a ->
            val t = ((now - a.start) / a.duration).coerceIn(0.0, 1.0)
            val e = if (t < 0.5) 4 * t * t * t else 1 - (-2 * t + 2).pow(3) / 2
            transform.setCenter(a.fromCenter + (a.toCenter - a.fromCenter) * e)
            transform.setZoom(a.fromZoom + (a.toZoom - a.fromZoom) * e)
            cameraChanged()
            if (t >= 1) {
                animation = null
                cameraStopped()
            }
            return
        }
        val d = deceleration ?: return
        val dt = now - d.last
        val decay = 0.05.pow(dt)  // speed falls to 5% each second
        val velocity = d.velocity * decay
        if (velocity.length * transform.worldSize < 8) {
            deceleration = null
            cameraStopped()
            return
        }
        transform.setCenter(transform.center + velocity * dt)
        deceleration = Deceleration(velocity, now)
        cameraChanged()
    }

    // MARK: Gestures

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop / density
    private var velocityTracker: VelocityTracker? = null
    /** The focus (mean of the pointers) at the last move, in dp. */
    private var lastFocus: ScreenPoint? = null
    private var lastSpan = 0.0
    private var lastAngle = 0.0
    private var rotationTotal = 0.0
    private var rotating = false
    private var gestureMoved = false
    private var twoFingerTapStart = 0L
    private var twoFingerTapCandidate = false
    private var maxPointers = 0

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            listener?.engineDidTap(this@MapEngineView, (e.x / density).toFloat(), (e.y / density).toFloat())
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            zoom(1.0, ScreenPoint(e.x / density, e.y / density))
            return true
        }
    })

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        val tracker = velocityTracker ?: VelocityTracker.obtain().also { velocityTracker = it }
        tracker.addMovement(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                cancelMotion()
                gestureMoved = false
                maxPointers = 1
                twoFingerTapCandidate = false
                resetGesture(event)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                maxPointers = maxOf(maxPointers, event.pointerCount)
                if (event.pointerCount == 2 && !gestureMoved) {
                    twoFingerTapCandidate = true
                    twoFingerTapStart = event.eventTime
                }
                resetGesture(event)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (twoFingerTapCandidate && event.pointerCount == 2 && !gestureMoved &&
                    event.eventTime - twoFingerTapStart < TWO_FINGER_TAP_MS) {
                    twoFingerTapCandidate = false
                    zoom(-1.0, ScreenPoint(transform.width / 2, transform.height / 2))
                }
                resetGesture(event, excluding = event.actionIndex)
            }
            MotionEvent.ACTION_MOVE -> handleMove(event)
            MotionEvent.ACTION_UP -> {
                tracker.computeCurrentVelocity(1000)
                val vx = tracker.xVelocity / density
                val vy = tracker.yVelocity / density
                startDecelerationOrStop(vx, vy)
                velocityTracker?.recycle()
                velocityTracker = null
                lastFocus = null
            }
            MotionEvent.ACTION_CANCEL -> {
                velocityTracker?.recycle()
                velocityTracker = null
                lastFocus = null
                if (gestureMoved) cameraStopped()
            }
        }
        return true
    }

    private fun focus(event: MotionEvent, excluding: Int = -1): Triple<ScreenPoint, Double, Double> {
        var sx = 0.0; var sy = 0.0; var count = 0
        for (i in 0 until event.pointerCount) {
            if (i == excluding) continue
            sx += event.getX(i); sy += event.getY(i); count++
        }
        val fx = sx / count; val fy = sy / count
        var span = 0.0
        var angle = 0.0
        val indices = (0 until event.pointerCount).filter { it != excluding }
        if (indices.size >= 2) {
            val a = indices[0]; val b = indices[1]
            span = hypot(event.getX(b) - event.getX(a).toDouble(), event.getY(b) - event.getY(a).toDouble()) / density
            angle = atan2(event.getY(b) - event.getY(a).toDouble(), event.getX(b) - event.getX(a).toDouble())
        }
        return Triple(ScreenPoint(fx / density, fy / density), span, angle)
    }

    private fun resetGesture(event: MotionEvent, excluding: Int = -1) {
        val (f, span, angle) = focus(event, excluding)
        lastFocus = f
        lastSpan = span
        lastAngle = angle
        rotationTotal = 0.0
        rotating = false
    }

    private fun handleMove(event: MotionEvent) {
        val previous = lastFocus ?: return
        val (f, span, angle) = focus(event)
        if (!gestureMoved) {
            val moved = hypot(f.x - previous.x, f.y - previous.y) > touchSlop ||
                (lastSpan > 0 && abs(span - lastSpan) > touchSlop)
            if (!moved) return
            gestureMoved = true
            twoFingerTapCandidate = false
            cancelMotion()
        }
        // Pan: keep the map point under the previous focus under the new one.
        val from = transform.mercatorAt(previous)
        val to = transform.mercatorAt(f)
        if (from != null && to != null) transform.setCenter(transform.center + (from - to))
        if (event.pointerCount >= 2 && lastSpan > 0 && span > 0) {
            // Pinch: zoom around the focus.
            val anchor = transform.mercatorAt(f)
            transform.setZoom(transform.zoom + log2(span / lastSpan))
            // Rotation, once the fingers have turned far enough to mean it.
            var delta = angle - lastAngle
            if (delta > Math.PI) delta -= 2 * Math.PI else if (delta < -Math.PI) delta += 2 * Math.PI
            rotationTotal += delta
            if (!rotating && abs(rotationTotal) > ROTATION_THRESHOLD) rotating = true
            if (rotating) transform.setHeading(transform.heading - Math.toDegrees(delta))
            if (anchor != null) keep(anchor, f)
        }
        lastFocus = f
        lastSpan = span
        lastAngle = angle
        cameraChanged()
    }

    private fun startDecelerationOrStop(vx: Double, vy: Double) {
        if (!gestureMoved) return
        if (maxPointers == 1 && hypot(vx, vy) > 200) {
            val cx = transform.width / 2; val cy = transform.height / 2
            val a = transform.mercatorAt(ScreenPoint(cx, cy))
            val b = transform.mercatorAt(ScreenPoint(cx - vx * 0.1, cy - vy * 0.1))
            if (a != null && b != null) {
                deceleration = Deceleration((b - a) * 10.0, nowSeconds())
                setNeedsRender()
                return
            }
        }
        cameraStopped()
    }

    /** Animates a zoom change that keeps the map point under `point` in place. */
    private fun zoom(delta: Double, point: ScreenPoint) {
        val anchor = transform.mercatorAt(point) ?: return
        val target = transform.copy()
        target.setZoom(transform.zoom + delta)
        target.mercatorAt(point)?.let { moved -> target.setCenter(target.center + (anchor - moved)) }
        setCenter(MapTransform.coordinate(target.center), target.zoom, animated = true)
    }

    /** Shifts the center so a Mercator point sits under a screen point again. */
    private fun keep(mercator: Vec2, point: ScreenPoint) {
        val now = transform.mercatorAt(point) ?: return
        transform.setCenter(transform.center + (mercator - now))
    }

    private class CameraAnimation(
        val start: Double, val duration: Double,
        val fromCenter: Vec2, val toCenter: Vec2, val fromZoom: Double, val toZoom: Double,
    )

    private class Deceleration(val velocity: Vec2, val last: Double)

    companion object {
        private const val TWO_FINGER_TAP_MS = 300L
        /** Radians the fingers must turn before a pinch also rotates. */
        private const val ROTATION_THRESHOLD = 0.2

        /** Seconds on the frame callback's clock. */
        fun nowSeconds(): Double = System.nanoTime() / 1e9
    }
}
