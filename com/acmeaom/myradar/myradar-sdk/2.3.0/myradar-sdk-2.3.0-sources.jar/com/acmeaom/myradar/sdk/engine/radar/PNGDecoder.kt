package com.acmeaom.myradar.sdk.engine.radar

import java.util.zip.DataFormatException
import java.util.zip.Inflater
import kotlin.math.abs

/**
 * Decodes 8-bit RGBA and RGB PNGs to their exact stored bytes. System image decoding may
 * premultiply alpha or apply color management, which would corrupt the motion-vector tiles:
 * they store 16-bit integers split across (r, g) and (b, a).
 */
internal object PNGDecoder {
    internal class Image(
        val width: Int,
        val height: Int,
        /** RGBA, 4 bytes per pixel, not premultiplied, rows top first. */
        val pixels: ByteArray,
    )

    private val SIGNATURE = byteArrayOf(0x89.toByte(), 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)

    fun decode(bytes: ByteArray): Image? {
        if (bytes.size <= 8 || !bytes.copyOfRange(0, 8).contentEquals(SIGNATURE)) return null
        fun u8(o: Int) = bytes[o].toInt() and 0xFF
        fun u32(o: Int): Int = u8(o) shl 24 or (u8(o + 1) shl 16) or (u8(o + 2) shl 8) or u8(o + 3)
        var pos = 8
        var width = 0; var height = 0; var bitDepth = 0; var colorType = 0; var interlace = 0
        val idat = java.io.ByteArrayOutputStream()
        while (pos + 8 <= bytes.size) {
            val length = u32(pos)
            val type = String(bytes, pos + 4, 4, Charsets.US_ASCII)
            val body = pos + 8
            if (length < 0 || body + length > bytes.size) return null
            when (type) {
                "IHDR" -> {
                    width = u32(body)
                    height = u32(body + 4)
                    bitDepth = u8(body + 8)
                    colorType = u8(body + 9)
                    interlace = u8(body + 12)
                }
                "IDAT" -> idat.write(bytes, body, length)
            }
            if (type == "IEND") break
            pos = body + length + 4
        }
        // The tiles are 8-bit RGBA or RGB and never interlaced; anything else isn't a flow tile.
        val compressed = idat.toByteArray()
        if (width <= 0 || height <= 0 || bitDepth != 8 || interlace != 0 || (colorType != 6 && colorType != 2) ||
            compressed.size <= 2) return null
        val channels = if (colorType == 6) 4 else 3
        val stride = width * channels
        val expected = (stride + 1).toLong() * height
        if (expected > Int.MAX_VALUE - 64) return null
        val raw = inflate(compressed, 2, expected.toInt()) ?: return null
        if (raw.size < expected) return null

        val rows = ByteArray(stride * height)
        var input = 0
        for (y in 0 until height) {
            val filter = raw[input].toInt() and 0xFF
            input += 1
            val row = y * stride
            for (i in 0 until stride) {
                val x = raw[input + i].toInt() and 0xFF
                val a = if (i >= channels) rows[row + i - channels].toInt() and 0xFF else 0
                val b = if (y > 0) rows[row - stride + i].toInt() and 0xFF else 0
                val c = if (y > 0 && i >= channels) rows[row - stride + i - channels].toInt() and 0xFF else 0
                val v = when (filter) {
                    0 -> x
                    1 -> x + a
                    2 -> x + b
                    3 -> x + (a + b) / 2
                    4 -> {
                        val p = a + b - c
                        val pa = abs(p - a); val pb = abs(p - b); val pc = abs(p - c)
                        x + if (pa <= pb && pa <= pc) a else if (pb <= pc) b else c
                    }
                    else -> return null
                }
                rows[row + i] = v.toByte()
            }
            input += stride
        }

        if (channels == 4) return Image(width, height, rows)
        val rgba = ByteArray(width * height * 4) { -1 }
        for (p in 0 until width * height) {
            rgba[p * 4] = rows[p * 3]
            rgba[p * 4 + 1] = rows[p * 3 + 1]
            rgba[p * 4 + 2] = rows[p * 3 + 2]
        }
        return Image(width, height, rgba)
    }

    /**
     * Inflates raw DEFLATE data (the zlib stream from `offset`, past its 2-byte header), up to
     * `expected` bytes and a little more. Null when nothing inflates.
     */
    private fun inflate(input: ByteArray, offset: Int, expected: Int): ByteArray? {
        val output = ByteArray(expected + 64)
        val inflater = Inflater(true)
        var written = 0
        try {
            // A trailing byte past the stream, as `Inflater`'s raw mode asks for (the zlib
            // checksum that follows the DEFLATE data serves when present).
            inflater.setInput(input + 0.toByte(), offset, input.size - offset + 1)
            while (written < output.size && !inflater.finished()) {
                val n = inflater.inflate(output, written, output.size - written)
                if (n == 0 && (inflater.needsInput() || inflater.needsDictionary())) break
                written += n
            }
        } catch (e: DataFormatException) {
            // Like the system decoder, keep what inflated before the error.
        } finally {
            inflater.end()
        }
        if (written <= 0) return null
        return output.copyOf(written)
    }
}
