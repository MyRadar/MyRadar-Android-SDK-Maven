package com.acmeaom.myradar.sdk.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface

/**
 * Files the engine ships in the SDK's assets (`assets/myradar-sdk/`): the Inter typeface its
 * labels use and the lightning marker. [MapEngineView] installs the app context on creation.
 */
internal object EngineAssets {
    @Volatile private var appContext: Context? = null

    fun install(context: Context) {
        if (appContext == null) appContext = context.applicationContext
    }

    /** Inter SemiBold, the engine's label typeface; the system default when it can't be loaded. */
    val interSemiBold: Typeface by lazy {
        appContext?.let { runCatching { Typeface.createFromAsset(it.assets, "myradar-sdk/Inter-SemiBold.ttf") }.getOrNull() }
            ?: Typeface.DEFAULT_BOLD
    }

    /** An image from the SDK's assets, unscaled. */
    fun bitmap(name: String): Bitmap? = appContext?.let { context ->
        runCatching {
            context.assets.open("myradar-sdk/$name").use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inScaled = false })
            }
        }.getOrNull()
    }

    /** Screen pixels per point (dp). */
    val density: Float get() = appContext?.resources?.displayMetrics?.density ?: 1f
}
