// Decodes Mapbox Vector Tiles (protobuf): layers of features with properties and geometry in
// tile units (0..extent, y down).

package com.acmeaom.myradar.sdk.engine.basemap

/** A point in tile units. */
/**
 * A ring or line in tile units as interleaved x, y floats. Points are packed rather than objects
 * because a large tile holds hundreds of thousands of them.
 */
internal typealias Ring = FloatArray

/** The number of points in a ring. */
internal val Ring.pointCount: Int get() = size / 2

internal data class VectorTileFeature(
    /** The feature id: an unsigned 64-bit protobuf varint. */
    val id: ULong?,
    val type: GeometryType,
    val properties: Map<String, FeatureValue>,
    /** Points, lines or rings, in tile units. */
    val geometry: List<Ring>,
)

internal data class VectorTileLayer(
    val name: String,
    val extent: Float,
    val features: List<VectorTileFeature>,
)

internal object VectorTileDecoder {
    /** Decodes the layers whose names are in [wanted] (all layers when null). */
    fun decode(data: ByteArray, wanted: Set<String>? = null): Map<String, VectorTileLayer> {
        val layers = LinkedHashMap<String, VectorTileLayer>()
        val reader = ProtobufReader(data, 0, data.size)
        while (reader.nextField()) {
            val field = reader.field
            val wire = reader.wire
            if (field != 3 || wire != 2) {
                reader.skip(wire)
                continue
            }
            // The layer's bytes are consumed here whether or not it's wanted.
            val sub = reader.subMessage() ?: continue
            val layer = decodeLayer(sub, wanted) ?: continue
            layers[layer.name] = layer
        }
        return layers
    }

    private fun decodeLayer(reader: ProtobufReader, wanted: Set<String>?): VectorTileLayer? {
        var name = ""
        var extent = 4096f
        val keys = ArrayList<String>()
        val values = ArrayList<FeatureValue>()
        val featureReaders = ArrayList<ProtobufReader>()
        while (reader.nextField()) {
            val field = reader.field
            val wire = reader.wire
            when {
                field == 1 && wire == 2 -> name = reader.string()
                field == 2 && wire == 2 -> reader.subMessage()?.let { featureReaders.add(it) }
                field == 3 && wire == 2 -> keys.add(reader.string())
                field == 4 && wire == 2 ->
                    values.add(reader.subMessage()?.let(::decodeValue) ?: FeatureValue.StringValue(""))
                field == 5 && wire == 0 -> extent = reader.varint().toULong().toFloat()
                else -> reader.skip(wire)
            }
            // Skip the rest of a layer nobody draws as soon as its name is known.
            if (field == 1 && wanted != null && name !in wanted) return null
        }
        val features = featureReaders.map { decodeFeature(it, keys, values) }
        return VectorTileLayer(name, extent, features)
    }

    private fun decodeValue(reader: ProtobufReader): FeatureValue? {
        var result: FeatureValue? = null
        while (reader.nextField()) {
            val field = reader.field
            val wire = reader.wire
            result = when {
                field == 1 && wire == 2 -> FeatureValue.StringValue(reader.string())
                field == 2 && wire == 5 -> FeatureValue.NumberValue(Float.fromBits(reader.fixed32()).toDouble())
                field == 3 && wire == 1 -> FeatureValue.NumberValue(Double.fromBits(reader.fixed64()))
                field == 4 && wire == 0 -> FeatureValue.NumberValue(reader.varint().toDouble())
                field == 5 && wire == 0 -> FeatureValue.NumberValue(reader.varint().toULong().toDouble())
                field == 6 && wire == 0 -> FeatureValue.NumberValue(ProtobufReader.zigzag(reader.varint()).toDouble())
                field == 7 && wire == 0 -> FeatureValue.BoolValue(reader.varint() != 0L)
                else -> {
                    reader.skip(wire)
                    result
                }
            }
        }
        return result
    }

    private fun decodeFeature(reader: ProtobufReader, keys: List<String>, values: List<FeatureValue>): VectorTileFeature {
        var id: ULong? = null
        var type = GeometryType.POINT
        var tags = IntArray(0)
        var commands = IntArray(0)
        while (reader.nextField()) {
            val field = reader.field
            val wire = reader.wire
            when {
                field == 1 && wire == 0 -> id = reader.varint().toULong()
                field == 2 && wire == 2 -> tags = reader.packedUInt32()
                field == 3 && wire == 0 -> {
                    val raw = reader.varint()
                    type = (if (raw in 1L..3L) GeometryType.fromRawValue(raw.toInt()) else null) ?: GeometryType.POINT
                }
                field == 4 && wire == 2 -> commands = reader.packedUInt32()
                else -> reader.skip(wire)
            }
        }
        val properties = HashMap<String, FeatureValue>()
        var i = 0
        while (i + 1 < tags.size) {
            // Tags are unsigned 32-bit; a negative Int here is an index past 2^31, never valid.
            val k = tags[i]
            val v = tags[i + 1]
            if (k >= 0 && k < keys.size && v >= 0 && v < values.size) properties[keys[k]] = values[v]
            i += 2
        }
        return VectorTileFeature(id, type, properties, decodeGeometry(commands))
    }

    private fun decodeGeometry(commands: IntArray): List<Ring> {
        val parts = ArrayList<Ring>()
        val current = FloatList(64)
        var x = 0
        var y = 0
        var i = 0
        while (i < commands.size) {
            val command = commands[i] and 7
            val count = commands[i] ushr 3
            i += 1
            when (command) {
                1, 2 -> {
                    if (command == 1 && current.size > 0) {
                        parts.add(current.toArray())
                        current.clear()
                    }
                    // Stops early when the parameters run out (the remaining iterations would do nothing).
                    var n = 0
                    while (n < count && i + 1 < commands.size) {
                        // 32-bit zigzag on the raw bits, wrapping like the tile's int32 arithmetic.
                        x += ProtobufReader.zigzag32(commands[i])
                        y += ProtobufReader.zigzag32(commands[i + 1])
                        current.add(x.toFloat()); current.add(y.toFloat())
                        i += 2
                        n += 1
                    }
                }
                7 -> if (current.size > 0) { current.add(current.data[0]); current.add(current.data[1]) }
                else -> i = commands.size
            }
        }
        if (current.size > 0) parts.add(current.toArray())
        return parts
    }
}

/**
 * A minimal protobuf wire-format reader over a byte range. Unsigned values are returned as the
 * raw bits in signed `Int`/`Long`s.
 */
internal class ProtobufReader(private val data: ByteArray, start: Int, val end: Int) {
    var position: Int = start
        private set

    /** The field number and wire type read by the last successful [nextField]. */
    var field: Int = 0
        private set
    var wire: Int = 0
        private set

    /** Reads the next field key into [field] and [wire]; false at the end. */
    fun nextField(): Boolean {
        if (position >= end) return false
        val key = varint()
        val f = key ushr 3
        // A field number past Int.MAX_VALUE matches nothing.
        field = if (f > Int.MAX_VALUE) -1 else f.toInt()
        wire = (key and 7).toInt()
        return true
    }

    fun varint(): Long {
        var result = 0L
        var shift = 0
        while (position < end) {
            val byte = data[position].toInt()
            position += 1
            result = result or ((byte and 0x7f).toLong() shl shift)
            if (byte and 0x80 == 0) break
            shift += 7
            if (shift > 63) break
        }
        return result
    }

    fun fixed32(): Int {
        if (position + 4 > end) { position = end; return 0 }
        var v = 0
        for (i in 0 until 4) v = v or ((data[position + i].toInt() and 0xff) shl (8 * i))
        position += 4
        return v
    }

    fun fixed64(): Long {
        if (position + 8 > end) { position = end; return 0 }
        var v = 0L
        for (i in 0 until 8) v = v or ((data[position + i].toLong() and 0xff) shl (8 * i))
        position += 8
        return v
    }

    /** A length-delimited field as its own reader, or null (consuming the rest) when it overruns. */
    fun subMessage(): ProtobufReader? {
        val length = varint()
        if (length < 0 || length > end - position) { position = end; return null }
        val sub = ProtobufReader(data, position, position + length.toInt())
        position += length.toInt()
        return sub
    }

    fun string(): String {
        val length = varint()
        if (length < 0 || length > end - position) { position = end; return "" }
        val s = String(data, position, length.toInt(), Charsets.UTF_8)
        position += length.toInt()
        return s
    }

    /** Packed varints truncated to 32 bits. */
    fun packedUInt32(): IntArray {
        val sub = subMessage() ?: return IntArray(0)
        var values = IntArray(16)
        var count = 0
        while (sub.position < sub.end) {
            if (count == values.size) values = values.copyOf(count * 2)
            values[count++] = sub.varint().toInt()
        }
        return values.copyOf(count)
    }

    fun skip(wire: Int) {
        var next = position.toLong()
        when (wire) {
            0 -> { varint(); next = position.toLong() }
            1 -> next += 8
            2 -> {
                val length = varint()
                // A huge (or negative-as-signed) length runs to the end.
                next = if (length < 0 || length > end - position) end.toLong() else position + length
            }
            5 -> next += 4
            else -> next = end.toLong()
        }
        position = minOf(next, end.toLong()).toInt()
    }

    companion object {
        fun zigzag(n: Long): Long = (n ushr 1) xor -(n and 1)

        /** [zigzag] on a 32-bit value; equals the 64-bit result truncated to 32 bits. */
        fun zigzag32(n: Int): Int = (n ushr 1) xor -(n and 1)
    }
}
