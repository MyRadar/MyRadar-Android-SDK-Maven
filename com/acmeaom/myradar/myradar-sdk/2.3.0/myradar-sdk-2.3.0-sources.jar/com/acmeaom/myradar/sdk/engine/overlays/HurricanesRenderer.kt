package com.acmeaom.myradar.sdk.engine.overlays

import com.acmeaom.myradar.sdk.LatLng
import com.acmeaom.myradar.sdk.engine.EngineAssets
import com.acmeaom.myradar.sdk.engine.MapEngineView
import com.acmeaom.myradar.sdk.engine.basemap.RGBA
import com.acmeaom.myradar.sdk.engine.basemap.jsonObject
import com.acmeaom.myradar.sdk.engine.basemap.jsonObjects
import com.acmeaom.myradar.sdk.engine.basemap.parseJson
import com.acmeaom.myradar.sdk.engine.camera.MapTransform
import com.acmeaom.myradar.sdk.engine.camera.ScreenPoint
import com.acmeaom.myradar.sdk.engine.camera.Vec2
import com.acmeaom.myradar.sdk.engine.gl.RenderContext
import com.acmeaom.myradar.sdk.engine.tiles.EngineNetwork
import com.acmeaom.myradar.sdk.internal.GatewayConfiguration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.ParsePosition
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * Active tropical cyclones. Port of the engine's `Hurricanes3` (`Hurricanes2` on the v3 feed,
 * module version 4) drawn the way `FWGeoJsonModule` draws it:
 *
 * - The feed is polled every 5 minutes. Each storm's course line is assigned to the storm whose
 *   points are nearest and split at the point closest to the current position into a past and
 *   a future track; the storm center, the tracks and the cone are each switched on separately.
 * - Every shape gets the old hurricane colors: fill #1a1a1a at 10%, stroke #b3b3b3, 1 point
 *   wide, all at the layer's opacity (0.65 by default).
 * - Current positions get the storm glyph tinted with its color, spinning at 0.04 turns a second
 *   in the storm's direction; past and forecast points get a tinted dot with the category letter.
 * - Forecast and current points get a "11/12 000UTC 83kph" label beside them. Forecast labels
 *   show while the map moves and fade out 2 seconds after it stops (`FadeModule`); the current
 *   one fades to the layer opacity.
 * - With no storms, "No tropical cyclones" shows off the Atlantic and Pacific coasts.
 */

/** What the hurricanes layer shows, from the map's preferences. */
internal data class HurricanesSettings(
    val enabled: Boolean = false,
    val futureTrack: Boolean = true,
    val pastTrack: Boolean = true,
    val cone: Boolean = true,
    val stormCenter: Boolean = true,
    val opacity: Float = 0.65f,
)

/** Draws the hurricanes layer. Main thread only. */
internal class HurricanesRenderer(private val network: EngineNetwork) {
    var onNeedsDisplay: (() -> Unit)? = null

    var settings: HurricanesSettings = HurricanesSettings()
        set(value) {
            val old = field
            if (value == old) return
            field = value
            if (value.enabled != old.enabled) {
                if (value.enabled) {
                    startPolling()
                } else {
                    stopPolling(); features = emptyList(); feedLoaded = false
                }
            }
            rebuild()
        }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var pollJob: Job? = null
    private var rawFeatures: List<Feature> = emptyList()
    private var features: List<Feature> = emptyList()
    private var feedLoaded = false
    private var shapes: MercatorShapes? = null
    private var icons: List<Icon> = emptyList()
    private var labels: List<Label> = emptyList()
    private var builtAt = 0.0
    /** `FadeModule::_fadeStartTimestamp`: 2 seconds after the map last moved. */
    private var fadeStart = 0.0

    /** Multiplies the size of labels and lettered track points. */
    var textScale: Float = 1f
        set(value) {
            if (value == field) return
            field = value
            rebuild()
        }

    /** A feed feature in Web Mercator. */
    sealed class Geometry {
        data class Point(val mercator: Vec2, val coordinate: LatLng) : Geometry()
        data class Line(val points: List<Vec2>) : Geometry()
        data class Polygons(val polygons: List<List<List<Vec2>>>) : Geometry()
    }

    data class Feature(
        val id: String,
        val geometry: Geometry,
        val properties: Map<String, Any?>,
        /** "past_track" or "future_track" for the split course. */
        val trackKind: String? = null,
    ) {
        val featureType: String get() = properties["feature_type"] as? String ?: ""
    }

    private class Icon(
        val sprite: Sprite,
        /** Only the storm's current-position icon responds to taps, as in the engine. */
        val tapFeature: Map<String, Any?>?,
        /** Turns per second, counterclockwise positive; 0 for still icons. */
        val spin: Double,
    )

    private class Label(
        val sprite: Sprite,
        /** Forecast labels fade to 0 once the map is still; the current one to the layer opacity. */
        val fadesOut: Boolean,
    )

    /** The map moved (`FadeModule::mapMoved`). `now` is on the render clock. */
    fun mapMoved(now: Double = MapEngineView.nowSeconds()) {
        fadeStart = now + 2
    }

    /** Stops polling. The renderer can't be used afterwards. */
    fun dispose() {
        scope.cancel()
        pollJob = null
    }

    // MARK: Feed

    /**
     * Whether the feed may poll. The map turns it off while it isn't drawing (detached or in the
     * background), which also lets a discarded map be collected.
     */
    var feedsActive = true
        set(value) {
            if (value == field) return
            field = value
            if (!value) stopPolling() else if (settings.enabled) startPolling()
        }

    private fun startPolling() {
        if (pollJob != null || !feedsActive) return
        pollJob = scope.launch {
            while (isActive) {
                val data = try {
                    network.data(FEED_URL)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    null
                }
                if (data != null) {
                    val parsed = withContext(Dispatchers.Default) { parse(data) }
                    if (parsed != null) {
                        rawFeatures = parsed
                        feedLoaded = true
                        rebuild()
                    }
                }
                delay(UPDATE_INTERVAL_MS)
            }
        }
    }

    private fun stopPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    // MARK: Graphics

    /** `Hurricanes2::updateGraphics` over `FWGeoJsonModule::updateGraphics`. */
    private fun rebuild() {
        shapes = null
        icons = emptyList()
        labels = emptyList()
        if (!settings.enabled || !feedLoaded) {
            onNeedsDisplay?.invoke()
            return
        }
        features = process(rawFeatures, settings)
        builtAt = MapEngineView.nowSeconds()
        val scale = EngineAssets.density

        // Shapes, least important (last) first: fill #1a1a1a1a, stroke #ffb3b3b3 (ARGB), 1 point.
        // The engine blends the fill's channels as they are, as a premultiplied color: white at 10%.
        val c = 0x1a / 255f
        val fillPremultiplied = RGBA(c, c, c, c)
        val s = 0xb3 / 255f
        val stroke = RGBA(s, s, s, 1f)
        var builder: MercatorShapeBuilder? = null
        for (f in features.asReversed()) {
            when (val g = f.geometry) {
                is Geometry.Polygons -> {
                    val origin = g.polygons.firstOrNull()?.firstOrNull()?.firstOrNull() ?: continue
                    val b = builder ?: MercatorShapeBuilder(origin).also { builder = it }
                    for (poly in g.polygons) {
                        b.addFill(poly, fillPremultiplied)
                        for (ring in poly) b.addLine(ring, 1f, stroke, closed = true)
                    }
                }
                is Geometry.Line -> {
                    val origin = g.points.firstOrNull() ?: continue
                    if (g.points.size < 2) continue
                    val b = builder ?: MercatorShapeBuilder(origin).also { builder = it }
                    b.addLine(g.points, 1f, stroke)
                }
                is Geometry.Point -> continue
            }
        }
        builder?.takeIf { !it.isEmpty }?.let { shapes = MercatorShapes(it) }

        // Icons, least important first, fading in like new stamps.
        val newIcons = ArrayList<Icon>()
        for (f in features.asReversed()) {
            val point = f.geometry as? Geometry.Point ?: continue
            val p = f.properties
            val colorString = p["display_icon_color"] as? String ?: p["icon_color"] as? String ?: ""
            val color = RGBA.fromCss(colorString) ?: RGBA.black
            var spin = 0.0
            val image = when (f.featureType) {
                "Current" -> {
                    val glyph = p["display_icon_glyph"] as? String ?: p["icon_glyph"] as? String ?: ""
                    val rotation = (p["display_rotation"] as? String)?.takeIf { it.isNotEmpty() }
                        ?: p["rotation"] as? String ?: ""
                    spin = when (rotation) {
                        "Anticlockwise" -> 0.04
                        "Clockwise" -> -0.04
                        else -> 0.0
                    }
                    HurricaneGraphics.stormIcon(glyph, color, scale)
                }
                "Previous", "Forecast" -> {
                    val text = p["display_icon_text"] as? String ?: p["icon_text"] as? String ?: ""
                    HurricaneGraphics.pointIcon(text, color, scale, textScale)
                }
                else -> null
            } ?: continue
            val texture = image.texture() ?: continue
            val tapFeature = if (f.featureType == "Current") {
                mapOf("type" to "Feature", "id" to f.id, "properties" to p, "object_type" to "hurricane")
            } else {
                null
            }
            newIcons.add(Icon(Sprite(texture, point.mercator, image.width, image.height), tapFeature, spin))
        }
        icons = newIcons

        // Date labels beside forecast and current points; the current one in front.
        val newLabels = ArrayList<Label>()
        if (features.isEmpty()) {
            // `noStormGraphics`.
            for ((lat, lon, side) in listOf(Triple(31.3, -73.7, 1f), Triple(30.6, -123.9, -1f))) {
                val image = HurricaneGraphics.label("No tropical cyclones", scale, textScale) ?: continue
                val texture = image.texture() ?: continue
                val position = MapTransform.mercator(LatLng(lat, lon))
                newLabels.add(Label(Sprite(texture, position, image.width, image.height,
                    anchorX = side * image.width), fadesOut = false))
            }
        } else {
            val current = ArrayList<Label>()
            for (f in features) {
                val point = f.geometry as? Geometry.Point ?: continue
                if (f.featureType == "Previous") continue
                val text = labelText(f.properties) ?: continue
                val isCurrent = f.featureType == "Current"
                val image = HurricaneGraphics.label(text, scale, textScale) ?: continue
                val texture = image.texture() ?: continue
                val offset = (if (isCurrent) 20f else 10f) * textScale
                val label = Label(Sprite(texture, point.mercator, image.width, image.height,
                    anchorX = image.width / 2 + offset), fadesOut = !isCurrent)
                if (isCurrent) current.add(label) else newLabels.add(label)
            }
            newLabels.addAll(current)
        }
        labels = newLabels
        onNeedsDisplay?.invoke()
    }

    /**
     * The storms whose icon is under a screen point (dp), as their GeoJSON features with
     * `"object_type": "hurricane"`.
     */
    fun features(point: ScreenPoint, transform: MapTransform): List<Map<String, Any?>> {
        if (!settings.enabled) return emptyList()
        val projection = transform.projectionMatrix
        return icons.asReversed().mapNotNull { icon ->
            val feature = icon.tapFeature ?: return@mapNotNull null
            for (wrap in doubleArrayOf(-1.0, 0.0, 1.0)) {
                val p = transform.screenPoint(icon.sprite.position + Vec2(wrap, 0.0), projection) ?: continue
                if (abs(point.x - p.x) <= icon.sprite.width / 2 && abs(point.y - p.y) <= icon.sprite.height / 2) {
                    return@mapNotNull feature
                }
            }
            null
        }
    }

    // MARK: Drawing

    /** Cones and tracks, over the radar. */
    fun drawShapes(context: RenderContext) {
        if (!settings.enabled) return
        shapes?.draw(context, fillOpacity = settings.opacity, lineOpacity = settings.opacity)
    }

    /** Date labels, behind the storm icons and lightning markers. */
    fun drawLabels(context: RenderContext) {
        if (!settings.enabled || labels.isEmpty()) return
        val now = context.now
        // `computeTimeBasedFadeAlpha` with a 1 second fade, after `computeAndUpdateHideShowFadeAlpha`.
        val fade = ((now - fadeStart) / 1).coerceIn(0.0, 1.0).toFloat()
        val fadeIn = ((now - builtAt) / 0.45).coerceIn(0.0, 1.0).toFloat()
        val sprites = labels.map { label ->
            val minimum = if (label.fadesOut) 0f else settings.opacity
            label.sprite.copy(alpha = (1 - (1 - minimum) * fade) * fadeIn)
        }
        SpriteDrawer.draw(context, sprites)
    }

    /**
     * Storm icons, on top. Returns when the layer next needs a frame, on the render clock (the
     * spin runs at 10 fps, fades every frame), or null when it's still.
     */
    fun drawIcons(context: RenderContext): Double? {
        if (!settings.enabled || (icons.isEmpty() && labels.isEmpty())) return null
        val now = context.now
        val fadeIn = ((now - builtAt) / 0.45).coerceIn(0.0, 1.0).toFloat()
        val wallClock = System.currentTimeMillis() / 1000.0
        val sprites = icons.map { icon ->
            var sprite = icon.sprite.copy(alpha = fadeIn)
            if (icon.spin != 0.0) {
                // `FWGPURotateAnimation::transformForTime`.
                val fraction = (wallClock * icon.spin) % 1.0
                sprite = sprite.copy(rotation = (-(0.5 - fraction) * 2 * PI).toFloat())
            }
            sprite
        }
        SpriteDrawer.draw(context, sprites)
        val fading = fadeIn < 1 || (now >= fadeStart - 2 && now < fadeStart + 1)
        if (fading) return now
        return if (icons.any { it.spin != 0.0 }) now + 0.1 else null
    }

    companion object {
        private val FEED_URL = GatewayConfiguration.endpoint("/v3/cyclones/current/full")
        private const val UPDATE_INTERVAL_MS = 5 * 60 * 1000L

        fun parse(data: ByteArray): List<Feature>? {
            val json = jsonObject(parseJson(data)) ?: return null
            val list = jsonObjects(json["features"]) ?: return null
            return list.mapNotNull { f ->
                val geometry = jsonObject(f["geometry"]) ?: return@mapNotNull null
                val type = geometry["type"] as? String ?: return@mapNotNull null
                val properties = jsonObject(f["properties"]) ?: emptyMap()
                val id = when (val raw = f["id"]) {
                    is String -> raw
                    is Double -> if (raw % 1.0 == 0.0 && abs(raw) < 1e15) raw.toLong().toString() else raw.toString()
                    else -> ""
                }
                val coordinates = geometry["coordinates"]
                when (type) {
                    "Point" -> {
                        val c = positionOf(coordinates) ?: return@mapNotNull null
                        val m = merc(c) ?: return@mapNotNull null
                        Feature(id, Geometry.Point(m, LatLng(c[1], c[0])), properties)
                    }
                    "LineString" -> Feature(id, Geometry.Line(positions(coordinates).mapNotNull(::merc)), properties)
                    "Polygon" -> {
                        val rings = (nested(coordinates) { positions(it) } ?: emptyList()).map { it.mapNotNull(::merc) }
                        Feature(id, Geometry.Polygons(listOf(rings)), properties)
                    }
                    "MultiPolygon" -> {
                        val polys = (nested(coordinates) { poly -> nested(poly) { positions(it) } } ?: emptyList())
                            .map { poly -> poly.map { ring -> ring.mapNotNull(::merc) } }
                        Feature(id, Geometry.Polygons(polys), properties)
                    }
                    else -> null
                }
            }
        }

        private fun merc(c: List<Double>): Vec2? =
            if (c.size >= 2) MapTransform.mercator(LatLng(c[1], c[0])) else null

        /** A GeoJSON position as numbers, or null. */
        private fun positionOf(raw: Any?): List<Double>? {
            val list = raw as? List<*> ?: return null
            return list.map { it as? Double ?: return null }
        }

        /** A list of positions; empty unless every element is a position (as a Swift cast would be). */
        private fun positions(raw: Any?): List<List<Double>> =
            nested(raw) { item -> positionOf(item) } ?: emptyList()

        /** A list whose every element converts, or null. */
        private fun <T> nested(raw: Any?, element: (Any?) -> T?): List<T>? {
            val list = raw as? List<*> ?: return null
            return list.map { element(it) ?: return null }
        }

        /**
         * `Hurricanes2::parseResponse`: storms grouped by id (in id order), courses split into past
         * and future tracks, then the module version 4 element switches.
         */
        fun process(raw: List<Feature>, s: HurricanesSettings): List<Feature> {
            val storms = HashMap<String, MutableList<Feature>>()
            val withoutID = ArrayList<Feature>()
            for (f in raw) {
                if (f.featureType == "Course") continue
                if (f.id.isEmpty()) withoutID.add(f) else storms.getOrPut(f.id) { ArrayList() }.add(f)
            }
            val points = raw.mapNotNull { f -> (f.geometry as? Geometry.Point)?.let { f.id to it.coordinate } }
            for (f in raw) {
                if (f.featureType != "Course") continue
                val coords = (f.geometry as? Geometry.Line)?.points ?: continue
                if (coords.isEmpty()) continue
                val locations = coords.map(MapTransform::coordinate)
                // The storm whose points are nearest most of the course.
                val nearestIDs = locations.map { p ->
                    points.minByOrNull { distance(it.second, p) }?.first ?: ""
                }.sorted()
                val id = nearestIDs[nearestIDs.size / 2]
                val current = storms[id]?.lastOrNull { it.featureType == "Current" } ?: continue
                val currentLocation = (current.geometry as? Geometry.Point)?.coordinate ?: continue
                val split = locations.indices.minByOrNull { distance(locations[it], currentLocation) }!!
                val past = ArrayList<Vec2>(); val future = ArrayList<Vec2>()
                for (i in coords.indices) {
                    if (i < split || (i == split && s.stormCenter)) past.add(coords[i])
                    if (i > split || (i == split && s.stormCenter)) future.add(coords[i])
                }
                val storm = storms.getOrPut(id) { ArrayList() }
                storm.add(Feature(id, Geometry.Line(past), f.properties, "past_track"))
                storm.add(Feature(id, Geometry.Line(future), f.properties, "future_track"))
            }
            val result = storms.keys.sorted().flatMap { storms.getValue(it) } + withoutID
            return result.filterNot { f ->
                when {
                    f.featureType == "Current" -> !s.stormCenter
                    f.geometry is Geometry.Point && f.featureType == "Forecast" -> !s.futureTrack
                    f.geometry is Geometry.Point && f.featureType == "Previous" -> !s.pastTrack
                    f.geometry is Geometry.Polygons -> !s.cone
                    f.trackKind == "future_track" -> !s.futureTrack
                    f.trackKind == "past_track" -> !s.pastTrack
                    else -> false
                }
            }
        }

        /** Great-circle angle between two coordinates, in radians. */
        private fun distance(a: LatLng, b: LatLng): Double {
            val la1 = a.latitude * PI / 180; val la2 = b.latitude * PI / 180
            val dLat = la2 - la1; val dLon = (b.longitude - a.longitude) * PI / 180
            val h = sin(dLat / 2) * sin(dLat / 2) + cos(la1) * cos(la2) * sin(dLon / 2) * sin(dLon / 2)
            return 2 * atan2(sqrt(h), sqrt(1 - h))
        }

        /**
         * The label for a point: its `display_date`, or with the client format (the default),
         * "5/30 1100UTC 139kph" from `ts` and `msw_kph`, in UTC and km/h as the SDK leaves the
         * engine's time zone and unit preferences.
         */
        fun labelText(p: Map<String, Any?>): String? {
            var text = p["display_date"] as? String ?: ""
            val ts = p["ts"] as? String
            val kph = (p["msw_kph"] as? Number)?.toDouble()
            val date = ts?.let(::parseISO8601)
            if (kph != null && date != null) {
                val c = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US).apply { time = date }
                // "%Jm/%Jd %JH%M": month, day and hour without leading zeros.
                text = String.format(Locale.US, "%d/%d %d%02dUTC", c.get(Calendar.MONTH) + 1,
                    c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
                text += " ${kph.toInt()}kph"
            }
            return text.ifEmpty { null }
        }

        /** An internet date-time without fractional seconds, like `ISO8601DateFormatter`'s default. */
        private fun parseISO8601(text: String): java.util.Date? {
            val position = ParsePosition(0)
            val date = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).apply { isLenient = false }
                .parse(text, position)
            // The whole string must be the date.
            return if (position.index == text.length) date else null
        }
    }
}
