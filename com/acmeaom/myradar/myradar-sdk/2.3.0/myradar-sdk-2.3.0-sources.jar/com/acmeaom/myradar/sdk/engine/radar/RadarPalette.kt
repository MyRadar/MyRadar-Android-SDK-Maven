package com.acmeaom.myradar.sdk.engine.radar

import com.acmeaom.myradar.sdk.engine.basemap.parseJson

/**
 * A radar palette and its lookup bitmap. Port of the engine's `FWMorphingProgram::makePalette`
 * and `palettizeSampleWithSpan`: one row per palette row (rain, mix, snow), one column per raw
 * sample value, colors premultiplied. Column 0 stays clear so samples at the floor draw nothing.
 */
internal class RadarPalette private constructor(
    /** The palette JSON, as reported to the map view's listener. */
    val json: String,
    val width: Int,
    val rows: Int,
    /** Premultiplied RGBA, `rows` rows of `width` pixels. */
    val pixels: ByteArray,
) {
    companion object {
        /**
         * The bitmap's width: one column per 8-bit sample value. (The engine lets a palette's
         * properties override it; none of the SDK's palettes do.)
         */
        private const val WIDTH = 256

        /** Builds a palette from its JSON; null when the JSON isn't a palette. */
        fun parse(json: String): RadarPalette? {
            val palette = parseJson(json) as? Map<*, *> ?: return null
            val properties = palette["properties"] as? Map<*, *> ?: return null
            val paletteRows = (palette["rows"] as? List<*>)?.map { it as? Map<*, *> ?: return null } ?: return null
            val (slope, intercept) = decodingFunctionCoefficients(properties)
            val width = WIDTH
            val pixels = ByteArray(width * paletteRows.size * 4)
            for ((rowIndex, row) in paletteRows.withIndex()) {
                val spans = (row["spans"] as? List<*>)?.takeIf { l -> l.all { it is Map<*, *> } }
                    ?.map { it as Map<*, *> } ?: emptyList()
                val last = spans.lastOrNull() ?: continue
                for (column in 1 until width) {
                    val decoded = column * slope + intercept
                    var span = last
                    for (candidate in spans) {
                        val max = (candidate["max_val_exclusive"] as? Number)?.toDouble()
                        if (max == null || decoded < max) {
                            span = candidate
                            break
                        }
                    }
                    // As the engine does, the sample is a float on its way to the span.
                    val c = palettize(decoded.toFloat(), span).premultiplied
                    val o = (rowIndex * width + column) * 4
                    pixels[o] = c.r.toByte(); pixels[o + 1] = c.g.toByte()
                    pixels[o + 2] = c.b.toByte(); pixels[o + 3] = c.a.toByte()
                }
            }
            return RadarPalette(json, width, paletteRows.size, pixels)
        }

        /** `FWMorphingProgram::decodingFunctionCoefficients`; the defaults decode deep radar tiles. */
        fun decodingFunctionCoefficients(properties: Map<*, *>): Pair<Double, Double> {
            val c = properties["decoding_function_coefficients"] as? List<*>
            if (c != null && c.size >= 2 && c.all { it is Number }) {
                return (c[0] as Number).toDouble() to (c[1] as Number).toDouble()
            }
            return 0.333333333333333 to 0.0
        }

        /** `FWMorphingProgram::palettizeSampleWithSpan`. */
        fun palettize(value: Float, span: Map<*, *>): RGBA8 {
            val minVal = (span["min_val_inclusive"] as? Number)?.toDouble() ?: Double.NEGATIVE_INFINITY
            val maxVal = (span["max_val_exclusive"] as? Number)?.toDouble() ?: Double.POSITIVE_INFINITY
            var lerp = ((value.toDouble() - minVal) / (maxVal - minVal)).coerceIn(0.0, 1.0)
            if (lerp.isNaN()) lerp = 0.0
            val start = RGBA8.fromArgbHex(span["start_color_argb"] as? String ?: "")
            val end = RGBA8.fromArgbHex(span["end_color_argb"] as? String ?: "")
            return RGBA8.lerp(start, end, lerp.toFloat())
        }
    }
}

/** An 8-bit straight-alpha color (components 0...255), with the engine's integer color helpers. */
internal data class RGBA8(val r: Int, val g: Int, val b: Int, val a: Int) {
    /** `FWColorPremultiplyRGBA`: alpha scaled to 0...256 so 0xff is fully opaque. */
    val premultiplied: RGBA8
        get() {
            val alpha = (a shl 8) / 255
            fun m(v: Int) = ((alpha * v) shr 8) and 0xFF
            return RGBA8(m(r), m(g), m(b), a)
        }

    companion object {
        /** Parses `0xAARRGGBB` (`FWColor::colorFromArgbHexString` after the `0x`). */
        fun fromArgbHex(s: String): RGBA8 {
            val hex = if (s.length >= 2) s.substring(2) else ""
            val v = hex.toUIntOrNull(16)?.toLong() ?: 0L
            return RGBA8(
                r = ((v shr 16) and 0xFF).toInt(),
                g = ((v shr 8) and 0xFF).toInt(),
                b = (v and 0xFF).toInt(),
                a = ((v shr 24) and 0xFF).toInt(),
            )
        }

        /** `FWColorLerp`: fixed-point, with the first color rounding up and the second down. */
        fun lerp(x: RGBA8, y: RGBA8, t: Float): RGBA8 {
            val l = (256f * t).toLong()
            val lc = 256 - l
            fun c(p: Int, q: Int): Int = ((((lc * p + 0x80) shr 8) + ((l * q + 0x7f) shr 8)) and 0xFF).toInt()
            return RGBA8(c(x.r, y.r), c(x.g, y.g), c(x.b, y.b), c(x.a, y.a))
        }
    }
}
