package com.acmeaom.myradar.sdk.internal

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.DisplayMetrics
import androidx.annotation.ColorInt
import androidx.annotation.MainThread
import com.acmeaom.myradar.sdk.CoordinateRegion
import com.acmeaom.myradar.sdk.FlightException
import com.acmeaom.myradar.sdk.FlightInfo
import com.acmeaom.myradar.sdk.FlightOptions
import com.acmeaom.myradar.sdk.LatLng
import com.acmeaom.myradar.sdk.MapMarker
import com.acmeaom.myradar.sdk.MapPolyline
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.NumberFormat
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Loads the flight shown by `MyRadarMapView.showFlight`, keeps it updated until it lands, and
 * turns it into polylines and markers that the map view draws alongside the app's own.
 */
@MainThread
internal class FlightController(
    private val host: Host,
    private val displayMetrics: DisplayMetrics,
) {
    /** What the controller needs from the map view. */
    interface Host {
        fun flightShapesDidChange()
        fun flightDidUpdate(info: FlightInfo)
        fun flightDidFail(error: FlightException)
        fun fitRegion(region: CoordinateRegion, animated: Boolean)
    }

    var info: FlightInfo? = null
        private set
    var polylines: List<MapPolyline> = emptyList()
        private set
    var markers: List<MapMarker> = emptyList()
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val icons = FlightIcons(displayMetrics)
    private var ident = ""
    private var options = FlightOptions()
    private var generation = 0
    private var refreshJob: Job? = null
    private var paused = false

    suspend fun show(ident: String, options: FlightOptions): FlightInfo {
        clear()
        val generation = generation
        this.ident = ident
        this.options = options
        try {
            val info = FlightData.lookUp(ident)
            // A later showFlight or removeFlight replaced this one while it loaded.
            if (generation != this.generation) throw CancellationException("Replaced by another flight")
            apply(info)
            if (options.fitToFlight) fit(animated = false)
            scheduleRefresh()
            return info
        } catch (e: FlightException) {
            if (generation == this.generation) host.flightDidFail(e)
            throw e
        }
    }

    /** Removes the flight from the map and stops updating it. */
    fun clear() {
        generation++
        refreshJob?.cancel()
        refreshJob = null
        info = null
        polylines = emptyList()
        markers = emptyList()
        host.flightShapesDidChange()
    }

    /** Stops polling while the map is off screen; [resume] picks it up again. */
    fun pause() {
        paused = true
        refreshJob?.cancel()
        refreshJob = null
    }

    fun resume() {
        if (!paused) return
        paused = false
        scheduleRefresh()
    }

    fun dispose() {
        clear()
        scope.cancel()
    }

    private fun scheduleRefresh() {
        refreshJob?.cancel()
        refreshJob = null
        val current = info ?: return
        if (paused || options.refreshIntervalSeconds <= 0 || current.hasLanded || current.isCancelled) return
        val intervalMs = max(options.refreshIntervalSeconds, MIN_REFRESH_SECONDS) * 1000
        val generation = generation
        refreshJob = scope.launch {
            while (isActive) {
                delay(intervalMs)
                val shown = info ?: return@launch
                if (generation != this@FlightController.generation || shown.hasLanded || shown.isCancelled) return@launch
                try {
                    val updated = FlightData.lookUp(ident, shown.flightId)
                    if (generation != this@FlightController.generation) return@launch
                    apply(updated)
                } catch (e: FlightException) {
                    // The last data stays on the map; the next update may succeed.
                    if (generation == this@FlightController.generation) host.flightDidFail(e)
                }
            }
        }
    }

    private fun apply(info: FlightInfo) {
        this.info = info
        build(info)
        host.flightShapesDidChange()
        host.flightDidUpdate(info)
    }

    // MARK: Geometry

    private class Lines(
        val planned: List<LngLat>,
        val ahead: List<LngLat>,
        val track: List<LngLat>,
        val aircraft: LngLat?,
    )

    /** The flight's lines in one continuous longitude frame. */
    private fun lines(f: FlightInfo): Lines {
        val route = f.plannedRoute.map(::LngLat)
        val planned = FlightGeometry.densify(route)
        val ref = planned.firstOrNull()?.lng ?: f.track.firstOrNull()?.coordinate?.longitude
        val track = FlightGeometry.unwrap(f.track.map { LngLat(it.coordinate) }, ref).toMutableList()
        val position = f.position ?: return Lines(planned, emptyList(), track, null)
        var aircraft = LngLat(position.coordinate)
        var ahead = emptyList<LngLat>()
        val last = track.lastOrNull()
        if (route.size >= 2) {
            val split = FlightGeometry.split(route, aircraft)
            aircraft = split.aircraft
            if (f.isAirborne) ahead = split.ahead
        } else if (last != null) {
            aircraft = aircraft.copy(lng = FlightGeometry.nearLng(aircraft.lng, last.lng))
        }
        // The track ends where the aircraft is now, even when the newest point hasn't reached it yet.
        if (last != null && f.isAirborne) track.add(LngLat(FlightGeometry.nearLng(aircraft.lng, last.lng), aircraft.lat))
        return Lines(planned, ahead, track, aircraft)
    }

    // MARK: Drawing

    private fun build(f: FlightInfo) {
        val lines = lines(f)
        val color = options.color
        val lineList = mutableListOf<MapPolyline>()
        fun add(name: String, line: List<LngLat>, make: (String, List<LatLng>) -> MapPolyline) {
            FlightGeometry.cutAtDateLine(line).forEachIndexed { i, piece -> lineList.add(make("$ID_PREFIX$name-$i", piece)) }
        }
        if (options.plannedRoute) {
            add("planned", lines.planned) { id, c ->
                MapPolyline(id, c, color = withAlpha(color, 0.5f), widthDp = 1.5f, dashPattern = listOf(4f, 4f))
            }
        }
        if (options.remainingRoute) {
            add("ahead", lines.ahead) { id, c -> MapPolyline(id, c, color = color, widthDp = 2.5f, dashPattern = listOf(6f, 4f)) }
        }
        if (options.track) {
            add("track", lines.track) { id, c ->
                MapPolyline(id, c, color = Color.WHITE, widthDp = 3f, outlineColor = Color.argb(128, 0, 0, 0))
            }
        }
        polylines = lineList

        val markerList = mutableListOf<MapMarker>()
        if (options.airports) {
            for ((role, airport) in listOf("origin" to f.origin, "destination" to f.destination)) {
                val coordinate = airport?.coordinate ?: continue
                // Labels go on the side away from the aircraft, off the lines between them.
                val labelOnLeft = lines.aircraft?.let {
                    FlightGeometry.nearLng(it.lng, coordinate.longitude) > coordinate.longitude
                } ?: false
                markerList.add(MapMarker(ID_PREFIX + role, coordinate,
                    MapMarker.Icon.Image(icons.airport(airport.code, airport.city, color, labelOnLeft))))
            }
        }
        val position = f.position
        val at = lines.aircraft
        if (options.aircraft && position != null && at != null && !f.hasLanded) {
            val iconSize = options.aircraftIconSizeDp.coerceAtLeast(8f)
            markerList.add(MapMarker(ID_PREFIX + "aircraft", at.coordinate,
                MapMarker.Icon.Image(icons.aircraft(color, position.isEstimated, options.aircraftIcon, iconSize)),
                heading = position.heading ?: 0.0))
            val parts = listOfNotNull(
                position.altitudeFeet?.let { "${NumberFormat.getIntegerInstance().format(it.toLong())} ft" },
                f.destination?.let { "→ ${it.code}" },
                "estimated".takeIf { position.isEstimated },
            )
            markerList.add(MapMarker(ID_PREFIX + "aircraft-label", at.coordinate,
                MapMarker.Icon.Image(icons.aircraftLabel(f.ident, parts.joinToString(" "), iconSize / 2 + 4))))
        }
        markers = markerList
    }

    /** Moves the map to show the whole flight; while it flies, centred on the aircraft. */
    fun fit(animated: Boolean) {
        val f = info ?: return
        val lines = lines(f)
        val points = lines.planned + lines.track + listOfNotNull(lines.aircraft)
        if (points.isEmpty()) return
        // Unwrapped longitudes keep a date-line flight's box narrow instead of spanning the world.
        val w = points.minOf { it.lng }
        val e = points.maxOf { it.lng }
        val s = points.minOf { it.lat }
        val n = points.maxOf { it.lat }
        val padding = 1.3
        var center = LngLat((w + e) / 2, (s + n) / 2)
        var lngSpan = e - w
        var latSpan = n - s
        // Follow the aircraft while it flies: centre on it, wide enough to show the trip around it.
        val aircraft = lines.aircraft
        if (f.isAirborne && aircraft != null) {
            center = aircraft
            lngSpan = 2 * points.maxOf { abs(it.lng - aircraft.lng) }
            latSpan = 2 * points.maxOf { abs(it.lat - aircraft.lat) }
        }
        host.fitRegion(
            CoordinateRegion(
                center = center.coordinate,
                latitudeDelta = min(max(latSpan * padding, 0.5), 170.0),
                longitudeDelta = min(max(lngSpan * padding, 0.5), 350.0),
            ),
            animated,
        )
    }

    companion object {
        /** Prefix of the ids of everything the flight draws, so they never collide with the app's. */
        const val ID_PREFIX = "myradar-flight-"
        private const val MIN_REFRESH_SECONDS = 15L

        @ColorInt
        private fun withAlpha(@ColorInt color: Int, alpha: Float): Int =
            Color.argb((Color.alpha(color) * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color))
    }
}

/**
 * Marker images for flights. The map draws each image centered on its coordinate, so labels are
 * offset inside a larger transparent image. Images are cached so updates reuse the same bitmaps.
 */
private class FlightIcons(private val metrics: DisplayMetrics) {

    private val cache = LinkedHashMap<String, Bitmap>()
    private val density = metrics.density

    private fun cached(key: String, make: () -> Bitmap): Bitmap {
        cache[key]?.let { return it }
        if (cache.size > 64) cache.clear()
        return make().also { cache[key] = it }
    }

    private fun bitmap(widthDp: Float, heightDp: Float): Bitmap =
        Bitmap.createBitmap(metrics, (widthDp * density).toInt().coerceAtLeast(1), (heightDp * density).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888)

    /** Your own icon's last render, keyed by the bitmap itself so a new icon never reuses it. */
    private var lastCustom: CustomRender? = null

    private class CustomRender(val source: Bitmap, val size: Float, val estimated: Boolean, val bitmap: Bitmap)

    /**
     * The aircraft pointing north, so the map can rotate it to the heading. Hollow when estimated;
     * your own icon is drawn half transparent instead.
     */
    fun aircraft(@ColorInt color: Int, estimated: Boolean, custom: Bitmap?, size: Float): Bitmap {
        if (custom != null) {
            lastCustom?.takeIf { it.source === custom && it.size == size && it.estimated == estimated }?.let { return it.bitmap }
            return bitmap(size, size).also { bmp ->
                val canvas = Canvas(bmp)
                // Fit the icon in the square, centred, keeping its proportions.
                val side = size * density
                val scale = min(side / custom.width.coerceAtLeast(1), side / custom.height.coerceAtLeast(1))
                val (w, h) = custom.width * scale to custom.height * scale
                val dst = RectF((bmp.width - w) / 2, (bmp.height - h) / 2, (bmp.width + w) / 2, (bmp.height + h) / 2)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = if (estimated) 128 else 255 }
                canvas.drawBitmap(custom, null, dst, paint)
                lastCustom = CustomRender(custom, size, estimated, bmp)
            }
        }
        return cached("aircraft-$color-$estimated-$size") { builtInAircraft(color, estimated, size) }
    }

    private fun builtInAircraft(@ColorInt color: Int, estimated: Boolean, size: Float): Bitmap =
        bitmap(size, size).also { bmp ->
            val canvas = Canvas(bmp)
            canvas.scale(size * density / 64, size * density / 64)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                strokeJoin = Paint.Join.ROUND
                setShadowLayer(4f * 64 / size, 0f, 1f, Color.argb(153, 0, 0, 0))
            }
            if (estimated) {
                paint.style = Paint.Style.STROKE
                paint.color = Color.WHITE
                paint.strokeWidth = 3.5f
                canvas.drawPath(PLANE_PATH, paint)
            } else {
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                canvas.drawPath(PLANE_PATH, paint)
                paint.clearShadowLayer()
                paint.style = Paint.Style.STROKE
                paint.color = color
                paint.strokeWidth = 2.5f
                canvas.drawPath(PLANE_PATH, paint)
            }
        }

    /** The aircraft's label, sitting below the aircraft. */
    fun aircraftLabel(ident: String, detail: String, gap: Float): Bitmap = cached("label-$ident-$detail-$gap") {
        val pill = Pill(ident, if (detail.isEmpty()) "" else " $detail")
        bitmap(pill.widthDp, (gap + pill.heightDp) * 2).also { bmp ->
            pill.draw(Canvas(bmp), 0f, bmp.height / 2f + gap * density)
        }
    }

    /** An airport dot with its code and city beside it. */
    fun airport(code: String, city: String, @ColorInt color: Int, labelOnLeft: Boolean): Bitmap =
        cached("airport-$code-$city-$color-$labelOnLeft") {
            val pill = Pill(code, " $city")
            val dot = 12f
            val gap = 4f
            val half = dot / 2 + gap + pill.widthDp
            bitmap(half * 2, max(dot, pill.heightDp)).also { bmp ->
                val canvas = Canvas(bmp)
                val cx = bmp.width / 2f
                val cy = bmp.height / 2f
                val r = (dot / 2 - 1.5f) * density
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                paint.color = Color.WHITE
                canvas.drawCircle(cx, cy, r, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f * density
                paint.color = color
                canvas.drawCircle(cx, cy, r, paint)
                val x = if (labelOnLeft) cx - (dot / 2 + gap + pill.widthDp) * density else cx + (dot / 2 + gap) * density
                pill.draw(canvas, x, cy - pill.heightDp * density / 2)
            }
        }

    /** A dark rounded label with a bold part and a regular part. */
    private inner class Pill(private val bold: String, private val regular: String) {
        private val boldPaint = textPaint(Typeface.DEFAULT_BOLD)
        private val regularPaint = textPaint(Typeface.DEFAULT)
        private val boldWidth = boldPaint.measureText(bold)
        private val textWidth = boldWidth + regularPaint.measureText(regular)
        private val metrics = boldPaint.fontMetrics
        val widthDp = textWidth / density + 12
        val heightDp = (metrics.descent - metrics.ascent) / density + 4

        private fun textPaint(typeface: Typeface) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            textSize = 12f * density
            color = Color.WHITE
        }

        fun draw(canvas: Canvas, x: Float, y: Float) {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(204, 15, 20, 30) }
            canvas.drawRoundRect(RectF(x, y, x + widthDp * density, y + heightDp * density), 4 * density, 4 * density, bg)
            val baseline = y + 2 * density - metrics.ascent
            canvas.drawText(bold, x + 6 * density, baseline, boldPaint)
            canvas.drawText(regular, x + 6 * density + boldWidth, baseline, regularPaint)
        }
    }

    private companion object {
        /** An airliner seen from above, nose up, in a 64 × 64 box. */
        val PLANE_PATH = Path().apply {
            moveTo(32f, 3f)
            cubicTo(29.8f, 3f, 28f, 6.4f, 28f, 10.6f)
            for ((x, y) in listOf(28f to 23.5f, 5f to 37.3f, 5f to 42.7f, 28f to 35.3f, 28f to 47.4f, 21.6f to 51.7f,
                21.6f to 55.5f, 32f to 53f, 42.4f to 55.5f, 42.4f to 51.7f, 36f to 47.4f, 36f to 35.3f, 59f to 42.7f,
                59f to 37.3f, 36f to 23.5f, 36f to 10.6f)) {
                lineTo(x, y)
            }
            cubicTo(36f, 6.4f, 34.2f, 3f, 32f, 3f)
            close()
        }
    }
}
